import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";
import { specHead } from "@/data/page-specs";

export const Route = createFileRoute("/parties/contact")({
  head: () => specHead("/parties/contact"),
  component: Routepartiescontact,
});

function Routepartiescontact() {
  return <SectionPage path="/parties/contact" />;
}
