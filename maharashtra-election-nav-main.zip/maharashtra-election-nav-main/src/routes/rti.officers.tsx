import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";
import { specHead } from "@/data/page-specs";

export const Route = createFileRoute("/rti/officers")({
  head: () => specHead("/rti/officers"),
  component: Routertiofficers,
});

function Routertiofficers() {
  return <SectionPage path="/rti/officers" />;
}
