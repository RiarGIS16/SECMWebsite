import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";

export const Route = createFileRoute("/parties/compliance")({
  component: PartiesComplianceRoute,
});

function PartiesComplianceRoute() {
  return <SectionPage path="/parties/compliance" />;
}
