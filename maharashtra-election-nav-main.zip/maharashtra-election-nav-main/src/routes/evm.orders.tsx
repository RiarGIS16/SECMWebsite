import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";
import { specHead } from "@/data/page-specs";

export const Route = createFileRoute("/evm/orders")({
  head: () => specHead("/evm/orders"),
  component: Routeevmorders,
});

function Routeevmorders() {
  return <SectionPage path="/evm/orders" />;
}
