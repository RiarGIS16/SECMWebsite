import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";
import { specHead } from "@/data/page-specs";

export const Route = createFileRoute("/rti/section-4")({
  head: () => specHead("/rti/section-4"),
  component: Routertisection4,
});

function Routertisection4() {
  return <SectionPage path="/rti/section-4" />;
}
