import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";

export const Route = createFileRoute("/parties/")({
  component: PartiesRoute,
});

function PartiesRoute() {
  return <SectionPage path="/parties" />;
}
