import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";
import { specHead } from "@/data/page-specs";

export const Route = createFileRoute("/elections/upcoming")({
  head: () => specHead("/elections/upcoming"),
  component: Routeelectionsupcoming,
});

function Routeelectionsupcoming() {
  return <SectionPage path="/elections/upcoming" />;
}
