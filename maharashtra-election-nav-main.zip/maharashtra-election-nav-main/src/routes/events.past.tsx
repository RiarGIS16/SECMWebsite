import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";
import { specHead } from "@/data/page-specs";

export const Route = createFileRoute("/events/past")({
  head: () => specHead("/events/past"),
  component: Routeeventspast,
});

function Routeeventspast() {
  return <SectionPage path="/events/past" />;
}
