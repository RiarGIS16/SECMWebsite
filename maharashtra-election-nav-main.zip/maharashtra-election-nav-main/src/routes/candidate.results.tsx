import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";
import { specHead } from "@/data/page-specs";

export const Route = createFileRoute("/candidate/results")({
  head: () => specHead("/candidate/results"),
  component: Routecandidateresults,
});

function Routecandidateresults() {
  return <SectionPage path="/candidate/results" />;
}
