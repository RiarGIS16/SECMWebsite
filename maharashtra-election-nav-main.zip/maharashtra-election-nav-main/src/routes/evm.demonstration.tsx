import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";
import { specHead } from "@/data/page-specs";

export const Route = createFileRoute("/evm/demonstration")({
  head: () => specHead("/evm/demonstration"),
  component: Routeevmdemonstration,
});

function Routeevmdemonstration() {
  return <SectionPage path="/evm/demonstration" />;
}
