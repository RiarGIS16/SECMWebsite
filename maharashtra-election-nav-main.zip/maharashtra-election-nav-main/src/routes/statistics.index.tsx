import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";

export const Route = createFileRoute("/statistics/")({
  component: StatisticsRoute,
});

function StatisticsRoute() {
  return <SectionPage path="/statistics" />;
}
