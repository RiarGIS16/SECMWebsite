import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";

export const Route = createFileRoute("/voter/")({
  component: VoterRoute,
});

function VoterRoute() {
  return <SectionPage path="/voter" />;
}
