import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";

export const Route = createFileRoute("/parties/registration")({
  component: PartiesRegistrationRoute,
});

function PartiesRegistrationRoute() {
  return <SectionPage path="/parties/registration" />;
}
