import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";
import { specHead } from "@/data/page-specs";

export const Route = createFileRoute("/about/protocol")({
  head: () => specHead("/about/protocol"),
  component: Routeaboutprotocol,
});

function Routeaboutprotocol() {
  return <SectionPage path="/about/protocol" />;
}
