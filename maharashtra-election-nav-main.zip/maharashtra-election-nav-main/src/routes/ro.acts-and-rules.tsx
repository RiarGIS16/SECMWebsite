import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";

export const Route = createFileRoute("/ro/acts-and-rules")({
  component: RoActsAndRulesRoute,
});

function RoActsAndRulesRoute() {
  return <SectionPage path="/ro/acts-and-rules" />;
}
