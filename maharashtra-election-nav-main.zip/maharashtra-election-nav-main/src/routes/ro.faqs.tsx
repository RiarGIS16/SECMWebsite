import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";
import { specHead } from "@/data/page-specs";

export const Route = createFileRoute("/ro/faqs")({
  head: () => specHead("/ro/faqs"),
  component: Routerofaqs,
});

function Routerofaqs() {
  return <SectionPage path="/ro/faqs" />;
}
