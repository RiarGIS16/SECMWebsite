import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";
import { specHead } from "@/data/page-specs";

export const Route = createFileRoute("/publications/search")({
  head: () => specHead("/publications/search"),
  component: Routepublicationssearch,
});

function Routepublicationssearch() {
  return <SectionPage path="/publications/search" />;
}
