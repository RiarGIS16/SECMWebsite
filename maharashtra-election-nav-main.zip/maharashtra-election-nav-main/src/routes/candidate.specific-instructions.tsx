import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";
import { specHead } from "@/data/page-specs";

export const Route = createFileRoute("/candidate/specific-instructions")({
  head: () => specHead("/candidate/specific-instructions"),
  component: CandidateSpecificInstructionsRoute,
});

function CandidateSpecificInstructionsRoute() {
  return <SectionPage path="/candidate/specific-instructions" />;
}