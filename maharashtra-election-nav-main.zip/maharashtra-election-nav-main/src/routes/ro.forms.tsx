import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";

export const Route = createFileRoute("/ro/forms")({
  component: RoFormsRoute,
});

function RoFormsRoute() {
  return <SectionPage path="/ro/forms" />;
}
