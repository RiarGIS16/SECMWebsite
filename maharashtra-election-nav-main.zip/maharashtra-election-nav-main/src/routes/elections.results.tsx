import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";

export const Route = createFileRoute("/elections/results")({
  component: ElectionsResultsRoute,
});

function ElectionsResultsRoute() {
  return <SectionPage path="/elections/results" />;
}
