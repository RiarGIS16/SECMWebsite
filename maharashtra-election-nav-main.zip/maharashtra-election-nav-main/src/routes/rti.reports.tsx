import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";
import { specHead } from "@/data/page-specs";

export const Route = createFileRoute("/rti/reports")({
  head: () => specHead("/rti/reports"),
  component: Routertireports,
});

function Routertireports() {
  return <SectionPage path="/rti/reports" />;
}
