import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";

export const Route = createFileRoute("/contact/")({
  component: ContactRoute,
});

function ContactRoute() {
  return <SectionPage path="/contact" />;
}
