import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";
import { specHead } from "@/data/page-specs";

export const Route = createFileRoute("/evm/training")({
  head: () => specHead("/evm/training"),
  component: Routeevmtraining,
});

function Routeevmtraining() {
  return <SectionPage path="/evm/training" />;
}
