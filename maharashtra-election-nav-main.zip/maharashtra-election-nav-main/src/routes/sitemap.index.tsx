import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";

export const Route = createFileRoute("/sitemap/")({
  component: SitemapRoute,
});

function SitemapRoute() {
  return <SectionPage path="/sitemap" />;
}
