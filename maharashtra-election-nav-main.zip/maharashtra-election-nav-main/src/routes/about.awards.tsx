import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";
import { specHead } from "@/data/page-specs";

export const Route = createFileRoute("/about/awards")({
  head: () => specHead("/about/awards"),
  component: Routeaboutawards,
});

function Routeaboutawards() {
  return <SectionPage path="/about/awards" />;
}
