import { createFileRoute, Link } from "@tanstack/react-router";
import { zodValidator, fallback } from "@tanstack/zod-adapter";
import * as React from "react";
import { z } from "zod";

import { PageShell } from "@/components/layout/PageShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useI18n } from "@/i18n/i18n";
import { countByKind, searchKindLabels, searchSite } from "@/lib/search";

const searchSchema = z.object({
  q: fallback(z.string(), "").default(""),
  kind: fallback(z.string(), "all").default("all"),
});

export const Route = createFileRoute("/search/")({
  validateSearch: zodValidator(searchSchema),
  head: () => ({
    meta: [
      { title: "Search — State Election Commission, Maharashtra" },
      { name: "description", content: "Search notices, elections, forms, services and FAQs across the portal." },
      { property: "og:title", content: "Search — State Election Commission, Maharashtra" },
      { property: "og:description", content: "Search notices, elections, forms, services and FAQs." },
    ],
  }),
  component: SearchResultsPage,
});

function SearchResultsPage() {
  const { q, kind } = Route.useSearch();
  const navigate = Route.useNavigate();
  const { t, localised, locale, formatDate } = useI18n();
  const [draft, setDraft] = React.useState(q);

  React.useEffect(() => setDraft(q), [q]);

  const hits = React.useMemo(() => searchSite(q, locale), [q, locale]);
  const counts = React.useMemo(() => countByKind(hits), [hits]);
  const visible = kind === "all" ? hits : hits.filter((hit) => hit.kind === kind);

  return (
    <PageShell
      title={{ en: "Search", mr: "शोध" }}
      intro={{
        en: "One search across services, notices, forms, elections and help content — with result counts by type.",
        mr: "सेवा, सूचना, नमुने, निवडणुका व मदत मजकुरामध्ये एकत्रित शोध — प्रकारनिहाय संख्येसह.",
      }}
      crumbs={[{ label: { en: "Search", mr: "शोध" } }]}
    >
      <form
        className="flex flex-wrap items-end gap-3"
        onSubmit={(event) => {
          event.preventDefault();
          navigate({ search: { q: draft.trim(), kind } });
        }}
      >
        <div className="min-w-0 flex-1 space-y-1.5">
          <Label htmlFor="site-search" className="text-sm font-medium">
            {t("search.label")}
          </Label>
          <Input
            id="site-search"
            type="search"
            value={draft}
            onChange={(event) => setDraft(event.target.value)}
            placeholder={t("search.placeholder")}
            className="min-h-11 bg-card"
          />
        </div>
        <Button type="submit" className="min-h-11">
          {t("search.submit")}
        </Button>
      </form>

      {q.trim() && (
        <>
          <div className="mt-6 flex flex-wrap gap-2" role="group" aria-label={t("search.filterByType")}>
            <FilterChip active={kind === "all"} onClick={() => navigate({ search: { q, kind: "all" } })}>
              {t("search.allTypes")} ({hits.length})
            </FilterChip>
            {Object.entries(counts).map(([key, count]) => (
              <FilterChip
                key={key}
                active={kind === key}
                onClick={() => navigate({ search: { q, kind: key } })}
              >
                {localised(searchKindLabels[key as keyof typeof searchKindLabels])} ({count})
              </FilterChip>
            ))}
          </div>

          <p aria-live="polite" className="mt-4 text-sm text-muted-foreground">
            {visible.length} {visible.length === 1 ? t("search.countOne") : t("search.countMany")}{" "}
            {t("search.resultsFor")} “{q}”
          </p>

          {visible.length === 0 ? (
            <div className="mt-6 rounded-lg border border-dashed p-8 text-center">
              <p className="font-medium">{t("search.noResults")}</p>
              <p className="mt-1 text-sm text-muted-foreground">{t("search.noResultsHint")}</p>
            </div>
          ) : (
            <ul className="mt-4 divide-y rounded-lg border bg-card">
              {visible.map((hit) => (
                <li key={hit.id}>
                  <Link to={hit.href} className="block p-4 hover:bg-surface">
                    <span className="text-xs text-muted-foreground">
                      {localised(hit.section)} · {localised(searchKindLabels[hit.kind])}
                      {hit.date ? ` · ${formatDate(hit.date)}` : ""}
                    </span>
                    <span className="mt-0.5 block font-medium text-primary underline-offset-2 hover:underline">
                      {localised(hit.title)}
                    </span>
                    <span className="mt-1 block text-sm text-muted-foreground">
                      {localised(hit.snippet)}
                    </span>
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </>
      )}
    </PageShell>
  );
}

function FilterChip({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      aria-pressed={active}
      onClick={onClick}
      className={
        active
          ? "min-h-9 rounded-full border border-primary bg-primary px-3 text-sm font-medium text-primary-foreground"
          : "min-h-9 rounded-full border bg-card px-3 text-sm hover:bg-surface"
      }
    >
      {children}
    </button>
  );
}
