import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";
import { specHead } from "@/data/page-specs";

export const Route = createFileRoute("/elections/ongoing")({
  head: () => specHead("/elections/ongoing"),
  component: Routeelectionsongoing,
});

function Routeelectionsongoing() {
  return <SectionPage path="/elections/ongoing" />;
}
