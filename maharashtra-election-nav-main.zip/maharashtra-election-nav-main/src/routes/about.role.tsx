import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";
import { specHead } from "@/data/page-specs";

export const Route = createFileRoute("/about/role")({
  head: () => specHead("/about/role"),
  component: Routeaboutrole,
});

function Routeaboutrole() {
  return <SectionPage path="/about/role" />;
}
