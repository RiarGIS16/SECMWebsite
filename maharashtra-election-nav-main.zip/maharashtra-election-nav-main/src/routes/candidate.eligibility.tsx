import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";

export const Route = createFileRoute("/candidate/eligibility")({
  component: CandidateEligibilityRoute,
});

function CandidateEligibilityRoute() {
  return <SectionPage path="/candidate/eligibility" />;
}
