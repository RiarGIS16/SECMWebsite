import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";

export const Route = createFileRoute("/evm/")({
  component: EvmRoute,
});

function EvmRoute() {
  return <SectionPage path="/evm" />;
}
