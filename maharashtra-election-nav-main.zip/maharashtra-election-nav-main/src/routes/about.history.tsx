import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";
import { specHead } from "@/data/page-specs";

export const Route = createFileRoute("/about/history")({
  head: () => specHead("/about/history"),
  component: Routeabouthistory,
});

function Routeabouthistory() {
  return <SectionPage path="/about/history" />;
}
