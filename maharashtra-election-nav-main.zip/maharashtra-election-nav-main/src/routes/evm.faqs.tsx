import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";
import { specHead } from "@/data/page-specs";

export const Route = createFileRoute("/evm/faqs")({
  head: () => specHead("/evm/faqs"),
  component: Routeevmfaqs,
});

function Routeevmfaqs() {
  return <SectionPage path="/evm/faqs" />;
}
