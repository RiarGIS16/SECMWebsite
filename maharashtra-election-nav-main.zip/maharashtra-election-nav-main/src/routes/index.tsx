import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, CalendarDays, FileText, Info, Users } from "lucide-react";
import * as React from "react";

import { AreaFilter, emptyArea, type AreaSelection } from "@/components/common/AreaFilter";
import { ServiceIcon } from "@/components/common/ServiceIcon";
import { Section } from "@/components/layout/PageShell";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { documents, documentTypeLabels } from "@/data/documents";
import { elections, phaseLabels, pollDate, statusLabels } from "@/data/elections";
import { geoStats } from "@/data/geo";
import { navSections, quickLinks } from "@/data/navigation";
import { useI18n } from "@/i18n/i18n";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "State Election Commission, Maharashtra — Local body elections" },
      {
        name: "description",
        content:
          "Find your ward, track the election programme, file nominations and read notices — services for voters, candidates and Returning Officers.",
      },
      { property: "og:title", content: "State Election Commission, Maharashtra" },
      {
        property: "og:description",
        content: "Voter, candidate and Returning Officer services for local body elections in Maharashtra.",
      },
    ],
  }),
  component: HomePage,
});

function HomePage() {
  const { t, localised, formatDate, formatNumber } = useI18n();
  const [area, setArea] = React.useState<AreaSelection>(emptyArea);

  const latest = [...documents]
    .sort((a, b) => b.publishedOn.localeCompare(a.publishedOn))
    .slice(0, 5);
  const programme = elections.filter((e) => e.status !== "completed").slice(0, 3);

  return (
    <>
      <div className="border-b bg-warning/15">
        <p className="mx-auto flex max-w-7xl items-start gap-2 px-4 py-2 text-sm">
          <Info aria-hidden="true" className="mt-0.5 size-4 shrink-0" />
          <span>{t("site.demoBanner")}</span>
        </p>
      </div>

      <section className="border-b bg-surface">
        <div className="mx-auto grid max-w-7xl gap-8 px-4 py-10 lg:grid-cols-[1.1fr_1fr] lg:py-14">
          <div>
            <p className="font-display text-sm font-semibold tracking-wide uppercase text-accent-foreground">
              {t("site.tagline")}
            </p>
            <h1 className="mt-3 font-display text-3xl font-bold text-balance text-primary sm:text-4xl">
              {t("home.heroTitle")}
            </h1>
            <p className="mt-3 max-w-2xl text-lg text-muted-foreground">{t("home.heroBody")}</p>

            <div className="mt-6 grid gap-3 sm:grid-cols-3">
              <RoleCard
                to="/voter"
                icon={<Users aria-hidden="true" className="size-5" />}
                title={t("home.roleVoter")}
                body={t("home.roleVoterBody")}
              />
              <RoleCard
                to="/candidate"
                icon={<FileText aria-hidden="true" className="size-5" />}
                title={t("home.roleCandidate")}
                body={t("home.roleCandidateBody")}
              />
              <RoleCard
                to="/ro"
                icon={<CalendarDays aria-hidden="true" className="size-5" />}
                title={t("home.roleOfficer")}
                body={t("home.roleOfficerBody")}
              />
            </div>
          </div>

          <div className="rounded-xl border bg-card p-5 shadow-sm">
            <h2 className="font-display text-lg font-bold">{t("geo.heading")}</h2>
            <p className="mt-1 text-sm text-muted-foreground">{t("geo.description")}</p>
            <div className="mt-4">
              <AreaFilter value={area} onChange={setArea} depth="ward" idPrefix="home-area" />
            </div>
            <Button asChild className="mt-4 min-h-11 w-full">
              <Link to="/voter">{t("geo.apply")}</Link>
            </Button>
          </div>
        </div>
      </section>

      <div className="mx-auto max-w-7xl px-4 py-10">
        <Section title={{ en: t("home.quickLinks"), mr: t("home.quickLinks") }}>
          <ul className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {quickLinks.map((link) => (
              <li key={link.to}>
                <Link
                  to={link.to}
                  className="flex h-full min-h-11 items-start justify-between gap-3 rounded-lg border bg-card p-4 hover:border-accent hover:shadow-sm"
                >
                  <span className="flex min-w-0 items-start gap-3">
                    <span className="grid size-10 shrink-0 place-items-center rounded-md bg-primary/10 text-primary">
                      <ServiceIcon name={link.icon} className="size-5" />
                    </span>
                    <span className="min-w-0">
                    <span className="block font-medium">{localised(link.label)}</span>
                    <span className="mt-1 block text-sm text-muted-foreground">
                      {localised(link.hint)}
                    </span>
                    </span>
                  </span>
                  <ArrowRight aria-hidden="true" className="mt-1 size-4 shrink-0 text-accent" />
                </Link>
              </li>
            ))}
          </ul>
        </Section>

        <div className="mt-10 grid gap-10 lg:grid-cols-2">
          <Section
            title={{ en: t("home.latestNotices"), mr: t("home.latestNotices") }}
            actions={
              <Link to="/updates" className="text-sm font-medium underline hover:no-underline">
                {t("ui.viewAll")}
              </Link>
            }
          >
            <ul className="divide-y rounded-lg border bg-card">
              {latest.map((record) => (
                <li key={record.id} className="p-4">
                  <div className="flex flex-wrap items-center gap-2">
                    <Badge variant="outline">{localised(documentTypeLabels[record.type])}</Badge>
                    <span className="text-xs text-muted-foreground">
                      {formatDate(record.publishedOn)} · {localised(record.issuingAuthority)}
                    </span>
                  </div>
                  <Link
                    to="/updates"
                    className="mt-1 block font-medium text-primary underline-offset-2 hover:underline"
                  >
                    {localised(record.title)}
                  </Link>
                  <p className="mt-1 text-sm text-muted-foreground">{localised(record.summary)}</p>
                </li>
              ))}
            </ul>
          </Section>

          <Section
            title={{ en: t("home.upcoming"), mr: t("home.upcoming") }}
            actions={
              <Link to="/elections" className="text-sm font-medium underline hover:no-underline">
                {t("ui.viewAll")}
              </Link>
            }
          >
            <ul className="space-y-3">
              {programme.map((election) => (
                <li key={election.id} className="rounded-lg border bg-card p-4">
                  <div className="flex flex-wrap items-center gap-2">
                    <Badge>{localised(statusLabels[election.status])}</Badge>
                    <span className="text-xs text-muted-foreground">
                      {formatNumber(election.seats)}{" "}
                      {localised({ en: "seats", mr: "जागा" })} ·{" "}
                      {formatNumber(election.electors)} {localised({ en: "electors", mr: "मतदार" })}
                    </span>
                  </div>
                  <h3 className="mt-1 font-medium">{localised(election.name)}</h3>
                  <p className="mt-1 text-sm text-muted-foreground">
                    {localised(phaseLabels.poll)}: {formatDate(pollDate(election))}
                  </p>
                </li>
              ))}
            </ul>
          </Section>
        </div>

        <Section title={{ en: t("home.stats"), mr: t("home.stats") }}>
          <dl className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <Stat label={t("home.statDistricts")} value={formatNumber(geoStats.districts)} />
            <Stat label={t("home.statBodies")} value={formatNumber(geoStats.localBodies)} />
            <Stat label={t("home.statWards")} value={formatNumber(geoStats.wards)} />
            <Stat label={t("home.statPolls")} value={formatNumber(elections.length)} />
          </dl>
          <p className="mt-2 text-xs text-muted-foreground">{t("ui.demoData")}.</p>
        </Section>

        <Section title={{ en: "Browse the site", mr: "संकेतस्थळ पहा" }}>
          <ul className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {navSections.map((section) => (
              <li key={section.id}>
                <Link to={section.to} className="block h-full rounded-lg border bg-card p-4 hover:border-accent">
                  <span className="block font-display font-semibold text-primary">
                    {localised(section.label)}
                  </span>
                  <span className="mt-1 block text-sm text-muted-foreground">
                    {localised(section.summary)}
                  </span>
                </Link>
              </li>
            ))}
          </ul>
        </Section>
      </div>
    </>
  );
}

function RoleCard({
  to,
  icon,
  title,
  body,
}: {
  to: string;
  icon: React.ReactNode;
  title: string;
  body: string;
}) {
  return (
    <Link
      to={to}
      className="flex h-full flex-col gap-1 rounded-lg border bg-card p-4 hover:border-accent hover:shadow-sm"
    >
      <span className="text-accent-foreground">{icon}</span>
      <span className="font-medium">{title}</span>
      <span className="text-sm text-muted-foreground">{body}</span>
    </Link>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border bg-surface p-4">
      <dt className="text-sm text-muted-foreground">{label}</dt>
      <dd className="mt-1 font-display text-2xl font-bold text-primary">{value}</dd>
    </div>
  );
}
