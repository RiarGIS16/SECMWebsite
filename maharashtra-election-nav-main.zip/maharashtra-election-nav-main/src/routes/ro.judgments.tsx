import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";
import { specHead } from "@/data/page-specs";

export const Route = createFileRoute("/ro/judgments")({
  head: () => specHead("/ro/judgments"),
  component: RoJudgmentsRoute,
});

function RoJudgmentsRoute() {
  return <SectionPage path="/ro/judgments" />;
}