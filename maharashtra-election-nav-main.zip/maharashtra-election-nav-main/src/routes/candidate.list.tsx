import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";

export const Route = createFileRoute("/candidate/list")({
  component: CandidateListRoute,
});

function CandidateListRoute() {
  return <SectionPage path="/candidate/list" />;
}
