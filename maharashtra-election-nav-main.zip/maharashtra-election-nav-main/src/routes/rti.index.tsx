import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";

export const Route = createFileRoute("/rti/")({
  component: RtiRoute,
});

function RtiRoute() {
  return <SectionPage path="/rti" />;
}
