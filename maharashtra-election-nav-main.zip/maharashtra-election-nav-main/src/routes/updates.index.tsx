import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";

export const Route = createFileRoute("/updates/")({
  component: UpdatesRoute,
});

function UpdatesRoute() {
  return <SectionPage path="/updates" />;
}
