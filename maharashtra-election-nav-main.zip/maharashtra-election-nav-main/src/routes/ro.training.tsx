import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";
import { specHead } from "@/data/page-specs";

export const Route = createFileRoute("/ro/training")({
  head: () => specHead("/ro/training"),
  component: Routerotraining,
});

function Routerotraining() {
  return <SectionPage path="/ro/training" />;
}
