import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";
import { specHead } from "@/data/page-specs";

export const Route = createFileRoute("/ro/circulars")({
  head: () => specHead("/ro/circulars"),
  component: Routerocirculars,
});

function Routerocirculars() {
  return <SectionPage path="/ro/circulars" />;
}
