import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";

export const Route = createFileRoute("/parties/register")({
  component: PartiesRegisterRoute,
});

function PartiesRegisterRoute() {
  return <SectionPage path="/parties/register" />;
}
