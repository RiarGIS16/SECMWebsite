import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";
import { specHead } from "@/data/page-specs";

export const Route = createFileRoute("/parties/deregistered")({
  head: () => specHead("/parties/deregistered"),
  component: DeregisteredPartiesRoute,
});

function DeregisteredPartiesRoute() {
  return <SectionPage path="/parties/deregistered" />;
}