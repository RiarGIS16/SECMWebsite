import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";

export const Route = createFileRoute("/events/")({
  component: EventsRoute,
});

function EventsRoute() {
  return <SectionPage path="/events" />;
}
