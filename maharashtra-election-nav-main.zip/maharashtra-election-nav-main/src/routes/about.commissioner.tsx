import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";
import { specHead } from "@/data/page-specs";

export const Route = createFileRoute("/about/commissioner")({
  head: () => specHead("/about/commissioner"),
  component: Routeaboutcommissioner,
});

function Routeaboutcommissioner() {
  return <SectionPage path="/about/commissioner" />;
}
