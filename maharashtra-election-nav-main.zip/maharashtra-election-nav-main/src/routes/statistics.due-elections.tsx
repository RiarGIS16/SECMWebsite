import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";
import { specHead } from "@/data/page-specs";

export const Route = createFileRoute("/statistics/due-elections")({
  head: () => specHead("/statistics/due-elections"),
  component: DueElectionDataRoute,
});

function DueElectionDataRoute() {
  return <SectionPage path="/statistics/due-elections" />;
}