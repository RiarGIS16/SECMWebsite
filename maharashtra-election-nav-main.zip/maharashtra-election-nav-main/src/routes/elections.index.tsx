import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";

export const Route = createFileRoute("/elections/")({
  component: ElectionsRoute,
});

function ElectionsRoute() {
  return <SectionPage path="/elections" />;
}
