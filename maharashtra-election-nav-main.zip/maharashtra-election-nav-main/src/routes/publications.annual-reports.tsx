import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";
import { specHead } from "@/data/page-specs";

export const Route = createFileRoute("/publications/annual-reports")({
  head: () => specHead("/publications/annual-reports"),
  component: Routepublicationsannualreports,
});

function Routepublicationsannualreports() {
  return <SectionPage path="/publications/annual-reports" />;
}
