import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";

export const Route = createFileRoute("/publications/")({
  component: PublicationsRoute,
});

function PublicationsRoute() {
  return <SectionPage path="/publications" />;
}
