import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";

export const Route = createFileRoute("/ro/calendar")({
  component: RoCalendarRoute,
});

function RoCalendarRoute() {
  return <SectionPage path="/ro/calendar" />;
}
