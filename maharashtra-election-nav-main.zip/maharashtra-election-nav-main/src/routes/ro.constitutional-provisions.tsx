import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";
import { specHead } from "@/data/page-specs";

export const Route = createFileRoute("/ro/constitutional-provisions")({
  head: () => specHead("/ro/constitutional-provisions"),
  component: Routeroconstitutionalprovisions,
});

function Routeroconstitutionalprovisions() {
  return <SectionPage path="/ro/constitutional-provisions" />;
}
