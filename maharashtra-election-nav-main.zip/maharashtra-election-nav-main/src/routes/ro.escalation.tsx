import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";

export const Route = createFileRoute("/ro/escalation")({
  component: RoEscalationRoute,
});

function RoEscalationRoute() {
  return <SectionPage path="/ro/escalation" />;
}
