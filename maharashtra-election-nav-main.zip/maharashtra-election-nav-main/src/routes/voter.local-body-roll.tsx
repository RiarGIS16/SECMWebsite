import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";
import { specHead } from "@/data/page-specs";

export const Route = createFileRoute("/voter/local-body-roll")({
  head: () => specHead("/voter/local-body-roll"),
  component: Routevoterlocalbodyroll,
});

function Routevoterlocalbodyroll() {
  return <SectionPage path="/voter/local-body-roll" />;
}
