import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";
import { specHead } from "@/data/page-specs";

export const Route = createFileRoute("/parties/circulars")({
  head: () => specHead("/parties/circulars"),
  component: Routepartiescirculars,
});

function Routepartiescirculars() {
  return <SectionPage path="/parties/circulars" />;
}
