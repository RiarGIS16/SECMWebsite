import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";

export const Route = createFileRoute("/accessibility/")({
  component: AccessibilityRoute,
});

function AccessibilityRoute() {
  return <SectionPage path="/accessibility" />;
}
