import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";
import { specHead } from "@/data/page-specs";

export const Route = createFileRoute("/voter/awareness")({
  head: () => specHead("/voter/awareness"),
  component: Routevoterawareness,
});

function Routevoterawareness() {
  return <SectionPage path="/voter/awareness" />;
}
