import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";

export const Route = createFileRoute("/voter/polling-station")({
  component: VoterPollingStationRoute,
});

function VoterPollingStationRoute() {
  return <SectionPage path="/voter/polling-station" />;
}
