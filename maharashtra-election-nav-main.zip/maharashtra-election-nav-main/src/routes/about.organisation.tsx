import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";
import { specHead } from "@/data/page-specs";

export const Route = createFileRoute("/about/organisation")({
  head: () => specHead("/about/organisation"),
  component: Routeaboutorganisation,
});

function Routeaboutorganisation() {
  return <SectionPage path="/about/organisation" />;
}
