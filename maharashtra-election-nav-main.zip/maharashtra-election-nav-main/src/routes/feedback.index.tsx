import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";

export const Route = createFileRoute("/feedback/")({
  component: FeedbackRoute,
});

function FeedbackRoute() {
  return <SectionPage path="/feedback" />;
}
