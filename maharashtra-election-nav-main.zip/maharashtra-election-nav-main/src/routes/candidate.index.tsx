import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";

export const Route = createFileRoute("/candidate/")({
  component: CandidateRoute,
});

function CandidateRoute() {
  return <SectionPage path="/candidate" />;
}
