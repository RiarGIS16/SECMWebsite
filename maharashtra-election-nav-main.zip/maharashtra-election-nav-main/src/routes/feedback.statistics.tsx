import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";
import { specHead } from "@/data/page-specs";

export const Route = createFileRoute("/feedback/statistics")({
  head: () => specHead("/feedback/statistics"),
  component: Routefeedbackstatistics,
});

function Routefeedbackstatistics() {
  return <SectionPage path="/feedback/statistics" />;
}
