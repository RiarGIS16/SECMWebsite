import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";
import { specHead } from "@/data/page-specs";

export const Route = createFileRoute("/candidate/general-orders")({
  head: () => specHead("/candidate/general-orders"),
  component: CandidateGeneralOrdersRoute,
});

function CandidateGeneralOrdersRoute() {
  return <SectionPage path="/candidate/general-orders" />;
}