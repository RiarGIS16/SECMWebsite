import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";

export const Route = createFileRoute("/candidate/nomination")({
  component: CandidateNominationRoute,
});

function CandidateNominationRoute() {
  return <SectionPage path="/candidate/nomination" />;
}
