import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";

export const Route = createFileRoute("/candidate/symbols")({
  component: CandidateSymbolsRoute,
});

function CandidateSymbolsRoute() {
  return <SectionPage path="/candidate/symbols" />;
}
