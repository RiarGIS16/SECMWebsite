import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";

export const Route = createFileRoute("/feedback/status")({
  component: FeedbackStatusRoute,
});

function FeedbackStatusRoute() {
  return <SectionPage path="/feedback/status" />;
}
