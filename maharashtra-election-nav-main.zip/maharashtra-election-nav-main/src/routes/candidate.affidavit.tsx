import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";

export const Route = createFileRoute("/candidate/affidavit")({
  component: CandidateAffidavitRoute,
});

function CandidateAffidavitRoute() {
  return <SectionPage path="/candidate/affidavit" />;
}
