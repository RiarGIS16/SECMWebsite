import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";

export const Route = createFileRoute("/about/")({
  component: AboutRoute,
});

function AboutRoute() {
  return <SectionPage path="/about" />;
}
