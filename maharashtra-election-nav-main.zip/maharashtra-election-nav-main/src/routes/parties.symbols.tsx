import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";

export const Route = createFileRoute("/parties/symbols")({
  component: PartiesSymbolsRoute,
});

function PartiesSymbolsRoute() {
  return <SectionPage path="/parties/symbols" />;
}
