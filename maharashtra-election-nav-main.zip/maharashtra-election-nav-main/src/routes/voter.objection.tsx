import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";

export const Route = createFileRoute("/voter/objection")({
  component: VoterObjectionRoute,
});

function VoterObjectionRoute() {
  return <SectionPage path="/voter/objection" />;
}
