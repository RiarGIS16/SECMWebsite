import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";
import { specHead } from "@/data/page-specs";

export const Route = createFileRoute("/feedback/accessibility")({
  head: () => specHead("/feedback/accessibility"),
  component: Routefeedbackaccessibility,
});

function Routefeedbackaccessibility() {
  return <SectionPage path="/feedback/accessibility" />;
}
