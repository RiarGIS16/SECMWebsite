import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";
import { specHead } from "@/data/page-specs";

export const Route = createFileRoute("/ro/handbooks")({
  head: () => specHead("/ro/handbooks"),
  component: Routerohandbooks,
});

function Routerohandbooks() {
  return <SectionPage path="/ro/handbooks" />;
}
