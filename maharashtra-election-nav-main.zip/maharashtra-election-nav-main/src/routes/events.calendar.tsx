import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";
import { specHead } from "@/data/page-specs";

export const Route = createFileRoute("/events/calendar")({
  head: () => specHead("/events/calendar"),
  component: Routeeventscalendar,
});

function Routeeventscalendar() {
  return <SectionPage path="/events/calendar" />;
}
