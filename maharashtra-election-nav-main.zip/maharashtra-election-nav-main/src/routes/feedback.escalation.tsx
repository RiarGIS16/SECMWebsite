import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";
import { specHead } from "@/data/page-specs";

export const Route = createFileRoute("/feedback/escalation")({
  head: () => specHead("/feedback/escalation"),
  component: Routefeedbackescalation,
});

function Routefeedbackescalation() {
  return <SectionPage path="/feedback/escalation" />;
}
