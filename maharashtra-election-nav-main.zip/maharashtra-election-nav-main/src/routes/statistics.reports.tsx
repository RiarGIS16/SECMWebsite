import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";
import { specHead } from "@/data/page-specs";

export const Route = createFileRoute("/statistics/reports")({
  head: () => specHead("/statistics/reports"),
  component: StatisticsReportsRoute,
});

function StatisticsReportsRoute() {
  return <SectionPage path="/statistics/reports" />;
}