import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";
import { specHead } from "@/data/page-specs";

export const Route = createFileRoute("/events/gallery")({
  head: () => specHead("/events/gallery"),
  component: Routeeventsgallery,
});

function Routeeventsgallery() {
  return <SectionPage path="/events/gallery" />;
}
