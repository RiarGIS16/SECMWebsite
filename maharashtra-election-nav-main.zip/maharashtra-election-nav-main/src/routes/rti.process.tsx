import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";
import { specHead } from "@/data/page-specs";

export const Route = createFileRoute("/rti/process")({
  head: () => specHead("/rti/process"),
  component: Routertiprocess,
});

function Routertiprocess() {
  return <SectionPage path="/rti/process" />;
}
