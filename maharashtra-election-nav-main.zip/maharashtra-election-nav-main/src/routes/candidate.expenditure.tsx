import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";

export const Route = createFileRoute("/candidate/expenditure")({
  component: CandidateExpenditureRoute,
});

function CandidateExpenditureRoute() {
  return <SectionPage path="/candidate/expenditure" />;
}
