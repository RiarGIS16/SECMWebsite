import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";
import { specHead } from "@/data/page-specs";

export const Route = createFileRoute("/evm/security")({
  head: () => specHead("/evm/security"),
  component: Routeevmsecurity,
});

function Routeevmsecurity() {
  return <SectionPage path="/evm/security" />;
}
