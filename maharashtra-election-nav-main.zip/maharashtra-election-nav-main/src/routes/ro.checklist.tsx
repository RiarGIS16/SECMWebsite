import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";

export const Route = createFileRoute("/ro/checklist")({
  component: RoChecklistRoute,
});

function RoChecklistRoute() {
  return <SectionPage path="/ro/checklist" />;
}
