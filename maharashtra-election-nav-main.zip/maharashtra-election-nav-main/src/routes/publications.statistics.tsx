import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";
import { specHead } from "@/data/page-specs";

export const Route = createFileRoute("/publications/statistics")({
  head: () => specHead("/publications/statistics"),
  component: Routepublicationsstatistics,
});

function Routepublicationsstatistics() {
  return <SectionPage path="/publications/statistics" />;
}
