import { createFileRoute } from "@tanstack/react-router";

import { SectionPage } from "@/components/layout/SectionPage";
import { specHead } from "@/data/page-specs";

export const Route = createFileRoute("/publications/manuals")({
  head: () => specHead("/publications/manuals"),
  component: Routepublicationsmanuals,
});

function Routepublicationsmanuals() {
  return <SectionPage path="/publications/manuals" />;
}
