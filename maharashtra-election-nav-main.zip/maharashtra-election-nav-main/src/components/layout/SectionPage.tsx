import { Link } from "@tanstack/react-router";
import { ArrowRight, Database, Filter, ListChecks, MousePointerClick } from "lucide-react";
import type { ReactNode } from "react";

import { DocumentRegister } from "@/components/common/DocumentRegister";
import { ServiceIcon } from "@/components/common/ServiceIcon";
import { PageShell, Section } from "@/components/layout/PageShell";
import { allDocuments, documentsForSection } from "@/data/documents";
import { aboutSection, importantStatisticsSection, navSections } from "@/data/navigation";
import { getPageSpec } from "@/data/page-specs";
import { useI18n } from "@/i18n/i18n";

/**
 * Generic connected page for a section route. It always shows where the page
 * sits in the hierarchy, its sibling services, and the slice of the document
 * register relevant to it — so no page in the site is a dead end.
 *
 * Where `data/page-specs.ts` declares a content model for the path, the page
 * also states exactly which fields, filters and actions the Commission's CMS
 * must supply. Official values are never invented here.
 */
export function SectionPage({ path }: { path: string }) {
  const { localised } = useI18n();
  const spec = getPageSpec(path);

  const section =
    [aboutSection, importantStatisticsSection, ...navSections].find(
      (s) => s.to === path || s.children.some((c) => c.to === path),
    ) ?? navSections[0]!;
  const child = section.children.find((c) => c.to === path);
  const title = spec?.title ?? child?.label ?? section.label;
  const intro = spec?.intro ?? child?.description ?? section.summary;

  // Official records published for this area take precedence; where the
  // Commission publishes no list for a section, the demo register is shown.
  const sectionKey = path.split("/")[1] ?? "";
  const official = documentsForSection(sectionKey);
  const records = official.length > 0 ? official : allDocuments;
  const isOfficial = official.length > 0;

  return (
    <PageShell
      title={title}
      intro={intro}
      crumbs={
        child ? [{ label: section.label, to: section.to }, { label: title }] : [{ label: title }]
      }
      governance={{
        owner: spec?.source ?? { en: "Election Operations Section (demo)", mr: "निवडणूक संचालन कक्ष (नमुना)" },
        lastVerified: "2026-02-18",
      }}
    >
      {spec && (
        <Section
          title={{ en: "What this page holds", mr: "या पृष्ठावर काय असेल" }}
          description={{
            en: "The record structure this service uses. Official values are supplied by the Commission's content system — nothing here is presented as verified data.",
            mr: "या सेवेची नोंद रचना. अधिकृत माहिती आयोगाच्या प्रणालीतून येईल — येथे कोणतीही माहिती पडताळलेली म्हणून दाखवलेली नाही.",
          }}
        >
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <SpecCard
              icon={<ListChecks aria-hidden="true" className="size-4" />}
              title={{ en: "Each record carries", mr: "प्रत्येक नोंदीत" }}
              items={spec.fields}
            />
            {spec.filters && spec.filters.length > 0 && (
              <SpecCard
                icon={<Filter aria-hidden="true" className="size-4" />}
                title={{ en: "Filters", mr: "गाळण्या" }}
                items={spec.filters}
              />
            )}
            {spec.actions && spec.actions.length > 0 && (
              <SpecCard
                icon={<MousePointerClick aria-hidden="true" className="size-4" />}
                title={{ en: "You can", mr: "आपण करू शकता" }}
                items={spec.actions}
              />
            )}
          </div>
          <p className="mt-4 flex items-start gap-2 rounded-md border border-warning bg-warning/15 px-3 py-2 text-sm">
            <Database aria-hidden="true" className="mt-0.5 size-4 shrink-0" />
            <span>
              {localised({
                en: "Awaiting official content from",
                mr: "अधिकृत माहितीची प्रतीक्षा —",
              })}{" "}
              <strong>{localised(spec.source)}</strong>.{" "}
              {localised({
                en: "Dates, officers, numbers and legal references will appear once that data is loaded.",
                mr: "दिनांक, अधिकारी, आकडे व कायदेशीर संदर्भ ती माहिती भरल्यावर दिसतील.",
              })}
            </span>
          </p>
        </Section>
      )}

      <Section
        title={{ en: "In this section", mr: "या विभागात" }}
        description={{
          en: "Every related service, kept together so a task can be finished in one place.",
          mr: "संबंधित सर्व सेवा एकत्र, जेणेकरून काम एकाच ठिकाणी पूर्ण होईल.",
        }}
      >
        <ul className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {section.children.map((item) => (
            <li key={item.to}>
              <Link
                to={item.to}
                className="flex h-full min-h-11 items-start justify-between gap-3 rounded-lg border bg-card p-4 hover:border-accent hover:shadow-sm"
                activeProps={{ className: "border-accent bg-surface" }}
                activeOptions={{ exact: true }}
              >
                <span className="flex min-w-0 items-start gap-3">
                  <span className="grid size-9 shrink-0 place-items-center rounded-md bg-primary/10 text-primary">
                    <ServiceIcon path={item.to} className="size-5" />
                  </span>
                  <span className="min-w-0">
                  <span className="block font-medium">{localised(item.label)}</span>
                  {item.description && (
                    <span className="mt-1 block text-sm text-muted-foreground">
                      {localised(item.description)}
                    </span>
                  )}
                  </span>
                </span>
                <ArrowRight aria-hidden="true" className="mt-1 size-4 shrink-0 text-accent" />
              </Link>
            </li>
          ))}
        </ul>
      </Section>

      <Section
        title={
          isOfficial
            ? { en: "Records published by the Commission", mr: "आयोगाने प्रकाशित केलेले दस्तऐवज" }
            : { en: "Related documents", mr: "संबंधित दस्तऐवज" }
        }
        description={
          isOfficial
            ? {
                en: "Records as published on the Commission's own site. Filter by category, election type, area and date; both endpoints of a date range are included.",
                mr: "आयोगाच्या संकेतस्थळावर प्रकाशित झालेले दस्तऐवज. वर्ग, निवडणूक प्रकार, क्षेत्र व दिनांकानुसार गाळा; दोन्ही दिनांक समाविष्ट.",
              }
            : {
                en: "Filter by category, election type, area and date. Both endpoints of a date range are included.",
                mr: "वर्ग, निवडणूक प्रकार, क्षेत्र व दिनांकानुसार गाळा. दिनांक कालावधीतील दोन्ही दिनांक समाविष्ट.",
              }
        }
      >
        <DocumentRegister records={records} />
      </Section>
    </PageShell>
  );
}

function SpecCard({
  icon,
  title,
  items,
}: {
  icon: ReactNode;
  title: { en: string; mr: string };
  items: string[];
}) {
  const { localised } = useI18n();
  return (
    <div className="rounded-lg border bg-card p-4">
      <h3 className="flex items-center gap-2 font-medium text-primary">
        {icon}
        {localised(title)}
      </h3>
      <ul className="mt-2 space-y-1 text-sm text-muted-foreground">
        {items.map((item) => (
          <li key={item} className="flex gap-2">
            <span aria-hidden="true">·</span>
            <span>{item}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}
