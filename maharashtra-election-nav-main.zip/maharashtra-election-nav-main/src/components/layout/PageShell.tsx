import { Link } from "@tanstack/react-router";
import { ChevronRight } from "lucide-react";
import type { ReactNode } from "react";

import { useI18n } from "@/i18n/i18n";
import type { Localised } from "@/i18n/i18n";
import { cn } from "@/lib/utils";

export type Crumb = { label: Localised; to?: string };

type Props = {
  title: Localised;
  intro?: Localised;
  crumbs?: Crumb[];
  /** Rendered to the right of the title on wide screens (filters count, actions). */
  actions?: ReactNode;
  /** Optional context strip: owner / last verified — content governance. */
  governance?: { owner: Localised; lastVerified: string; reviewCycle?: string };
  children: ReactNode;
  className?: string;
};

/**
 * Standard page frame: breadcrumb, one H1, an intro paragraph, and a governance
 * strip. Keeping every page on this shell is what gives the site the consistent
 * heading hierarchy and "who owns this page / when was it checked" metadata the
 * audit asks for.
 */
export function PageShell({
  title,
  intro,
  crumbs = [],
  actions,
  governance,
  children,
  className,
}: Props) {
  const { t, localised, formatDate } = useI18n();

  return (
    <div className={cn("mx-auto max-w-7xl px-4 py-6 sm:py-8", className)}>
      <nav aria-label={t("site.breadcrumb")} className="mb-4">
        <ol className="flex flex-wrap items-center gap-1 text-sm text-muted-foreground">
          <li>
            <Link to="/" className="hover:text-foreground hover:underline">
              {t("nav.home")}
            </Link>
          </li>
          {crumbs.map((crumb, index) => {
            const last = index === crumbs.length - 1;
            return (
              <li key={`${localised(crumb.label)}-${index}`} className="flex items-center gap-1">
                <ChevronRight aria-hidden="true" className="size-3.5" />
                {crumb.to && !last ? (
                  <Link to={crumb.to} className="hover:text-foreground hover:underline">
                    {localised(crumb.label)}
                  </Link>
                ) : (
                  <span aria-current={last ? "page" : undefined} className="text-foreground">
                    {localised(crumb.label)}
                  </span>
                )}
              </li>
            );
          })}
        </ol>
      </nav>

      <div className="flex flex-wrap items-end justify-between gap-4 border-b pb-5">
        <div className="max-w-3xl">
          <h1 className="font-display text-2xl font-bold text-balance text-primary sm:text-3xl">
            {localised(title)}
          </h1>
          {intro && <p className="mt-2 text-muted-foreground">{localised(intro)}</p>}
        </div>
        {actions}
      </div>

      {governance && (
        <p className="mt-3 text-xs text-muted-foreground">
          {localised({ en: "Page owner", mr: "पृष्ठ जबाबदारी" })}: {localised(governance.owner)} ·{" "}
          {localised({ en: "Last verified", mr: "शेवटची पडताळणी" })}:{" "}
          {formatDate(governance.lastVerified)}
          {governance.reviewCycle ? ` · ${governance.reviewCycle}` : ""}
        </p>
      )}

      <div className="mt-6">{children}</div>
    </div>
  );
}

/** Small labelled section used inside pages so H2 order stays predictable. */
export function Section({
  title,
  description,
  children,
  id,
  actions,
}: {
  title: Localised;
  description?: Localised;
  children: ReactNode;
  id?: string;
  actions?: ReactNode;
}) {
  const { localised } = useI18n();
  return (
    <section id={id} className="mt-10 first:mt-0">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="font-display text-xl font-bold">{localised(title)}</h2>
          {description && (
            <p className="mt-1 max-w-3xl text-sm text-muted-foreground">{localised(description)}</p>
          )}
        </div>
        {actions}
      </div>
      <div className="mt-4">{children}</div>
    </section>
  );
}
