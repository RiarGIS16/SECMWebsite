import { Link } from "@tanstack/react-router";

import { SmartLink } from "@/components/common/SmartLink";
import { aboutSection, importantStatisticsSection, navSections } from "@/data/navigation";
import { useI18n } from "@/i18n/i18n";

/**
 * Footer. Repeats the full hierarchy (so every page exposes the whole site),
 * carries the accessibility/help statements GIGW expects, and publishes the
 * content-governance line the workbook asks for (owner + last reviewed).
 */
export function SiteFooter() {
  const { t, localised, formatDate } = useI18n();

  return (
    <footer className="mt-16 border-t bg-surface">
      <div className="state-rule h-1" aria-hidden="true" />
      <div className="mx-auto max-w-7xl px-4 py-10">
        <nav aria-label={localised({ en: "Footer", mr: "तळटीप" })}>
          <ul className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
            {[aboutSection, importantStatisticsSection, ...navSections].map((section) => (
              <li key={section.id}>
                <h2 className="font-display text-sm font-bold tracking-wide uppercase text-primary">
                  <Link to={section.to} className="hover:underline">
                    {localised(section.label)}
                  </Link>
                </h2>
                <ul className="mt-3 space-y-2">
                  {section.children.map((child) => (
                    <li key={child.to}>
                      <Link
                        to={child.to}
                        className="text-sm text-muted-foreground hover:text-foreground hover:underline"
                      >
                        {localised(child.label)}
                      </Link>
                    </li>
                  ))}
                </ul>
              </li>
            ))}
          </ul>
        </nav>

        <div className="mt-10 grid gap-6 border-t pt-6 sm:grid-cols-2">
          <div>
            <h2 className="text-sm font-semibold">
              {localised({ en: "Accessibility", mr: "सुलभता" })}
            </h2>
            <p className="mt-2 text-sm text-muted-foreground">
              {localised({
                en: "This prototype targets WCAG 2.1 AA and GIGW 3.0: keyboard operable, resizable text, high-contrast mode, described links and HTML alternatives for critical PDFs.",
                mr: "हे नमुना संकेतस्थळ WCAG 2.1 AA व GIGW 3.0 नुसार तयार केले आहे: कीबोर्डने वापरता येते, अक्षर आकार बदलता येतो, उच्च कॉन्ट्रास्ट व महत्त्वाच्या पीडीएफसाठी एचटीएमएल पर्याय.",
              })}
            </p>
            <ul className="mt-3 flex flex-wrap gap-x-4 gap-y-2 text-sm">
              <li>
                <Link to="/accessibility" className="underline hover:no-underline">
                  {localised({ en: "Accessibility statement", mr: "सुलभता निवेदन" })}
                </Link>
              </li>
              <li>
                <Link to="/sitemap" className="underline hover:no-underline">
                  {localised({ en: "Sitemap", mr: "साइटमॅप" })}
                </Link>
              </li>
              <li>
                <Link to="/feedback" className="underline hover:no-underline">
                  {localised({ en: "Report a problem", mr: "अडचण कळवा" })}
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h2 className="text-sm font-semibold">
              {localised({ en: "Related official sites", mr: "संबंधित अधिकृत संकेतस्थळे" })}
            </h2>
            <ul className="mt-3 space-y-2 text-sm">
              <li>
                <SmartLink href="https://www.eci.gov.in">
                  {localised({ en: "Election Commission of India", mr: "भारत निवडणूक आयोग" })}
                </SmartLink>
              </li>
              <li>
                <SmartLink href="https://www.maharashtra.gov.in">
                  {localised({ en: "Government of Maharashtra", mr: "महाराष्ट्र शासन" })}
                </SmartLink>
              </li>
              <li>
                <SmartLink href="https://www.india.gov.in">
                  {localised({ en: "National Portal of India", mr: "भारताचे राष्ट्रीय पोर्टल" })}
                </SmartLink>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-8 space-y-2 border-t pt-6 text-xs text-muted-foreground">
          <p className="font-medium text-foreground">{t("site.demoBanner")}</p>
          <p>
            {localised({ en: "Content owner", mr: "मजकूर जबाबदारी" })}: {localised({
              en: "Information & Communication Section (demo)",
              mr: "माहिती व संपर्क कक्ष (नमुना)",
            })}{" "}
            · {t("ui.updated")}: {formatDate("2026-02-18")} ·{" "}
            {localised({ en: "Review cycle: monthly", mr: "आढावा कालावधी: मासिक" })}
          </p>
          <p>
            © {new Date().getFullYear()} {t("site.org")}, {t("site.state")}.{" "}
            {localised({
              en: "Prototype for evaluation purposes only.",
              mr: "केवळ मूल्यमापनासाठी तयार केलेला नमुना.",
            })}
          </p>
        </div>
      </div>
    </footer>
  );
}
