import { Link, useRouterState } from "@tanstack/react-router";
import { ChevronDown, Menu, Pause, Volume2 } from "lucide-react";
import * as React from "react";
import { toast } from "sonner";

import { GlobalSearch } from "@/components/common/GlobalSearch";
import { Button } from "@/components/ui/button";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  aboutSection,
  importantStatisticsSection,
  navSections,
  primaryNavSections,
  remainingPrimaryLinks,
  type NavSection,
} from "@/data/navigation";
import { LOCALE_LABELS, LOCALES } from "@/i18n/dictionary";
import { useI18n } from "@/i18n/i18n";
import { cn } from "@/lib/utils";
import secLogo from "@/assets/sec-maharashtra-logo.png.asset.json";
import nationalEmblem from "@/assets/national-emblem-india.png.asset.json";

/**
 * Masthead + navigation.
 *
 * Addresses: language switch on every page (rows 8, 9 — GIGW 3.0 multilingual),
 * a single unified hierarchy instead of scattered entry points (rows 1, 6, 75),
 * a working mobile navigation, and the accessibility controls GIGW expects
 * (text resize, high contrast, skip links).
 */

function useAccessibilityControls(onAnnounce: (message: string) => void) {
  const [scale, setScale] = React.useState(100);
  const [contrast, setContrast] = React.useState(false);

  React.useEffect(() => {
    document.documentElement.style.fontSize = `${scale}%`;
  }, [scale]);

  React.useEffect(() => {
    document.documentElement.classList.toggle("dark", contrast);
  }, [contrast]);

  const changeScale = (nextScale: number) => {
    setScale(nextScale);
    onAnnounce(`Text size adjusted to ${nextScale} percent.`);
  };

  const changeContrast = (enabled: boolean) => {
    setContrast(enabled);
    onAnnounce(enabled ? "High contrast mode active." : "Standard contrast mode active.");
  };

  return { scale, changeScale, contrast, changeContrast };
}

export function SiteHeader() {
  const { t, localised, locale, setLocale } = useI18n();
  const [announcement, setAnnouncement] = React.useState("");
  const announce = React.useCallback((message: string) => setAnnouncement(message), []);
  const { scale, changeScale, contrast, changeContrast } = useAccessibilityControls(announce);
  const [mobileOpen, setMobileOpen] = React.useState(false);
  const [now, setNow] = React.useState<Date | null>(null);
  const [reading, setReading] = React.useState(false);

  React.useEffect(() => {
    setNow(new Date());
    const timer = window.setInterval(() => setNow(new Date()), 1000);
    return () => window.clearInterval(timer);
  }, []);

  React.useEffect(() => () => window.speechSynthesis?.cancel(), []);

  const changeLanguage = (code: (typeof LOCALES)[number]) => {
    setLocale(code);
    announce(code === "mr" ? "Language switched to Marathi." : "Language switched to English.");
  };

  const toggleReading = () => {
    if (!("speechSynthesis" in window)) {
      announce("Audio reading is not supported by this browser.");
      return;
    }
    if (reading) {
      window.speechSynthesis.cancel();
      setReading(false);
      announce("Page reading stopped.");
      return;
    }
    const content = document.getElementById("main-content")?.innerText.trim();
    if (!content) {
      announce("No page content is available to read.");
      return;
    }
    const utterance = new SpeechSynthesisUtterance(content);
    utterance.lang = locale === "mr" ? "mr-IN" : "en-IN";
    utterance.onend = () => {
      setReading(false);
      announce("Page reading finished.");
    };
    utterance.onerror = () => {
      setReading(false);
      announce("Page reading stopped.");
    };
    window.speechSynthesis.speak(utterance);
    setReading(true);
    announce("Page reading started.");
  };

  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const aboutActive = pathname === "/about" || pathname.startsWith("/about/");
  const statisticsActive = pathname === "/statistics" || pathname.startsWith("/statistics/");
  const activeSection = navSections.find(
    (section) => pathname === section.to || pathname.startsWith(`${section.to}/`),
  );
  const subNav = aboutActive ? aboutSection : statisticsActive ? importantStatisticsSection : activeSection;

  return (
    <header className="sticky top-0 z-40 border-b bg-background/95 shadow-sm backdrop-blur supports-[backdrop-filter]:bg-background/85">
      <p className="sr-only" role="status" aria-live="polite" aria-atomic="true">
        {announcement}
      </p>
      {/* Utility bar: accessibility + language */}
      <div className="border-b bg-utility text-utility-foreground">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-2 px-4 py-1.5 text-xs">
          <div className="flex min-h-9 items-center gap-3">
            <GlobalSearch compact />
            <time dateTime={now?.toISOString()} className="hidden whitespace-nowrap font-medium tabular-nums sm:inline">
              {now
                ? new Intl.DateTimeFormat(locale === "mr" ? "mr-IN" : "en-IN", {
                    timeZone: "Asia/Kolkata",
                    dateStyle: "medium",
                    timeStyle: "medium",
                  }).format(now)
                : localised({ en: "India Standard Time", mr: "भारतीय प्रमाण वेळ" })}
            </time>
          </div>
          <div className="flex flex-wrap items-center justify-end gap-1" role="group" aria-label="Website utility controls">
            <a href="#main-nav" className="hidden min-h-9 items-center px-2 font-medium underline-offset-4 hover:underline focus-visible:outline-3 md:flex">
              {t("site.skipToNav")}
            </a>
            <a href="#main-content" className="hidden min-h-9 items-center px-2 font-medium underline-offset-4 hover:underline focus-visible:outline-3 md:flex">
              {t("site.skipToContent")}
            </a>
            <Button
              size="icon"
              variant="ghost"
              aria-label={reading ? "Stop reading page aloud" : "Read page aloud with screen reader audio"}
              aria-pressed={reading}
              className="size-9 text-utility-foreground hover:bg-foreground/10 hover:text-utility-foreground"
              onClick={toggleReading}
            >
              {reading ? <Pause aria-hidden="true" /> : <Volume2 aria-hidden="true" />}
            </Button>
            <div role="group" aria-label={t("site.textSize")} className="flex items-center">
            <Button
              variant="ghost"
              aria-label={t("site.decreaseText")}
              className="size-9 px-1 text-xs text-utility-foreground hover:bg-foreground/10 hover:text-utility-foreground"
              onClick={() => changeScale(Math.max(85, scale - 10))}
            >
              A−
            </Button>
            <Button
              variant="ghost"
              aria-label={`${t("site.resetText")}; current size ${scale} percent`}
              className="size-9 px-1 text-sm text-utility-foreground hover:bg-foreground/10 hover:text-utility-foreground"
              onClick={() => changeScale(100)}
            >
              A
            </Button>
            <Button
              variant="ghost"
              aria-label={t("site.increaseText")}
              className="size-9 px-1 text-base text-utility-foreground hover:bg-foreground/10 hover:text-utility-foreground"
              onClick={() => changeScale(Math.min(140, scale + 10))}
            >
              A+
            </Button>
            </div>
            <div role="group" aria-label="Display contrast" className="flex items-center gap-1">
            <Button
              variant="outline"
              aria-label="Use standard contrast"
              aria-pressed={!contrast}
              className="size-9 border-foreground/40 bg-background p-0 text-foreground hover:bg-muted"
              onClick={() => changeContrast(false)}
            >
              A
            </Button>
            <Button
              aria-label="Use high contrast inverted display"
              aria-pressed={contrast}
              className="size-9 p-0"
              onClick={() => changeContrast(true)}
            >
              A
            </Button>
            </div>
            <div
              role="group"
              aria-label={t("site.switchLanguage")}
              className="ml-1 flex overflow-hidden rounded border border-foreground/30"
            >
              {LOCALES.map((code) => (
                <Button
                  key={code}
                  variant="ghost"
                  lang={code === "mr" ? "mr-IN" : "en-IN"}
                  aria-label={code === "mr" ? "Switch language to Marathi" : "Switch language to English"}
                  aria-pressed={locale === code}
                  onClick={() => changeLanguage(code)}
                  className={cn(
                    "min-h-9 rounded-none px-2.5 py-1 text-utility-foreground transition-colors hover:bg-foreground/10 hover:text-utility-foreground",
                    locale === code
                      ? "bg-foreground/10 font-semibold"
                      : "",
                  )}
                >
                  {LOCALE_LABELS[code]}
                </Button>
              ))}
            </div>
            <Button
              className="ml-1 min-h-9 bg-utility-action text-utility-action-foreground hover:bg-utility-action/85"
              aria-label="Login to secure services; demonstration only"
              onClick={() => toast.info("Login is not enabled in this demonstration prototype.")}
            >
              {localised({ en: "Login", mr: "लॉग इन" })}
            </Button>
          </div>
        </div>
      </div>

      {/* Masthead */}
      <div className="bg-masthead text-masthead-foreground">
        <div className="mx-auto grid min-h-28 max-w-[100rem] grid-cols-[5rem_1fr_4rem] items-center gap-3 px-4 py-3 sm:min-h-36 sm:grid-cols-[9rem_1fr_6rem] sm:gap-8 sm:px-8">
          <Link to="/" className="justify-self-start rounded-md" aria-label={`${t("site.org")}, ${t("site.state")} home`}>
            <img src={secLogo.url} alt="State Election Commission Maharashtra logo" className="h-auto w-20 sm:w-32" />
          </Link>
          <div className="min-w-0 text-center">
            <span className="block font-sans text-xl leading-tight font-bold text-masthead-foreground sm:text-4xl">
              {t("site.org")}
            </span>
            <span className="mt-1 block font-sans text-base leading-tight text-masthead-foreground sm:text-3xl">{t("site.state")}</span>
          </div>
          <img src={nationalEmblem.url} alt="National Emblem of India, Lion Capital of Ashoka" className="h-20 w-auto justify-self-end object-contain sm:h-28" />
        </div>
      </div>

      <div className="flex justify-end border-t border-navigation-foreground/20 bg-navigation px-4 py-1 text-navigation-foreground xl:hidden">
          <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="size-11 text-navigation-foreground hover:bg-navigation-foreground/15 hover:text-navigation-foreground xl:hidden" aria-label={t("site.openMenu")}>
                <Menu aria-hidden="true" className="size-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[min(22rem,92vw)] overflow-y-auto">
              <SheetHeader>
                <SheetTitle>{t("site.mainNav")}</SheetTitle>
              </SheetHeader>
              <div className="px-4 pb-8">
                <div className="mb-4 sm:hidden">
                  <GlobalSearch />
                </div>
                <div className="mb-3">
                  <Link
                    to="/"
                    onClick={() => setMobileOpen(false)}
                    className="flex min-h-11 items-center rounded-md border px-3 text-base font-medium hover:bg-muted"
                    activeOptions={{ exact: true }}
                    activeProps={{ className: "bg-muted font-semibold" }}
                  >
                    {t("nav.home")}
                  </Link>
                </div>
                <Accordion type="multiple" className="w-full">
                   {[...primaryNavSections, ...remainingPrimaryLinks].map((section) => (
                    <AccordionItem key={section.id} value={section.id}>
                      <AccordionTrigger className="min-h-11 text-left text-base">
                        {localised(section.label)}
                      </AccordionTrigger>
                      <AccordionContent>
                        <ul className="space-y-1">
                          {section.children.map((child) => (
                            <li key={child.to}>
                              <Link
                                to={child.to}
                                onClick={() => setMobileOpen(false)}
                                className="block min-h-11 rounded-md px-3 py-2.5 text-sm hover:bg-muted"
                                activeProps={{ className: "bg-muted font-semibold" }}
                              >
                                {localised(child.label)}
                              </Link>
                            </li>
                          ))}
                        </ul>
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </div>
            </SheetContent>
          </Sheet>
      </div>

      {/* Primary navigation */}
       <nav aria-label={t("site.mainNav")} id="main-nav" className="hidden border-t border-navigation-foreground/20 bg-navigation text-navigation-foreground xl:block">
         <ul className="mx-auto flex max-w-[100rem] items-stretch justify-center px-4">
          <li>
            <Link
              to="/"
                className="flex min-h-11 items-center px-3 text-sm font-medium text-navigation-foreground hover:bg-navigation-foreground/15"
              activeOptions={{ exact: true }}
               activeProps={{ className: "border-b-3 border-accent font-semibold" }}
            >
              {t("nav.home")}
            </Link>
          </li>
           {primaryNavSections.map((section) => (
            <li key={section.id}>
               <DesktopSectionMenu section={section} pathname={pathname} />
            </li>
          ))}
           {remainingPrimaryLinks.map((section) => (
             <li key={section.id}>
               <Link
                 to={section.to}
                  className="flex min-h-11 items-center px-3 text-sm font-medium text-navigation-foreground hover:bg-navigation-foreground/15"
                  activeProps={{ className: "border-b-3 border-accent font-semibold" }}
               >
                 {localised(section.label)}
               </Link>
             </li>
           ))}
        </ul>
      </nav>

      {/* Contextual sub-navigation for the active section */}
      {subNav && subNav.children.length > 1 && (
        <nav
          aria-label={localised(subNav.label)}
           className="hidden border-t bg-background xl:block"
        >
          <ul className="mx-auto flex max-w-7xl flex-wrap items-center gap-x-1 px-4 py-1">
            {subNav.children.map((child) => (
              <li key={child.to}>
                <Link
                  to={child.to}
                  className="flex min-h-9 items-center rounded px-2.5 text-sm text-muted-foreground hover:text-foreground"
                  activeOptions={{ exact: true }}
                  activeProps={{ className: "text-foreground font-semibold" }}
                >
                  {localised(child.label)}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
      )}
    </header>
  );
}

function DesktopSectionMenu({ section, pathname }: { section: NavSection; pathname: string }) {
  const { localised } = useI18n();
  const active = pathname === section.to || pathname.startsWith(`${section.to}/`);

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="ghost"
          className={cn(
            "min-h-11 rounded-none px-3 text-sm font-medium text-navigation-foreground hover:bg-navigation-foreground/15 hover:text-navigation-foreground",
            active && "border-b-3 border-accent font-semibold",
          )}
          aria-label={`${localised(section.label)} ${localised({ en: "menu", mr: "मेनू" })}`}
        >
          {localised(section.label)}
          <ChevronDown aria-hidden="true" className="size-3.5" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="start" className="w-80">
        {section.children.map((child) => (
          <DropdownMenuItem key={child.to} asChild>
            <Link to={child.to} activeProps={{ className: "font-semibold" }} activeOptions={{ exact: true }}>
              {localised(child.label)}
            </Link>
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
