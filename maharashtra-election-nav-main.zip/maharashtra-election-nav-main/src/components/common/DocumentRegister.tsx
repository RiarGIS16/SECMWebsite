import {
  AlertTriangle,
  CheckCircle2,
  Download,
  FileText,
  Filter,
  History,
  Search,
} from "lucide-react";
import * as React from "react";

import { AreaFilter, emptyArea, matchesArea, type AreaSelection } from "@/components/common/AreaFilter";
import { DateRangeFilter } from "@/components/common/DateRangeFilter";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { documentTypeLabels, stageLabels } from "@/data/documents";
import type { DocumentRecord, DocumentType, ProcessStage } from "@/data/types";
import { useI18n } from "@/i18n/i18n";
import { dateBounds, filterByDateInclusive, normaliseRange, type DateRange } from "@/lib/date-range";
import { cn } from "@/lib/utils";

/**
 * Reusable document register.
 *
 * Covers a large block of the audit at once: type/category filter with live
 * counts (rows 1–5), inclusive date filtering (rows 17–20), area-aware results
 * (rows 8, 9), visible issuing authority, reference number, version and
 * supersession chain (rows 22, 41, 54), and an explicit accessibility state for
 * every PDF with an HTML alternative where one exists (row 56).
 */

const priorityStyles: Record<DocumentRecord["priority"], string> = {
  critical: "border-destructive/40 bg-destructive/10 text-destructive",
  important: "border-accent/50 bg-accent/15 text-accent-foreground",
  routine: "border-border bg-muted text-muted-foreground",
};

const priorityLabels = {
  critical: { en: "Action required", mr: "कार्यवाही आवश्यक" },
  important: { en: "Important", mr: "महत्त्वाचे" },
  routine: { en: "For information", mr: "माहितीसाठी" },
} as const;

export type RegisterProps = {
  records: DocumentRecord[];
  /** Restrict the type dropdown to these types. */
  types?: DocumentType[];
  /** Restrict the stage dropdown to these stages; omit to hide the control. */
  stages?: ProcessStage[];
  showArea?: boolean;
  showStatus?: boolean;
  emptyHint?: string;
  className?: string;
};

export function DocumentRegister({
  records,
  types,
  stages,
  showArea = true,
  showStatus = true,
  className,
}: RegisterProps) {
  const { t, localised, formatDate } = useI18n();

  const [query, setQuery] = React.useState("");
  const [type, setType] = React.useState<string>("all");
  const [stage, setStage] = React.useState<string>("all");
  const [status, setStatus] = React.useState<string>("current");
  const [scope, setScope] = React.useState<string>("all");
  const [range, setRange] = React.useState<DateRange>({});
  const [area, setArea] = React.useState<AreaSelection>(emptyArea);
  const [showFilters, setShowFilters] = React.useState(false);

  const availableTypes = React.useMemo(
    () => types ?? Array.from(new Set(records.map((r) => r.type))),
    [types, records],
  );

  const bounds = React.useMemo(
    () => dateBounds(records.map((r) => r.publishedOn)),
    [records],
  );

  const results = React.useMemo(() => {
    const q = query.trim().toLowerCase();
    const byRange = filterByDateInclusive(records, (r: DocumentRecord) => r.publishedOn, normaliseRange(range));
    return byRange.filter((record) => {
      if (type !== "all" && record.type !== type) return false;
      if (stage !== "all" && !record.stages.includes(stage as ProcessStage)) return false;
      if (status !== "all" && record.status !== status) return false;
      if (scope !== "all" && record.scope !== scope && record.scope !== "both") return false;
      if (!matchesArea(area, record)) return false;
      if (!q) return true;
      const haystack = [
        localised(record.title),
        localised(record.summary),
        record.referenceNo,
        localised(record.issuingAuthority),
        ...record.keywords,
      ]
        .join(" ")
        .toLowerCase();
      return haystack.includes(q);
    });
  }, [records, query, type, stage, status, scope, range, area, localised]);

  // Live counts per type against everything except the type filter itself.
  const typeCounts = React.useMemo(() => {
    const counts: Record<string, number> = {};
    for (const record of records) counts[record.type] = (counts[record.type] ?? 0) + 1;
    return counts;
  }, [records]);

  const reset = () => {
    setQuery("");
    setType("all");
    setStage("all");
    setStatus("current");
    setScope("all");
    setRange({});
    setArea(emptyArea);
  };

  return (
    <div className={cn("space-y-6", className)}>
      <div className="rounded-lg border bg-surface p-4 sm:p-5">
        <div className="flex flex-wrap items-end gap-3">
          <div className="min-w-0 flex-1 space-y-1.5">
            <Label htmlFor="register-q" className="text-sm font-medium">
              {t("notices.searchLabel")}
            </Label>
            <div className="relative">
              <Search
                aria-hidden="true"
                className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground"
              />
              <Input
                id="register-q"
                type="search"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder={localised({
                  en: "Title, reference number or keyword",
                  mr: "शीर्षक, संदर्भ क्रमांक किंवा शब्द",
                })}
                className="min-h-11 bg-card pl-9"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="register-type" className="text-sm font-medium">
              {t("notices.category")}
            </Label>
            <Select value={type} onValueChange={setType}>
              <SelectTrigger id="register-type" className="min-h-11 w-full bg-card sm:w-64">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">
                  {t("notices.allCategories")} ({records.length})
                </SelectItem>
                {availableTypes.map((item) => (
                  <SelectItem key={item} value={item}>
                    {localised(documentTypeLabels[item])} ({typeCounts[item] ?? 0})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <Button
            type="button"
            variant="outline"
            className="min-h-11"
            aria-expanded={showFilters}
            aria-controls="register-filters"
            onClick={() => setShowFilters((v) => !v)}
          >
            <Filter aria-hidden="true" className="size-4" />
            {localised({ en: "More filters", mr: "अधिक गाळण्या" })}
          </Button>
        </div>

        {showFilters && (
          <div id="register-filters" className="mt-5 space-y-5 border-t pt-5">
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {stages && (
                <div className="space-y-1.5">
                  <Label htmlFor="register-stage" className="text-sm font-medium">
                    {localised({ en: "Process stage", mr: "प्रक्रियेचा टप्पा" })}
                  </Label>
                  <Select value={stage} onValueChange={setStage}>
                    <SelectTrigger id="register-stage" className="min-h-11 w-full bg-card">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">{localised({ en: "All stages", mr: "सर्व टप्पे" })}</SelectItem>
                      {stages.map((item) => (
                        <SelectItem key={item} value={item}>
                          {localised(stageLabels[item])}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              <div className="space-y-1.5">
                <Label htmlFor="register-scope" className="text-sm font-medium">
                  {localised({ en: "Election type", mr: "निवडणूक प्रकार" })}
                </Label>
                <Select value={scope} onValueChange={setScope}>
                  <SelectTrigger id="register-scope" className="min-h-11 w-full bg-card">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">{localised({ en: "All", mr: "सर्व" })}</SelectItem>
                    <SelectItem value="urban">
                      {localised({ en: "Urban local bodies", mr: "नागरी स्थानिक संस्था" })}
                    </SelectItem>
                    <SelectItem value="rural">
                      {localised({ en: "Rural local bodies", mr: "ग्रामीण स्थानिक संस्था" })}
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {showStatus && (
                <div className="space-y-1.5">
                  <Label htmlFor="register-status" className="text-sm font-medium">
                    {localised({ en: "Version status", mr: "आवृत्ती स्थिती" })}
                  </Label>
                  <Select value={status} onValueChange={setStatus}>
                    <SelectTrigger id="register-status" className="min-h-11 w-full bg-card">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="current">
                        {localised({ en: "In force", mr: "अंमलात" })}
                      </SelectItem>
                      <SelectItem value="superseded">
                        {localised({ en: "Superseded", mr: "अधिक्रमित" })}
                      </SelectItem>
                      <SelectItem value="archived">
                        {localised({ en: "Archived", mr: "संग्रहित" })}
                      </SelectItem>
                      <SelectItem value="all">{localised({ en: "All versions", mr: "सर्व आवृत्त्या" })}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              )}
            </div>

            <DateRangeFilter value={range} onChange={setRange} bounds={bounds} idPrefix="register" />

            {showArea && <AreaFilter value={area} onChange={setArea} depth="localBody" idPrefix="register-area" />}
          </div>
        )}
      </div>

      <div className="flex flex-wrap items-center justify-between gap-3">
        <p aria-live="polite" className="text-sm">
          <span className="font-semibold">{results.length}</span>{" "}
          {results.length === 1 ? t("search.countOne") : t("search.countMany")}{" "}
          <span className="text-muted-foreground">
            {t("ui.of")} {records.length}
          </span>
        </p>
        <Button type="button" variant="ghost" size="sm" className="min-h-9" onClick={reset}>
          {t("ui.reset")}
        </Button>
      </div>

      {results.length === 0 ? (
        <div className="rounded-lg border border-dashed p-8 text-center">
          <p className="font-medium">{t("ui.noRecords")}</p>
          <p className="mt-1 text-sm text-muted-foreground">{t("search.noResultsHint")}</p>
        </div>
      ) : (
        <ul className="space-y-4">
          {results.map((record) => (
            <li key={record.id}>
              <article className="rounded-lg border bg-card p-4 transition-shadow hover:shadow-sm sm:p-5">
                <div className="flex flex-wrap items-center gap-2">
                  <Badge variant="outline">{localised(documentTypeLabels[record.type])}</Badge>
                  <span
                    className={cn(
                      "rounded-full border px-2 py-0.5 text-xs font-medium",
                      priorityStyles[record.priority],
                    )}
                  >
                    {localised(priorityLabels[record.priority])}
                  </span>
                  {record.status !== "current" && (
                    <span className="flex items-center gap-1 rounded-full border border-warning bg-warning/15 px-2 py-0.5 text-xs">
                      <History aria-hidden="true" className="size-3" />
                      {record.status === "superseded"
                        ? localised({ en: "Superseded", mr: "अधिक्रमित" })
                        : localised({ en: "Archived", mr: "संग्रहित" })}
                    </span>
                  )}
                </div>

                <h3 className="mt-2 font-display text-lg leading-snug font-semibold">
                  {localised(record.title)}
                </h3>
                <p className="mt-1 text-sm text-muted-foreground">{localised(record.summary)}</p>

                <dl className="mt-3 grid gap-x-6 gap-y-1 text-xs text-muted-foreground sm:grid-cols-2 lg:grid-cols-3">
                  <div className="flex gap-1">
                    <dt className="font-medium">{localised({ en: "Issued by", mr: "जारीकर्ता" })}:</dt>
                    <dd>{localised(record.issuingAuthority)}</dd>
                  </div>
                  <div className="flex gap-1">
                    <dt className="font-medium">{localised({ en: "Reference", mr: "संदर्भ" })}:</dt>
                    <dd className="font-mono">{record.referenceNo}</dd>
                  </div>
                  <div className="flex gap-1">
                    <dt className="font-medium">{t("ui.published")}:</dt>
                    <dd>{formatDate(record.publishedOn)}</dd>
                  </div>
                  {record.effectiveFrom && (
                    <div className="flex gap-1">
                      <dt className="font-medium">
                        {localised({ en: "Effective from", mr: "प्रभावी दिनांक" })}:
                      </dt>
                      <dd>{formatDate(record.effectiveFrom)}</dd>
                    </div>
                  )}
                  <div className="flex gap-1">
                    <dt className="font-medium">{localised({ en: "Version", mr: "आवृत्ती" })}:</dt>
                    <dd>
                      {record.version}
                      {record.supersedes ? ` (${localised({ en: "replaces", mr: "बदलते" })} ${record.supersedes})` : ""}
                    </dd>
                  </div>
                  <div className="flex gap-1">
                    <dt className="font-medium">{localised({ en: "Owner", mr: "जबाबदारी" })}:</dt>
                    <dd>{localised(record.governance.owner)}</dd>
                  </div>
                </dl>

                <div className="mt-4 flex flex-wrap items-center gap-2">
                  {record.sourceUrl ? (
                    <Button size="sm" className="min-h-10" asChild>
                      <a href={record.sourceUrl} target="_blank" rel="noreferrer">
                        <Download aria-hidden="true" className="size-4" />
                        {t("ui.download")} {record.format.toUpperCase()}
                        {record.sizeKb ? ` · ${record.sizeKb} KB` : ""}
                        <span className="sr-only">
                          {" "}
                          — {localised(record.title)}{" "}
                          {localised({ en: "(opens in a new tab)", mr: "(नवीन टॅबमध्ये उघडते)" })}
                        </span>
                      </a>
                    </Button>
                  ) : (
                    <Button
                      type="button"
                      size="sm"
                      className="min-h-10"
                      onClick={() =>
                        alert(
                          localised({
                            en: `Demo prototype — the file for ${record.referenceNo} is not attached. In the live site this downloads the published ${record.format.toUpperCase()}.`,
                            mr: `नमुना संकेतस्थळ — ${record.referenceNo} ची फाइल जोडलेली नाही. प्रत्यक्ष संकेतस्थळावर येथून ${record.format.toUpperCase()} डाउनलोड होईल.`,
                          }),
                        )
                      }
                    >
                      <Download aria-hidden="true" className="size-4" />
                      {t("ui.download")} {record.format.toUpperCase()}
                      {record.sizeKb ? ` · ${record.sizeKb} KB` : ""}
                      <span className="sr-only"> — {localised(record.title)}</span>
                    </Button>
                  )}

                  {record.htmlAlternative && (
                    <Button type="button" size="sm" variant="outline" className="min-h-10" asChild>
                      <a href={record.htmlAlternative}>
                        <FileText aria-hidden="true" className="size-4" />
                        {localised({ en: "Read as web page", mr: "वेब पृष्ठ म्हणून वाचा" })}
                        <span className="sr-only"> — {localised(record.title)}</span>
                      </a>
                    </Button>
                  )}

                  <span
                    className={cn(
                      "ml-auto flex items-center gap-1 text-xs",
                      record.accessiblePdf ? "text-success" : "text-warning-foreground",
                    )}
                  >
                    {record.accessiblePdf ? (
                      <CheckCircle2 aria-hidden="true" className="size-3.5" />
                    ) : (
                      <AlertTriangle aria-hidden="true" className="size-3.5" />
                    )}
                    {record.accessiblePdf
                      ? localised({ en: "Tagged, searchable file", mr: "टॅग केलेली, शोधण्यायोग्य फाइल" })
                      : localised({
                          en: "Scanned file — accessible version being prepared",
                          mr: "स्कॅन केलेली फाइल — सुलभ आवृत्ती तयार होत आहे",
                        })}
                  </span>
                </div>
              </article>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
