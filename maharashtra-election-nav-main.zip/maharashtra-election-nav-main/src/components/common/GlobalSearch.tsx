import { useNavigate } from "@tanstack/react-router";
import { FileText, Search } from "lucide-react";
import * as React from "react";

import { Button } from "@/components/ui/button";
import {
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import { quickLinks } from "@/data/navigation";
import { useI18n } from "@/i18n/i18n";
import { searchKindLabels, searchSite } from "@/lib/search";

/**
 * Quick search available from every page (workbook row 6: "no quick search").
 * Enter runs a full search on /search so the user gets a countable, filterable
 * result set rather than only a dropdown.
 */
export function GlobalSearch({ compact = false }: { compact?: boolean }) {
  const { t, localised, locale } = useI18n();
  const navigate = useNavigate();
  const [open, setOpen] = React.useState(false);
  const [query, setQuery] = React.useState("");

  React.useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "k" && (event.metaKey || event.ctrlKey)) {
        event.preventDefault();
        setOpen((v) => !v);
      }
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, []);

  const hits = React.useMemo(() => searchSite(query, locale).slice(0, 8), [query, locale]);

  const go = (href: string) => {
    setOpen(false);
    setQuery("");
    navigate({ to: href });
  };

  const runFullSearch = () => {
    if (!query.trim()) return;
    setOpen(false);
    navigate({ to: "/search", search: { q: query.trim(), kind: "all" } });
  };

  return (
    <>
      <Button
        variant={compact ? "ghost" : "outline"}
        size={compact ? "icon" : "default"}
        aria-label={t("search.open")}
        onClick={() => setOpen(true)}
        className={
          compact
            ? "size-9 border border-utility-foreground/30 bg-utility-action text-utility-action-foreground hover:bg-utility-action/85 hover:text-utility-action-foreground"
            : "min-h-11 justify-start gap-2 bg-card text-muted-foreground sm:w-64 lg:w-80"
        }
      >
        <Search aria-hidden="true" className="size-4" />
        {!compact && (
          <>
            <span className="truncate">{t("search.placeholder")}</span>
            <kbd className="ml-auto hidden rounded border bg-muted px-1.5 py-0.5 font-mono text-[10px] lg:inline">
              Ctrl K
            </kbd>
          </>
        )}
      </Button>

      <CommandDialog
        open={open}
        onOpenChange={setOpen}
      >
        <CommandInput
          value={query}
          onValueChange={setQuery}
          placeholder={t("search.placeholder")}
          onKeyDown={(event) => {
            if (event.key === "Enter" && hits.length === 0) runFullSearch();
          }}
        />
        <CommandList>
          {query.trim().length >= 2 && hits.length === 0 && (
            <CommandEmpty>{t("search.noResults")}</CommandEmpty>
          )}

          {query.trim().length < 2 && (
            <CommandGroup heading={t("search.recent")}>
              {quickLinks.map((link) => (
                <CommandItem key={link.to} value={link.to} onSelect={() => go(link.to)}>
                  <FileText aria-hidden="true" className="size-4" />
                  <span>{localised(link.label)}</span>
                  <span className="ml-auto text-xs text-muted-foreground">
                    {localised(link.hint)}
                  </span>
                </CommandItem>
              ))}
            </CommandGroup>
          )}

          {hits.length > 0 && (
            <CommandGroup
              heading={`${hits.length} ${
                hits.length === 1 ? t("search.countOne") : t("search.countMany")
              }`}
            >
              {hits.map((hit) => (
                <CommandItem key={hit.id} value={hit.id} onSelect={() => go(hit.href)}>
                  <span className="flex min-w-0 flex-col">
                    <span className="truncate">{localised(hit.title)}</span>
                    <span className="truncate text-xs text-muted-foreground">
                      {localised(hit.snippet)}
                    </span>
                  </span>
                  <span className="ml-auto shrink-0 rounded border px-1.5 py-0.5 text-[10px] text-muted-foreground">
                    {localised(searchKindLabels[hit.kind])}
                  </span>
                </CommandItem>
              ))}
              <CommandItem value="__all" onSelect={runFullSearch}>
                <Search aria-hidden="true" className="size-4" />
                {t("search.submit")}: “{query.trim()}”
              </CommandItem>
            </CommandGroup>
          )}
        </CommandList>
      </CommandDialog>
    </>
  );
}
