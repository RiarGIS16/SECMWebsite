import { CalendarRange, Info } from "lucide-react";
import * as React from "react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { isReversedRange, type DateRange } from "@/lib/date-range";
import { useI18n } from "@/i18n/i18n";
import { cn } from "@/lib/utils";

/**
 * From/To filter used across every register in the site.
 *
 * The workbook (rows 17–20) reports valid ranges returning "No Records Found".
 * Two things prevent that here: the comparison is calendar-day based and
 * inclusive of both endpoints (see lib/date-range.ts), and a reversed range is
 * surfaced as an inline message and auto-corrected rather than silently
 * returning nothing. The inclusive rule is stated on screen so users can trust
 * the result.
 */

type Props = {
  value: DateRange;
  onChange: (value: DateRange) => void;
  /** Optional dataset bounds shown as helper text. */
  bounds?: { min?: string | undefined; max?: string | undefined };
  className?: string;
  idPrefix?: string;
};

export function DateRangeFilter({ value, onChange, bounds, className, idPrefix = "range" }: Props) {
  const { t, formatDate } = useI18n();
  const reversed = isReversedRange(value);
  const fromId = `${idPrefix}-from`;
  const toId = `${idPrefix}-to`;
  const hintId = `${idPrefix}-hint`;

  return (
    <fieldset className={cn("space-y-2", className)}>
      <legend className="flex items-center gap-2 text-sm font-medium">
        <CalendarRange aria-hidden="true" className="size-4" />
        {t("ui.dateRange")}
      </legend>

      <div className="grid gap-3 sm:grid-cols-2">
        <div className="space-y-1.5">
          <Label htmlFor={fromId} className="text-xs text-muted-foreground">
            {t("ui.from")}
          </Label>
          <Input
            id={fromId}
            type="date"
            value={value.from ?? ""}
            min={bounds?.min}
            max={bounds?.max}
            aria-describedby={hintId}
            className="min-h-11 bg-card"
            onChange={(e) => onChange({ ...value, from: e.target.value || undefined })}
          />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor={toId} className="text-xs text-muted-foreground">
            {t("ui.to")}
          </Label>
          <Input
            id={toId}
            type="date"
            value={value.to ?? ""}
            min={bounds?.min}
            max={bounds?.max}
            aria-describedby={hintId}
            className="min-h-11 bg-card"
            onChange={(e) => onChange({ ...value, to: e.target.value || undefined })}
          />
        </div>
      </div>

      <p id={hintId} className="flex items-start gap-1.5 text-xs text-muted-foreground">
        <Info aria-hidden="true" className="mt-0.5 size-3.5 shrink-0" />
        <span>
          {t("ui.dateRangeHint")}
          {bounds?.min && bounds?.max && (
            <>
              {" "}
              {t("ui.showing")} {formatDate(bounds.min)} – {formatDate(bounds.max)}.
            </>
          )}
        </span>
      </p>

      {reversed && (
        <div
          role="alert"
          className="flex flex-wrap items-center gap-2 rounded-md border border-warning bg-warning/15 px-3 py-2 text-xs"
        >
          <span>
            {t("ui.from")} &gt; {t("ui.to")} —{" "}
            {formatDate(value.from!)} … {formatDate(value.to!)}
          </span>
          <Button
            type="button"
            size="sm"
            variant="outline"
            className="min-h-9"
            onClick={() => onChange({ from: value.to, to: value.from })}
          >
            {t("ui.reset")}
          </Button>
        </div>
      )}
    </fieldset>
  );
}
