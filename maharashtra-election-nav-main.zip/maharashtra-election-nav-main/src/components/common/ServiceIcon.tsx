import {
  Accessibility,
  BadgeCheck,
  BookOpenText,
  Building2,
  CalendarDays,
  CircleHelp,
  FileCheck2,
  FileText,
  Landmark,
  Library,
  MailQuestion,
  MapPin,
  MessageSquare,
  Scale,
  ScrollText,
  Search,
  ShieldCheck,
  Users,
  Vote,
  type LucideIcon,
} from "lucide-react";

const namedIcons: Record<string, LucideIcon> = {
  search: Search,
  "file-text": FileText,
  scale: Scale,
  "calendar-days": CalendarDays,
  "scroll-text": ScrollText,
  "message-square": MessageSquare,
};

const sectionIcons: Record<string, LucideIcon> = {
  voter: Vote,
  candidate: BadgeCheck,
  ro: FileCheck2,
  parties: Users,
  elections: CalendarDays,
  events: CalendarDays,
  evm: ShieldCheck,
  updates: ScrollText,
  publications: Library,
  statistics: Building2,
  rti: BookOpenText,
  contact: MapPin,
  feedback: MailQuestion,
  about: Landmark,
  accessibility: Accessibility,
};

export function ServiceIcon({ name, path, className }: { name?: string; path?: string; className?: string }) {
  const section = path?.split("/").filter(Boolean)[0] ?? "";
  const Icon = (name && namedIcons[name]) || sectionIcons[section] || CircleHelp;

  return <Icon aria-hidden="true" className={className} />;
}