import { Link } from "@tanstack/react-router";
import { ArrowUpRight, ExternalLink as ExternalIcon, Landmark, ShieldAlert } from "lucide-react";
import * as React from "react";

import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";
import { useI18n } from "@/i18n/i18n";

/**
 * Outbound link handling.
 *
 * Workbook rows 11, 12 and 15: the live site shows the same blunt "you are
 * leaving" warning for its own pages and for trusted government portals, which
 * creates friction and makes the official site look unsafe. Here links are
 * classified:
 *
 *   internal   — our own routes, no interruption at all
 *   sec        — another SEC-owned domain, no interruption, marked as ours
 *   government — another government domain, a short notice naming the domain,
 *                dismissible for the rest of the session
 *   external   — third party, full notice
 *
 * The destination domain is always shown, and "don't show again this session"
 * is honoured per classification.
 */

export type LinkKind = "internal" | "sec" | "government" | "external";

const SEC_DOMAINS = ["mahasec.maharashtra.gov.in", "mahasecelec.in", "mahasecvoterlist.in"];
const GOV_SUFFIXES = [".gov.in", ".nic.in", "india.gov.in"];

export function classifyHref(href: string): { kind: LinkKind; domain: string } {
  if (!/^https?:/i.test(href)) return { kind: "internal", domain: "" };
  let domain = "";
  try {
    domain = new URL(href).hostname.replace(/^www\./, "");
  } catch {
    return { kind: "internal", domain: "" };
  }
  if (SEC_DOMAINS.some((d) => domain === d || domain.endsWith(`.${d}`))) {
    return { kind: "sec", domain };
  }
  if (GOV_SUFFIXES.some((suffix) => domain.endsWith(suffix))) {
    return { kind: "government", domain };
  }
  return { kind: "external", domain };
}

const SESSION_KEY = "sec-mh.suppress-link-notice";

function isSuppressed(kind: LinkKind): boolean {
  if (typeof window === "undefined") return false;
  try {
    const raw = window.sessionStorage.getItem(SESSION_KEY);
    return raw ? (JSON.parse(raw) as string[]).includes(kind) : false;
  } catch {
    return false;
  }
}

function suppress(kind: LinkKind) {
  try {
    const raw = window.sessionStorage.getItem(SESSION_KEY);
    const list = raw ? (JSON.parse(raw) as string[]) : [];
    if (!list.includes(kind)) list.push(kind);
    window.sessionStorage.setItem(SESSION_KEY, JSON.stringify(list));
  } catch {
    /* ignore */
  }
}

type SmartLinkProps = {
  href: string;
  children: React.ReactNode;
  className?: string;
  /** Hide the small trailing icon (for card-sized links that show their own). */
  bare?: boolean;
  "aria-label"?: string;
};

export function SmartLink({ href, children, className, bare, ...rest }: SmartLinkProps) {
  const { t, locale } = useI18n();
  const { kind, domain } = React.useMemo(() => classifyHref(href), [href]);
  const [open, setOpen] = React.useState(false);
  const [dontAsk, setDontAsk] = React.useState(false);

  if (kind === "internal") {
    return (
      <Link to={href} className={className} {...rest}>
        {children}
      </Link>
    );
  }

  const needsNotice = kind === "government" || kind === "external";

  const openTarget = () => window.open(href, "_blank", "noopener,noreferrer");

  const handleClick = (event: React.MouseEvent) => {
    if (!needsNotice || isSuppressed(kind)) return; // let the browser handle it
    event.preventDefault();
    setOpen(true);
  };

  const label =
    kind === "external"
      ? `${t("ui.externalSite")}: ${domain}, ${t("ui.opensNewTab")}`
      : `${domain}, ${t("ui.opensNewTab")}`;

  return (
    <>
      <a
        href={href}
        target="_blank"
        rel="noopener noreferrer"
        onClick={handleClick}
        className={cn("inline-flex items-center gap-1", className)}
        {...rest}
      >
        {children}
        {!bare && (
          <ExternalIcon aria-hidden="true" className="size-3.5 shrink-0 opacity-70" />
        )}
        <span className="sr-only"> ({label})</span>
      </a>

      <AlertDialog open={open} onOpenChange={setOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              {kind === "government" ? (
                <Landmark aria-hidden="true" className="size-5 text-primary" />
              ) : (
                <ShieldAlert aria-hidden="true" className="size-5 text-accent" />
              )}
              {kind === "government"
                ? locale === "mr"
                  ? "आपण दुसऱ्या शासकीय संकेतस्थळावर जात आहात"
                  : "You are moving to another government website"
                : locale === "mr"
                  ? "आपण बाह्य संकेतस्थळावर जात आहात"
                  : "You are leaving for an external website"}
            </AlertDialogTitle>
            <AlertDialogDescription asChild>
              <div className="space-y-3 text-left">
                <p>
                  {kind === "government"
                    ? locale === "mr"
                      ? "हे संकेतस्थळ शासनाच्या अखत्यारीतील आहे, मात्र त्याचा मजकूर संबंधित विभागाकडून चालवला जातो."
                      : "This is a government-run website, but its content is maintained by the concerned department."
                    : locale === "mr"
                      ? "हे संकेतस्थळ आयोगाच्या नियंत्रणाखाली नाही. तेथील मजकुरासाठी आयोग जबाबदार नाही."
                      : "This website is not controlled by the Commission, which is not responsible for its content."}
                </p>
                <p className="rounded-md border bg-muted px-3 py-2 font-mono text-sm break-all">
                  {domain}
                </p>
                <div className="flex items-start gap-2">
                  <Checkbox
                    id="suppress-link-notice"
                    checked={dontAsk}
                    onCheckedChange={(v) => setDontAsk(v === true)}
                  />
                  <Label htmlFor="suppress-link-notice" className="text-sm leading-snug font-normal">
                    {locale === "mr"
                      ? "या सत्रात असे संदेश पुन्हा दाखवू नका"
                      : "Don't show this again during this session"}
                  </Label>
                </div>
              </div>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{locale === "mr" ? "रद्द करा" : "Cancel"}</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                if (dontAsk) suppress(kind);
                openTarget();
              }}
            >
              {locale === "mr" ? "पुढे जा" : "Continue"}
              <ArrowUpRight aria-hidden="true" className="size-4" />
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
