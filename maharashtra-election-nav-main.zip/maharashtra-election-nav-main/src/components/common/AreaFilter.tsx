import { MapPin, RotateCcw } from "lucide-react";
import * as React from "react";

import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  districtsForType,
  getDistrict,
  getLocalBody,
  getLocalBodyType,
  getWard,
  localBodiesFor,
  localBodyTypes,
  wardsFor,
} from "@/data/geo";
import { useI18n } from "@/i18n/i18n";
import { cn } from "@/lib/utils";

/**
 * Dependent Local Body Type → District → Local Body → Ward filter.
 *
 * This is the fix for the Critical mapping defect in workbook rows 8, 9, 15 and
 * 16. Each level is derived from the level above, so an illogical combination
 * (Gram Panchayat + Mumbai City wards) cannot be selected. Downstream levels
 * clear themselves when a parent changes, disabled levels explain *why* they
 * are disabled instead of opening an empty list, and a level with genuinely no
 * data says so rather than showing a blank panel.
 */

export type AreaSelection = {
  bodyTypeId?: string | undefined;
  districtId?: string | undefined;
  localBodyId?: string | undefined;
  wardId?: string | undefined;
};

export const emptyArea: AreaSelection = {};

type Props = {
  value: AreaSelection;
  onChange: (value: AreaSelection) => void;
  /** Deepest level to show. Defaults to ward. */
  depth?: "bodyType" | "district" | "localBody" | "ward";
  /** Mark the fields as mandatory (workbook row 15: unclear mandatory state). */
  required?: boolean;
  /** Field-level error messages keyed by level. */
  errors?: Partial<Record<keyof AreaSelection, string>>;
  className?: string;
  idPrefix?: string;
};

const DEPTH_ORDER = ["bodyType", "district", "localBody", "ward"] as const;

export function AreaFilter({
  value,
  onChange,
  depth = "ward",
  required,
  errors,
  className,
  idPrefix = "area",
}: Props) {
  const { t, localised, formatNumber } = useI18n();
  const maxDepth = DEPTH_ORDER.indexOf(depth);

  const districts = React.useMemo(() => districtsForType(value.bodyTypeId), [value.bodyTypeId]);
  const bodies = React.useMemo(
    () => localBodiesFor(value.bodyTypeId, value.districtId),
    [value.bodyTypeId, value.districtId],
  );
  const wards = React.useMemo(() => wardsFor(value.localBodyId), [value.localBodyId]);

  const selectedType = getLocalBodyType(value.bodyTypeId);

  // Changing a level always clears everything below it.
  const setBodyType = (bodyTypeId: string) => onChange({ bodyTypeId });
  const setDistrict = (districtId: string) => onChange({ bodyTypeId: value.bodyTypeId, districtId });
  const setLocalBody = (localBodyId: string) =>
    onChange({ bodyTypeId: value.bodyTypeId, districtId: value.districtId, localBodyId });
  const setWard = (wardId: string) => onChange({ ...value, wardId });

  const hasAny = Boolean(value.bodyTypeId);

  const field = (
    key: keyof AreaSelection,
    labelKey: Parameters<typeof t>[0],
    placeholderKey: Parameters<typeof t>[0],
    options: { id: string; label: string; hint?: string }[],
    current: string | undefined,
    onSelect: (id: string) => void,
    enabled: boolean,
    emptyMessage?: string,
  ) => {
    const id = `${idPrefix}-${key}`;
    const errorId = `${id}-error`;
    const helpId = `${id}-help`;
    const error = errors?.[key];
    const disabled = !enabled;
    const help = disabled ? t("geo.chooseFirst") : enabled && options.length === 0 ? emptyMessage : undefined;

    return (
      <div className="space-y-1.5">
        <Label htmlFor={id} className="text-sm font-medium">
          {t(labelKey)}
          {required && (
            <span className="text-destructive" aria-hidden="true">
              *
            </span>
          )}
          {required && <span className="sr-only"> ({t("ui.required")})</span>}
        </Label>
        <Select value={current ?? ""} onValueChange={onSelect} disabled={disabled}>
          <SelectTrigger
            id={id}
            aria-required={required || undefined}
            aria-invalid={error ? true : undefined}
            aria-describedby={cn(error && errorId, help && helpId) || undefined}
            className={cn("w-full min-h-11 bg-card", error && "border-destructive")}
          >
            <SelectValue placeholder={t(placeholderKey)} />
          </SelectTrigger>
          <SelectContent>
            {options.length === 0 ? (
              <div className="px-3 py-6 text-center text-sm text-muted-foreground">
                {emptyMessage ?? t("geo.chooseFirst")}
              </div>
            ) : (
              options.map((option) => (
                <SelectItem key={option.id} value={option.id}>
                  <span className="flex flex-col items-start">
                    <span>{option.label}</span>
                    {option.hint && (
                      <span className="text-xs text-muted-foreground">{option.hint}</span>
                    )}
                  </span>
                </SelectItem>
              ))
            )}
          </SelectContent>
        </Select>
        {help && (
          <p id={helpId} className="text-xs text-muted-foreground">
            {help}
          </p>
        )}
        {error && (
          <p id={errorId} role="alert" className="text-xs font-medium text-destructive">
            {error}
          </p>
        )}
      </div>
    );
  };

  return (
    <div className={cn("space-y-4", className)}>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {field(
          "bodyTypeId",
          "geo.bodyType",
          "geo.selectBodyType",
          localBodyTypes.map((type) => ({
            id: type.id,
            label: localised(type.name),
            hint: localised(type.note),
          })),
          value.bodyTypeId,
          setBodyType,
          true,
        )}

        {maxDepth >= 1 &&
          field(
            "districtId",
            "geo.district",
            "geo.selectDistrict",
            districts.map((d) => ({ id: d.id, label: localised(d.name) })),
            value.districtId,
            setDistrict,
            Boolean(value.bodyTypeId),
            selectedType
              ? `${localised(selectedType.name)}: ${t("geo.none")}`
              : undefined,
          )}

        {maxDepth >= 2 &&
          field(
            "localBodyId",
            "geo.localBody",
            "geo.selectLocalBody",
            bodies.map((b) => ({ id: b.id, label: localised(b.name) })),
            value.localBodyId,
            setLocalBody,
            Boolean(value.districtId),
            // Explicit message instead of the blank screen reported in row 15.
            value.districtId
              ? `${localised(getDistrict(value.districtId)?.name)} — ${
                  localised(selectedType?.name) || ""
                }: 0`
              : undefined,
          )}

        {maxDepth >= 3 &&
          field(
            "wardId",
            "geo.ward",
            "geo.selectWard",
            wards.map((w) => ({
              id: w.id,
              label: localised(w.name),
              hint: `${formatNumber(w.electors)} ${localised({ en: "electors", mr: "मतदार" })}`,
            })),
            value.wardId,
            setWard,
            Boolean(value.localBodyId),
          )}
      </div>

      <div className="flex flex-wrap items-center gap-3">
        <p className="flex items-start gap-2 text-sm text-muted-foreground" aria-live="polite">
          <MapPin aria-hidden="true" className="mt-0.5 size-4 shrink-0" />
          <span>
            <span className="font-medium text-foreground">{t("geo.summary")}: </span>
            {hasAny ? (
              <>
                {[
                  localised(getLocalBodyType(value.bodyTypeId)?.name),
                  localised(getDistrict(value.districtId)?.name),
                  localised(getLocalBody(value.localBodyId)?.name),
                  localised(getWard(value.wardId)?.name),
                ]
                  .filter(Boolean)
                  .join(" › ")}
              </>
            ) : (
              t("geo.none")
            )}
          </span>
        </p>
        {hasAny && (
          <Button
            type="button"
            variant="ghost"
            size="sm"
            className="min-h-9"
            onClick={() => onChange(emptyArea)}
          >
            <RotateCcw aria-hidden="true" className="size-4" />
            {t("geo.clear")}
          </Button>
        )}
      </div>
    </div>
  );
}

/** True when a record's area tags are compatible with the current selection. */
export function matchesArea(
  selection: AreaSelection,
  record: { districtId?: string; localBodyId?: string },
): boolean {
  if (selection.districtId && record.districtId && record.districtId !== selection.districtId) {
    return false;
  }
  if (selection.localBodyId && record.localBodyId && record.localBodyId !== selection.localBodyId) {
    return false;
  }
  return true;
}
