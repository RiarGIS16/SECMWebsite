/**
 * Translation dictionary.
 *
 * Architecture note: every user-facing string in the prototype resolves through
 * `t("key")`. The dictionary is a plain, serialisable map so it can be swapped
 * for a CMS/API-delivered locale bundle (or a translation-management export)
 * without touching component code. Marathi strings below are demo placeholders
 * pending official translation review.
 */

export const LOCALES = ["en", "mr"] as const;
export type Locale = (typeof LOCALES)[number];

export const LOCALE_LABELS: Record<Locale, string> = {
  en: "English",
  mr: "मराठी",
};

type Entry = Record<Locale, string>;

export const dictionary = {
  // --- Masthead / global chrome -------------------------------------------
  "site.org": { en: "State Election Commission", mr: "राज्य निवडणूक आयोग" },
  "site.state": { en: "Maharashtra", mr: "महाराष्ट्र" },
  "site.tagline": {
    en: "Local body elections — conduct, supervision and control",
    mr: "स्थानिक स्वराज्य संस्था निवडणुका — संचालन, पर्यवेक्षण आणि नियंत्रण",
  },
  "site.demoBanner": {
    en: "Demonstration prototype. All content, dates, names and figures shown are illustrative sample data, not official records.",
    mr: "प्रात्यक्षिक नमुना संकेतस्थळ. येथील सर्व मजकूर, दिनांक, नावे व आकडेवारी केवळ उदाहरणादाखल आहे, अधिकृत नोंदी नाहीत.",
  },
  "site.skipToContent": { en: "Skip to main content", mr: "मुख्य मजकुरावर जा" },
  "site.skipToNav": { en: "Skip to navigation", mr: "नेव्हिगेशनवर जा" },
  "site.mainNav": { en: "Main navigation", mr: "मुख्य नेव्हिगेशन" },
  "site.openMenu": { en: "Open menu", mr: "मेनू उघडा" },
  "site.closeMenu": { en: "Close menu", mr: "मेनू बंद करा" },
  "site.language": { en: "Language", mr: "भाषा" },
  "site.switchLanguage": { en: "Switch language", mr: "भाषा बदला" },
  "site.textSize": { en: "Text size", mr: "अक्षर आकार" },
  "site.decreaseText": { en: "Decrease text size", mr: "अक्षर आकार कमी करा" },
  "site.resetText": { en: "Reset text size", mr: "अक्षर आकार पूर्ववत करा" },
  "site.increaseText": { en: "Increase text size", mr: "अक्षर आकार वाढवा" },
  "site.highContrast": { en: "High contrast", mr: "उच्च कॉन्ट्रास्ट" },
  "site.breadcrumb": { en: "Breadcrumb", mr: "मार्गदर्शक दुवे" },

  // --- Navigation ----------------------------------------------------------
  "nav.home": { en: "Home", mr: "मुख्यपृष्ठ" },
  "nav.about": { en: "About the Commission", mr: "आयोगाविषयी" },
  "nav.elections": { en: "Elections", mr: "निवडणुका" },
  "nav.schedule": { en: "Election schedule", mr: "निवडणूक कार्यक्रम" },
  "nav.results": { en: "Results", mr: "निकाल" },
  "nav.candidates": { en: "For candidates", mr: "उमेदवारांसाठी" },
  "nav.nomination": { en: "Nomination process", mr: "नामनिर्देशन प्रक्रिया" },
  "nav.affidavit": { en: "Affidavits & expenditure", mr: "प्रतिज्ञापत्रे व खर्च" },
  "nav.voters": { en: "For voters", mr: "मतदारांसाठी" },
  "nav.rollSearch": { en: "Search voter roll", mr: "मतदार यादीत शोधा" },
  "nav.pollingStation": { en: "Find polling station", mr: "मतदान केंद्र शोधा" },
  "nav.ro": { en: "RO / Officials", mr: "निवडणूक निर्णय अधिकारी" },
  "nav.notices": { en: "Notices & circulars", mr: "सूचना व परिपत्रके" },
  "nav.tenders": { en: "Tenders", mr: "निविदा" },
  "nav.press": { en: "Press releases", mr: "प्रसिद्धी पत्रके" },
  "nav.acts": { en: "Acts & rules", mr: "कायदे व नियम" },
  "nav.contact": { en: "Contact", mr: "संपर्क" },
  "nav.help": { en: "Help & FAQ", mr: "मदत व प्रश्नोत्तरे" },
  "nav.grievance": { en: "Grievance redressal", mr: "तक्रार निवारण" },

  // --- Search --------------------------------------------------------------
  "search.label": { en: "Search this site", mr: "या संकेतस्थळावर शोधा" },
  "search.placeholder": {
    en: "Search notices, elections, forms, FAQs…",
    mr: "सूचना, निवडणुका, अर्ज, प्रश्नोत्तरे शोधा…",
  },
  "search.open": { en: "Open search", mr: "शोध उघडा" },
  "search.submit": { en: "Search", mr: "शोधा" },
  "search.results": { en: "Search results", mr: "शोध निकाल" },
  "search.resultsFor": { en: "Results for", mr: "यासाठी निकाल" },
  "search.noResults": {
    en: "No matching pages or documents found.",
    mr: "जुळणारी पृष्ठे किंवा दस्तऐवज आढळले नाहीत.",
  },
  "search.noResultsHint": {
    en: "Check the spelling, try a shorter phrase, or browse the sections below.",
    mr: "शुद्धलेखन तपासा, लहान शब्द वापरा किंवा खालील विभाग पहा.",
  },
  "search.countOne": { en: "result", mr: "निकाल" },
  "search.countMany": { en: "results", mr: "निकाल" },
  "search.filterByType": { en: "Filter by type", mr: "प्रकारानुसार गाळा" },
  "search.allTypes": { en: "All types", mr: "सर्व प्रकार" },
  "search.recent": { en: "Frequently used", mr: "वारंवार वापरलेले" },

  // --- Area (dependent) filter --------------------------------------------
  "geo.heading": { en: "Select your area", mr: "आपले क्षेत्र निवडा" },
  "geo.description": {
    en: "Choose a local body type, then narrow down to your ward. Results update as you select.",
    mr: "प्रथम स्थानिक संस्थेचा प्रकार निवडा, नंतर आपल्या प्रभागापर्यंत निवड करा. निवडीनुसार निकाल बदलतील.",
  },
  "geo.bodyType": { en: "Local body type", mr: "स्थानिक संस्थेचा प्रकार" },
  "geo.district": { en: "District", mr: "जिल्हा" },
  "geo.localBody": { en: "Local body", mr: "स्थानिक संस्था" },
  "geo.ward": { en: "Ward / Prabhag", mr: "प्रभाग" },
  "geo.selectBodyType": { en: "Select local body type", mr: "संस्थेचा प्रकार निवडा" },
  "geo.selectDistrict": { en: "Select district", mr: "जिल्हा निवडा" },
  "geo.selectLocalBody": { en: "Select local body", mr: "स्थानिक संस्था निवडा" },
  "geo.selectWard": { en: "Select ward", mr: "प्रभाग निवडा" },
  "geo.chooseFirst": { en: "Select the previous field first", mr: "प्रथम मागील पर्याय निवडा" },
  "geo.all": { en: "All", mr: "सर्व" },
  "geo.clear": { en: "Clear selection", mr: "निवड रद्द करा" },
  "geo.apply": { en: "Show results", mr: "निकाल दाखवा" },
  "geo.summary": { en: "Showing information for", mr: "यासाठी माहिती दाखवत आहे" },
  "geo.none": { en: "No area selected", mr: "क्षेत्र निवडलेले नाही" },

  // --- Generic UI ----------------------------------------------------------
  "ui.viewAll": { en: "View all", mr: "सर्व पहा" },
  "ui.readMore": { en: "Read more", mr: "अधिक वाचा" },
  "ui.download": { en: "Download", mr: "डाउनलोड" },
  "ui.published": { en: "Published", mr: "प्रसिद्ध" },
  "ui.updated": { en: "Last updated", mr: "शेवटचा बदल" },
  "ui.from": { en: "From", mr: "पासून" },
  "ui.to": { en: "To", mr: "पर्यंत" },
  "ui.dateRange": { en: "Date range", mr: "दिनांक कालावधी" },
  "ui.dateRangeHint": {
    en: "Both dates are included in the results.",
    mr: "दोन्ही दिनांक निकालांमध्ये समाविष्ट आहेत.",
  },
  "ui.reset": { en: "Reset filters", mr: "गाळण्या पूर्ववत करा" },
  "ui.showing": { en: "Showing", mr: "दाखवत आहे" },
  "ui.of": { en: "of", mr: "पैकी" },
  "ui.noRecords": { en: "No records match your filters.", mr: "आपल्या गाळण्यांशी जुळणारे नाही." },
  "ui.required": { en: "Required", mr: "आवश्यक" },
  "ui.optional": { en: "Optional", mr: "ऐच्छिक" },
  "ui.opensNewTab": { en: "opens in a new tab", mr: "नवीन टॅबमध्ये उघडते" },
  "ui.externalSite": { en: "external website", mr: "बाह्य संकेतस्थळ" },
  "ui.demoData": { en: "Demo data", mr: "नमुना माहिती" },
  "ui.new": { en: "New", mr: "नवीन" },
  "ui.close": { en: "Close", mr: "बंद करा" },
  "ui.back": { en: "Back", mr: "मागे" },
  "ui.next": { en: "Next", mr: "पुढे" },
  "ui.submit": { en: "Submit", mr: "सादर करा" },
  "ui.loading": { en: "Loading…", mr: "लोड होत आहे…" },

  // --- Home ----------------------------------------------------------------
  "home.heroTitle": {
    en: "Free, fair and accessible local body elections",
    mr: "मुक्त, निष्पक्ष आणि सुलभ स्थानिक स्वराज्य निवडणुका",
  },
  "home.heroBody": {
    en: "Find your ward, track the election calendar, file nominations and access notices — one place for voters, candidates and election officials.",
    mr: "आपला प्रभाग शोधा, निवडणूक कार्यक्रम पहा, नामनिर्देशन दाखल करा आणि सूचना मिळवा — मतदार, उमेदवार व अधिकाऱ्यांसाठी एकच ठिकाण.",
  },
  "home.quickLinks": { en: "Quick services", mr: "जलद सेवा" },
  "home.chooseRole": { en: "Where would you like to start?", mr: "आपण कोठून सुरुवात कराल?" },
  "home.roleVoter": { en: "I am a voter", mr: "मी मतदार आहे" },
  "home.roleVoterBody": {
    en: "Check your name on the roll, find your polling station and know your ward.",
    mr: "मतदार यादीत नाव तपासा, मतदान केंद्र शोधा आणि प्रभाग जाणून घ्या.",
  },
  "home.roleCandidate": { en: "I am a candidate", mr: "मी उमेदवार आहे" },
  "home.roleCandidateBody": {
    en: "Nomination steps, forms, affidavit checklist and expenditure limits.",
    mr: "नामनिर्देशन टप्पे, अर्ज, प्रतिज्ञापत्र यादी व खर्च मर्यादा.",
  },
  "home.roleOfficer": { en: "I am an election official", mr: "मी निवडणूक अधिकारी आहे" },
  "home.roleOfficerBody": {
    en: "Returning Officer workspace: scrutiny queue, symbol allotment and reporting.",
    mr: "निवडणूक निर्णय अधिकारी कार्यक्षेत्र: छाननी रांग, चिन्ह वाटप व अहवाल.",
  },
  "home.latestNotices": { en: "Latest notices", mr: "अलीकडील सूचना" },
  "home.upcoming": { en: "Election calendar", mr: "निवडणूक दिनदर्शिका" },
  "home.press": { en: "Press releases", mr: "प्रसिद्धी पत्रके" },
  "home.stats": { en: "At a glance", mr: "एका दृष्टिक्षेपात" },
  "home.statBodies": { en: "Local bodies covered", mr: "समाविष्ट स्थानिक संस्था" },
  "home.statWards": { en: "Wards mapped", mr: "नकाशांकित प्रभाग" },
  "home.statDistricts": { en: "Districts", mr: "जिल्हे" },
  "home.statPolls": { en: "Scheduled polls", mr: "नियोजित मतदान" },

  // --- Notices -------------------------------------------------------------
  "notices.title": { en: "Notices & circulars", mr: "सूचना व परिपत्रके" },
  "notices.intro": {
    en: "Orders, circulars and public notices issued for local body elections. Filter by category, area or the date the document was issued.",
    mr: "स्थानिक स्वराज्य निवडणुकांसाठी जारी केलेले आदेश, परिपत्रके व जाहीर सूचना. वर्ग, क्षेत्र किंवा दिनांकानुसार गाळा.",
  },
  "notices.category": { en: "Category", mr: "वर्ग" },
  "notices.allCategories": { en: "All categories", mr: "सर्व वर्ग" },
  "notices.searchLabel": { en: "Search notices", mr: "सूचना शोधा" },
} satisfies Record<string, Entry>;

export type TranslationKey = keyof typeof dictionary;
