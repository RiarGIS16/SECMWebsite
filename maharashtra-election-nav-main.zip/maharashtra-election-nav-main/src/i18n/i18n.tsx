import * as React from "react";

import { dictionary, LOCALES, type Locale, type TranslationKey } from "./dictionary";

/**
 * Locale runtime.
 *
 * `t()` resolves a key for the active locale and falls back to English when a
 * Marathi string has not been supplied yet, so a partially translated CMS
 * bundle never renders an empty label.
 *
 * `localised()` picks the right side of a `{ en, mr }` content field coming
 * from the data layer — the same shape a CMS would return.
 */

export type Localised = { en: string; mr?: string };

type I18nValue = {
  locale: Locale;
  setLocale: (locale: Locale) => void;
  t: (key: TranslationKey) => string;
  localised: (value: Localised | string | undefined) => string;
  formatDate: (iso: string, opts?: Intl.DateTimeFormatOptions) => string;
  formatNumber: (value: number) => string;
};

const I18nContext = React.createContext<I18nValue | null>(null);

const STORAGE_KEY = "sec-mh.locale";

function isLocale(value: unknown): value is Locale {
  return typeof value === "string" && (LOCALES as readonly string[]).includes(value);
}

export function I18nProvider({ children }: { children: React.ReactNode }) {
  // Always start at the SSR default so hydration matches, then adopt the
  // stored preference on the client.
  const [locale, setLocaleState] = React.useState<Locale>("en");

  React.useEffect(() => {
    try {
      const stored = window.localStorage.getItem(STORAGE_KEY);
      if (isLocale(stored)) setLocaleState(stored);
    } catch {
      /* storage unavailable — keep the default */
    }
  }, []);

  React.useEffect(() => {
    document.documentElement.lang = locale === "mr" ? "mr-IN" : "en-IN";
  }, [locale]);

  const setLocale = React.useCallback((next: Locale) => {
    setLocaleState(next);
    try {
      window.localStorage.setItem(STORAGE_KEY, next);
    } catch {
      /* ignore */
    }
  }, []);

  const value = React.useMemo<I18nValue>(() => {
    const t = (key: TranslationKey) => {
      const entry = dictionary[key];
      if (!entry) return key;
      return entry[locale] || entry.en;
    };

    const localised = (input: Localised | string | undefined) => {
      if (!input) return "";
      if (typeof input === "string") return input;
      return (locale === "mr" ? input.mr : input.en) || input.en;
    };

    const tag = locale === "mr" ? "mr-IN" : "en-IN";

    const formatDate = (iso: string, opts?: Intl.DateTimeFormatOptions) => {
      const date = new Date(`${iso}T00:00:00`);
      if (Number.isNaN(date.getTime())) return iso;
      return new Intl.DateTimeFormat(tag, {
        day: "numeric",
        month: "short",
        year: "numeric",
        ...opts,
      }).format(date);
    };

    const formatNumber = (n: number) => new Intl.NumberFormat(tag).format(n);

    return { locale, setLocale, t, localised, formatDate, formatNumber };
  }, [locale, setLocale]);

  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
}

export function useI18n() {
  const ctx = React.useContext(I18nContext);
  if (!ctx) throw new Error("useI18n must be used inside <I18nProvider>");
  return ctx;
}
