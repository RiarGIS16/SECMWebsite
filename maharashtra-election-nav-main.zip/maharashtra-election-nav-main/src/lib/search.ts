import { allDocuments, documentTypeLabels } from "@/data/documents";
import { elections, pollDate } from "@/data/elections";
import { navSections } from "@/data/navigation";
import type { SearchDoc } from "@/data/types";
import type { Locale } from "@/i18n/dictionary";
import type { Localised } from "@/i18n/i18n";

/**
 * Site-wide search.
 *
 * Workbook rows 6 and 55 record: no quick search, no result count, no full-text
 * search across documents, no snippets. The index below therefore covers pages,
 * services, documents and forms in both languages, and the scorer returns
 * ranked, countable results with the matched field available for a snippet.
 *
 * Everything is computed from the same data the pages render, so a CMS swap
 * updates search automatically — there is no second copy of the content.
 */

const text = (value: Localised | undefined) =>
  value ? `${value.en} ${value.mr ?? ""}`.toLowerCase() : "";

function buildIndex(): SearchDoc[] {
  const entries: SearchDoc[] = [];

  // 1. Pages and services from the IA definition.
  for (const section of navSections) {
    entries.push({
      id: `nav-${section.id}`,
      title: section.label,
      snippet: section.summary,
      href: section.to,
      section: section.label,
      kind: "page",
      keywords: [section.id],
    });
    for (const child of section.children) {
      if (child.to === section.to) continue;
      entries.push({
        id: `nav-${section.id}-${child.to}`,
        title: child.label,
        snippet: child.description ?? section.summary,
        href: child.to,
        section: section.label,
        kind: "service",
        keywords: [section.id],
      });
    }
  }

  // 2. Every document and form in the register.
  for (const doc of allDocuments) {
    entries.push({
      id: doc.id,
      title: doc.title,
      snippet: doc.summary,
      href: `/updates/${doc.id}`,
      section: documentTypeLabels[doc.type],
      kind: doc.type === "form" ? "form" : doc.type === "publication" ? "publication" : "document",
      keywords: [...doc.keywords, doc.referenceNo, doc.version, doc.type],
      date: doc.publishedOn,
      priority: doc.priority,
    });
  }

  // 3. Election programmes.
  for (const election of elections) {
    entries.push({
      id: election.id,
      title: election.name,
      snippet: {
        en: `Election programme with ${election.phases.length} notified stages. Poll date ${pollDate(election)}.`,
        mr: `${election.phases.length} अधिसूचित टप्प्यांचा निवडणूक कार्यक्रम. मतदान दिनांक ${pollDate(election)}.`,
      },
      href: `/elections?election=${election.id}`,
      section: { en: "Elections", mr: "निवडणुका" },
      kind: "event",
      keywords: [election.status, String(election.year), ...election.bodyTypeIds],
      date: pollDate(election),
    });
  }

  return entries;
}

export const searchIndex: SearchDoc[] = buildIndex();

export type SearchHit = SearchDoc & { score: number };

/**
 * Token-based scoring. Title matches outrank snippet matches, and every token
 * must appear somewhere so multi-word queries narrow rather than widen.
 */
export function searchSite(query: string, locale: Locale = "en"): SearchHit[] {
  const q = query.trim().toLowerCase();
  if (q.length < 2) return [];
  const tokens = q.split(/\s+/).filter(Boolean);

  const hits: SearchHit[] = [];
  for (const entry of searchIndex) {
    const title = text(entry.title);
    const snippet = text(entry.snippet);
    const keywords = entry.keywords.join(" ").toLowerCase();
    const section = text(entry.section);
    const haystack = `${title} ${snippet} ${keywords} ${section}`;

    if (!tokens.every((token) => haystack.includes(token))) continue;

    let score = 0;
    for (const token of tokens) {
      if (title.startsWith(token)) score += 12;
      if (title.includes(token)) score += 8;
      if (keywords.includes(token)) score += 5;
      if (snippet.includes(token)) score += 2;
      if (section.includes(token)) score += 1;
    }
    if (entry.kind === "service" || entry.kind === "page") score += 4;
    if (entry.priority === "critical") score += 2;
    hits.push({ ...entry, score });
  }

  return hits.sort((a, b) => {
    if (b.score !== a.score) return b.score - a.score;
    const aDate = a.date ?? "";
    const bDate = b.date ?? "";
    if (aDate !== bDate) return bDate.localeCompare(aDate);
    return (a.title[locale as "en"] ?? a.title.en).localeCompare(b.title[locale as "en"] ?? b.title.en);
  });
}

/** Counts per result kind, used for the "N results" line and type filter. */
export function countByKind(hits: SearchHit[]): Record<string, number> {
  return hits.reduce<Record<string, number>>((acc, hit) => {
    acc[hit.kind] = (acc[hit.kind] ?? 0) + 1;
    return acc;
  }, {});
}

export const searchKindLabels: Record<SearchDoc["kind"], Localised> = {
  page: { en: "Page", mr: "पृष्ठ" },
  service: { en: "Service", mr: "सेवा" },
  document: { en: "Document", mr: "दस्तऐवज" },
  form: { en: "Form", mr: "अर्ज" },
  faq: { en: "FAQ", mr: "प्रश्नोत्तर" },
  event: { en: "Election / event", mr: "निवडणूक / कार्यक्रम" },
  officer: { en: "Officer", mr: "अधिकारी" },
  publication: { en: "Publication", mr: "प्रकाशन" },
};
