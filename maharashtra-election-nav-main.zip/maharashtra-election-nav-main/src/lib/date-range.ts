/**
 * Inclusive date-range filtering.
 *
 * Workbook rows 17–20 (Voter Awareness Orders, Recently Completed / Ongoing /
 * Upcoming Elections) record the same defect: selecting a wide range such as
 * 01/06/2015 – 18/06/2026 returns "No Records Found" even though records from
 * 2022 and 2023 are plainly visible on the same page. The recommendation is
 * explicit — the system must return every document falling between the From and
 * To dates, with both endpoints included.
 *
 * These helpers compare calendar days only (no time-of-day, no timezone shift),
 * which is where boundary bugs of that kind usually come from.
 */

/** Converts an ISO-ish date string to a comparable YYYYMMDD number. */
function toDayNumber(value: string): number | null {
  const match = /^(\d{4})-(\d{2})-(\d{2})/.exec(value.trim());
  if (!match) return null;
  const [, y, m, d] = match;
  const year = Number(y);
  const month = Number(m);
  const day = Number(d);
  if (month < 1 || month > 12 || day < 1 || day > 31) return null;
  return year * 10000 + month * 100 + day;
}

export type DateRange = { from?: string | undefined; to?: string | undefined };

/**
 * True when `date` falls inside the range. Both endpoints are inclusive, and an
 * empty endpoint means "unbounded on that side" rather than "no match".
 */
export function isWithinInclusive(date: string | undefined, range: DateRange): boolean {
  if (!date) return !range.from && !range.to;
  const value = toDayNumber(date);
  if (value === null) return false;

  if (range.from) {
    const from = toDayNumber(range.from);
    // An unparseable bound is ignored rather than silently excluding everything.
    if (from !== null && value < from) return false;
  }
  if (range.to) {
    const to = toDayNumber(range.to);
    if (to !== null && value > to) return false;
  }
  return true;
}

/** Range is invalid only when both ends parse and From is after To. */
export function isReversedRange(range: DateRange): boolean {
  if (!range.from || !range.to) return false;
  const from = toDayNumber(range.from);
  const to = toDayNumber(range.to);
  if (from === null || to === null) return false;
  return from > to;
}

/** Normalises a reversed range by swapping the endpoints. */
export function normaliseRange(range: DateRange): DateRange {
  return isReversedRange(range) ? { from: range.to, to: range.from } : range;
}

export function filterByDateInclusive<T>(
  items: T[],
  getDate: (item: T) => string | undefined,
  range: DateRange,
): T[] {
  const safe = normaliseRange(range);
  if (!safe.from && !safe.to) return items;
  return items.filter((item) => isWithinInclusive(getDate(item), safe));
}

/** Earliest and latest dates present in a dataset — used to seed filter hints. */
export function dateBounds(dates: (string | undefined)[]): { min?: string | undefined; max?: string | undefined } {
  const valid = dates.filter((d): d is string => Boolean(d && toDayNumber(d) !== null)).sort();
  return { min: valid[0], max: valid[valid.length - 1] };
}
