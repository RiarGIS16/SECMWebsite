import type { ElectionScope } from "./types";
import type { Localised } from "@/i18n/i18n";

/**
 * Election programme demo data.
 *
 * Supports the "Recently Completed / Ongoing / Upcoming" views (workbook rows
 * 18–20) where the live date filter fails. Every phase date is a plain ISO
 * calendar date so the inclusive range filter can be exercised honestly.
 *
 * All dates and figures are illustrative demo values.
 */

export type ElectionPhaseKey =
  | "notification"
  | "nomination-start"
  | "nomination-end"
  | "scrutiny"
  | "withdrawal"
  | "symbol-allotment"
  | "poll"
  | "counting"
  | "result";

export const phaseLabels: Record<ElectionPhaseKey, Localised> = {
  notification: { en: "Notification issued", mr: "अधिसूचना जारी" },
  "nomination-start": { en: "Nominations open", mr: "नामनिर्देशन सुरू" },
  "nomination-end": { en: "Last date for nominations", mr: "नामनिर्देशनाची अंतिम मुदत" },
  scrutiny: { en: "Scrutiny of nominations", mr: "नामनिर्देशनांची छाननी" },
  withdrawal: { en: "Last date for withdrawal", mr: "माघारीची अंतिम मुदत" },
  "symbol-allotment": { en: "Allotment of symbols", mr: "चिन्ह वाटप" },
  poll: { en: "Day of poll", mr: "मतदानाचा दिवस" },
  counting: { en: "Counting of votes", mr: "मतमोजणी" },
  result: { en: "Declaration of result", mr: "निकाल जाहीर" },
};

export type ElectionStatus = "upcoming" | "ongoing" | "completed";

export type ElectionEvent = {
  id: string;
  name: Localised;
  scope: ElectionScope;
  /** Local body type ids the programme applies to. */
  bodyTypeIds: string[];
  /** District ids covered; empty means statewide. */
  districtIds: string[];
  status: ElectionStatus;
  year: number;
  phases: { key: ElectionPhaseKey; date: string }[];
  /** Reference to the notifying document in the document register. */
  notificationRef?: string;
  seats: number;
  electors: number;
};

const phase = (key: ElectionPhaseKey, date: string) => ({ key, date });

export const elections: ElectionEvent[] = [
  {
    id: "el-2026-mc-np",
    name: {
      en: "General election to Municipal Councils and Nagar Panchayats, 2026",
      mr: "नगरपरिषद व नगरपंचायत सार्वत्रिक निवडणूक, २०२६",
    },
    scope: "urban",
    bodyTypeIds: ["mcouncil", "np"],
    districtIds: [],
    status: "ongoing",
    year: 2026,
    notificationRef: "DEMO/SEC/MC-NP/2026/014",
    seats: 4820,
    electors: 9640000,
    phases: [
      phase("notification", "2026-08-25"),
      phase("nomination-start", "2026-08-27"),
      phase("nomination-end", "2026-09-03"),
      phase("scrutiny", "2026-09-04"),
      phase("withdrawal", "2026-09-08"),
      phase("symbol-allotment", "2026-09-09"),
      phase("poll", "2026-09-24"),
      phase("counting", "2026-09-26"),
      phase("result", "2026-09-26"),
    ],
  },
  {
    id: "el-2026-zp-ps",
    name: {
      en: "General election to Zilla Parishads and Panchayat Samitis, 2026",
      mr: "जिल्हा परिषद व पंचायत समिती सार्वत्रिक निवडणूक, २०२६",
    },
    scope: "rural",
    bodyTypeIds: ["zp", "ps"],
    districtIds: [],
    status: "upcoming",
    year: 2026,
    notificationRef: "DEMO/SEC/ZP-PS/2026/002",
    seats: 6140,
    electors: 21400000,
    phases: [
      phase("notification", "2026-10-12"),
      phase("nomination-start", "2026-10-14"),
      phase("nomination-end", "2026-10-21"),
      phase("scrutiny", "2026-10-22"),
      phase("withdrawal", "2026-10-26"),
      phase("symbol-allotment", "2026-10-27"),
      phase("poll", "2026-11-12"),
      phase("counting", "2026-11-14"),
      phase("result", "2026-11-14"),
    ],
  },
  {
    id: "el-2026-mc",
    name: {
      en: "General election to Municipal Corporations, 2026",
      mr: "महानगरपालिका सार्वत्रिक निवडणूक, २०२६",
    },
    scope: "urban",
    bodyTypeIds: ["mc"],
    districtIds: [],
    status: "upcoming",
    year: 2026,
    seats: 2210,
    electors: 32800000,
    phases: [
      phase("notification", "2026-12-01"),
      phase("nomination-start", "2026-12-03"),
      phase("nomination-end", "2026-12-10"),
      phase("scrutiny", "2026-12-11"),
      phase("withdrawal", "2026-12-15"),
      phase("symbol-allotment", "2026-12-16"),
      phase("poll", "2027-01-07"),
      phase("counting", "2027-01-09"),
      phase("result", "2027-01-09"),
    ],
  },
  {
    id: "el-2026-gp-phase1",
    name: {
      en: "Gram Panchayat elections, 2026 — phase I",
      mr: "ग्रामपंचायत निवडणूक, २०२६ — टप्पा १",
    },
    scope: "rural",
    bodyTypeIds: ["gp"],
    districtIds: ["pune", "satara", "sangli", "kolhapur", "solapur"],
    status: "ongoing",
    year: 2026,
    seats: 18400,
    electors: 5120000,
    phases: [
      phase("notification", "2026-08-18"),
      phase("nomination-start", "2026-08-20"),
      phase("nomination-end", "2026-08-27"),
      phase("scrutiny", "2026-08-28"),
      phase("withdrawal", "2026-09-01"),
      phase("symbol-allotment", "2026-09-02"),
      phase("poll", "2026-09-17"),
      phase("counting", "2026-09-19"),
      phase("result", "2026-09-19"),
    ],
  },
  {
    id: "el-2025-mcouncil",
    name: {
      en: "General election to Municipal Councils, 2025",
      mr: "नगरपरिषद सार्वत्रिक निवडणूक, २०२५",
    },
    scope: "urban",
    bodyTypeIds: ["mcouncil"],
    districtIds: [],
    status: "completed",
    year: 2025,
    notificationRef: "DEMO/SEC/RES/2025/028",
    seats: 3980,
    electors: 8210000,
    phases: [
      phase("notification", "2025-10-28"),
      phase("nomination-start", "2025-10-30"),
      phase("nomination-end", "2025-11-06"),
      phase("scrutiny", "2025-11-07"),
      phase("withdrawal", "2025-11-11"),
      phase("symbol-allotment", "2025-11-12"),
      phase("poll", "2025-12-14"),
      phase("counting", "2025-12-17"),
      phase("result", "2025-12-19"),
    ],
  },
  {
    id: "el-2024-byelection",
    name: {
      en: "By-elections to vacant seats, 2024",
      mr: "रिक्त जागांसाठी पोटनिवडणूक, २०२४",
    },
    scope: "both",
    bodyTypeIds: ["mcouncil", "np", "gp"],
    districtIds: ["nagpur", "wardha", "amravati", "akola"],
    status: "completed",
    year: 2024,
    seats: 214,
    electors: 486000,
    phases: [
      phase("notification", "2024-06-03"),
      phase("nomination-start", "2024-06-05"),
      phase("nomination-end", "2024-06-12"),
      phase("scrutiny", "2024-06-13"),
      phase("withdrawal", "2024-06-17"),
      phase("symbol-allotment", "2024-06-18"),
      phase("poll", "2024-07-04"),
      phase("counting", "2024-07-06"),
      phase("result", "2024-07-06"),
    ],
  },
  {
    id: "el-2023-gp",
    name: {
      en: "Gram Panchayat elections, 2023 — consolidated",
      mr: "ग्रामपंचायत निवडणूक, २०२३ — एकत्रित",
    },
    scope: "rural",
    bodyTypeIds: ["gp"],
    districtIds: [],
    status: "completed",
    year: 2023,
    seats: 24600,
    electors: 7840000,
    phases: [
      phase("notification", "2023-09-11"),
      phase("nomination-start", "2023-09-13"),
      phase("nomination-end", "2023-09-20"),
      phase("scrutiny", "2023-09-21"),
      phase("withdrawal", "2023-09-25"),
      phase("symbol-allotment", "2023-09-26"),
      phase("poll", "2023-10-15"),
      phase("counting", "2023-10-17"),
      phase("result", "2023-10-17"),
    ],
  },
  {
    id: "el-2022-zp",
    name: {
      en: "Zilla Parishad and Panchayat Samiti elections, 2022",
      mr: "जिल्हा परिषद व पंचायत समिती निवडणूक, २०२२",
    },
    scope: "rural",
    bodyTypeIds: ["zp", "ps"],
    districtIds: ["nashik", "dhule", "jalgaon", "nandurbar", "ahilyanagar"],
    status: "completed",
    year: 2022,
    seats: 1840,
    electors: 6210000,
    phases: [
      phase("notification", "2022-07-19"),
      phase("nomination-start", "2022-07-21"),
      phase("nomination-end", "2022-07-28"),
      phase("scrutiny", "2022-07-29"),
      phase("withdrawal", "2022-08-02"),
      phase("symbol-allotment", "2022-08-03"),
      phase("poll", "2022-08-21"),
      phase("counting", "2022-08-23"),
      phase("result", "2022-08-23"),
    ],
  },
];

export const statusLabels: Record<ElectionStatus, Localised> = {
  upcoming: { en: "Upcoming", mr: "आगामी" },
  ongoing: { en: "Ongoing", mr: "सुरू असलेली" },
  completed: { en: "Recently completed", mr: "नुकत्याच पूर्ण झालेल्या" },
};

/** The date used when an election is matched against a date-range filter. */
export function pollDate(election: ElectionEvent): string {
  return election.phases.find((p) => p.key === "poll")?.date ?? election.phases[0]?.date ?? "";
}

export function phaseDate(election: ElectionEvent, key: ElectionPhaseKey): string | undefined {
  return election.phases.find((p) => p.key === key)?.date;
}

/** Full span of an election programme, used for "any activity in range" checks. */
export function programmeSpan(election: ElectionEvent): { from: string; to: string } {
  const sorted = election.phases.map((p) => p.date).sort();
  return { from: sorted[0] ?? "", to: sorted[sorted.length - 1] ?? "" };
}
