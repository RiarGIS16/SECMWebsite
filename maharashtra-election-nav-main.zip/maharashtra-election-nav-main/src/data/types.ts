import type { Localised } from "@/i18n/i18n";

/**
 * Shared content model.
 *
 * Every field here exists to close a specific gap recorded in the requirements
 * workbook — chiefly rows 1 (no update type / priority / owner), 6 (no owner,
 * no unified hierarchy), 24 (form metadata), 41/54 (version + effective dates)
 * and 56 (PDF accessibility status). Shapes are plain JSON so the whole layer
 * can be served from a CMS or API without changing component code.
 */

export type ElectionScope = "urban" | "rural" | "both";

/** Update/document type — replaces the workbook's "mixed content in one list". */
export type DocumentType =
  | "notification"
  | "circular"
  | "order"
  | "press-release"
  | "election-schedule"
  | "form"
  | "result"
  | "publication"
  | "act"
  | "rule"
  | "handbook"
  | "rti-disclosure";

/** Visual + programmatic priority indicator (workbook row 1, gap 3). */
export type ContentPriority = "critical" | "important" | "routine";

/** Process stage taxonomy for RO/candidate circulars (workbook row 27). */
export type ProcessStage =
  | "pre-poll"
  | "nomination"
  | "scrutiny"
  | "symbol-allotment"
  | "campaign"
  | "polling"
  | "counting"
  | "result"
  | "model-code"
  | "expenditure"
  | "evm"
  | "staff";

export type FileFormat = "pdf" | "html" | "xlsx" | "csv" | "doc";

/** Governance block attached to every published item (rows 12, 58, 81). */
export type Governance = {
  /** Owning office/section — "document owner information is missing" (row 6). */
  owner: Localised;
  /** ISO date the content was last verified by the owning office. */
  lastVerified: string;
  /** Review cadence published alongside the date so users can judge staleness. */
  reviewCycle: "monthly" | "quarterly" | "half-yearly" | "annual" | "event-based";
};

export type DocumentRecord = {
  id: string;
  title: Localised;
  summary: Localised;
  type: DocumentType;
  priority: ContentPriority;
  stages: ProcessStage[];
  scope: ElectionScope;
  /** Issuing authority — distinct from the page owner. */
  issuingAuthority: Localised;
  /** Reference/serial number printed on the document. */
  referenceNo: string;
  /** ISO date of publication on the portal. */
  publishedOn: string;
  /** ISO date the instrument takes effect (row 22: "effective-from dates"). */
  effectiveFrom?: string;
  /** Version label and supersession chain (rows 41, 54). */
  version: string;
  supersedes?: string;
  status: "current" | "superseded" | "archived";
  format: FileFormat;
  sizeKb?: number;
  /** Whether the PDF is tagged/searchable/bookmarked (row 56, Critical). */
  accessiblePdf: boolean;
  /** HTML alternative required for critical content (row 56). */
  htmlAlternative?: string;
  /** Optional area scoping used by the dependent area filter. */
  districtId?: string;
  localBodyId?: string;
  /** Free-text keywords folded into the search index. */
  keywords: string[];
  /** Link to the published file on the Commission's own site, when official. */
  sourceUrl?: string;
  /** Site areas this record belongs to, e.g. "voter", "elections". */
  sections?: string[];
  governance: Governance;
};

export type FormRecord = DocumentRecord & {
  formNo: string;
  purpose: Localised;
  applicableElections: string[];
  requiredAttachments: Localised[];
  submitTo: Localised;
  feeNote: Localised;
};

/** Search index entry — powers site-wide search with counts and snippets. */
export type SearchDoc = {
  id: string;
  title: Localised;
  snippet: Localised;
  href: string;
  section: Localised;
  kind:
    | "page"
    | "service"
    | "document"
    | "form"
    | "faq"
    | "event"
    | "officer"
    | "publication";
  keywords: string[];
  date?: string;
  priority?: ContentPriority;
};
