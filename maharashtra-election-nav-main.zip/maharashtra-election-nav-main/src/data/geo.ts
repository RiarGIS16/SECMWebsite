import type { ElectionScope } from "./types";
import type { Localised } from "@/i18n/i18n";

/**
 * Area master data.
 *
 * Workbook rows 8, 9, 15 and 16 record a Critical defect on the live site: the
 * Local Body Type / District / Local Body dropdowns are not related, so a user
 * can pick "Gram Panchayat" and be offered "Mumbai City" wards. Here the
 * relationship is modelled in the data itself — a local body belongs to exactly
 * one type and one district, and wards belong to one local body — so an invalid
 * combination cannot be produced by the UI.
 *
 * Names of divisions, districts and local bodies are real administrative names
 * so the prototype reads realistically. All counts, ward names, reservation
 * labels and electorate figures are illustrative demo values.
 */

export type Division = { id: string; name: Localised };

export type LocalBodyType = {
  id: string;
  name: Localised;
  scope: Exclude<ElectionScope, "both">;
  /** Short plain-language description shown as helper text. */
  note: Localised;
};

export type District = { id: string; name: Localised; divisionId: string };

export type LocalBody = {
  id: string;
  name: Localised;
  typeId: string;
  districtId: string;
  /** Number of wards/prabhags — demo figure. */
  wardCount: number;
};

export type Ward = {
  id: string;
  localBodyId: string;
  number: string;
  name: Localised;
  /** Illustrative reservation label. */
  reservation: "general" | "women" | "sc" | "st" | "obc";
  electors: number;
};

export const divisions: Division[] = [
  { id: "div-konkan", name: { en: "Konkan", mr: "कोकण" } },
  { id: "div-pune", name: { en: "Pune", mr: "पुणे" } },
  { id: "div-nashik", name: { en: "Nashik", mr: "नाशिक" } },
  {
    id: "div-sambhajinagar",
    name: { en: "Chhatrapati Sambhajinagar", mr: "छत्रपती संभाजीनगर" },
  },
  { id: "div-amravati", name: { en: "Amravati", mr: "अमरावती" } },
  { id: "div-nagpur", name: { en: "Nagpur", mr: "नागपूर" } },
];

export const localBodyTypes: LocalBodyType[] = [
  {
    id: "mc",
    name: { en: "Municipal Corporation", mr: "महानगरपालिका" },
    scope: "urban",
    note: {
      en: "Large urban areas. Wards are called prabhags.",
      mr: "मोठी शहरी क्षेत्रे. प्रभाग रचना लागू.",
    },
  },
  {
    id: "mcouncil",
    name: { en: "Municipal Council", mr: "नगरपरिषद" },
    scope: "urban",
    note: {
      en: "Smaller towns and municipal areas.",
      mr: "लहान शहरे व नगरपरिषद क्षेत्रे.",
    },
  },
  {
    id: "np",
    name: { en: "Nagar Panchayat", mr: "नगरपंचायत" },
    scope: "urban",
    note: {
      en: "Transitional areas moving from rural to urban.",
      mr: "ग्रामीणकडून शहरीकडे संक्रमण होणारी क्षेत्रे.",
    },
  },
  {
    id: "zp",
    name: { en: "Zilla Parishad", mr: "जिल्हा परिषद" },
    scope: "rural",
    note: {
      en: "District-level rural body. Divisions are called gats.",
      mr: "जिल्हास्तरीय ग्रामीण संस्था. गट रचना लागू.",
    },
  },
  {
    id: "ps",
    name: { en: "Panchayat Samiti", mr: "पंचायत समिती" },
    scope: "rural",
    note: {
      en: "Block-level rural body. Divisions are called gans.",
      mr: "तालुकास्तरीय ग्रामीण संस्था. गण रचना लागू.",
    },
  },
  {
    id: "gp",
    name: { en: "Gram Panchayat", mr: "ग्रामपंचायत" },
    scope: "rural",
    note: {
      en: "Village-level rural body.",
      mr: "गावपातळीवरील ग्रामीण संस्था.",
    },
  },
];

const D = (id: string, en: string, mr: string, divisionId: string): District => ({
  id,
  name: { en, mr },
  divisionId,
});

export const districts: District[] = [
  D("mumbai-city", "Mumbai City", "मुंबई शहर", "div-konkan"),
  D("mumbai-suburban", "Mumbai Suburban", "मुंबई उपनगर", "div-konkan"),
  D("thane", "Thane", "ठाणे", "div-konkan"),
  D("palghar", "Palghar", "पालघर", "div-konkan"),
  D("raigad", "Raigad", "रायगड", "div-konkan"),
  D("ratnagiri", "Ratnagiri", "रत्नागिरी", "div-konkan"),
  D("sindhudurg", "Sindhudurg", "सिंधुदुर्ग", "div-konkan"),
  D("pune", "Pune", "पुणे", "div-pune"),
  D("satara", "Satara", "सातारा", "div-pune"),
  D("sangli", "Sangli", "सांगली", "div-pune"),
  D("solapur", "Solapur", "सोलापूर", "div-pune"),
  D("kolhapur", "Kolhapur", "कोल्हापूर", "div-pune"),
  D("nashik", "Nashik", "नाशिक", "div-nashik"),
  D("dhule", "Dhule", "धुळे", "div-nashik"),
  D("nandurbar", "Nandurbar", "नंदुरबार", "div-nashik"),
  D("jalgaon", "Jalgaon", "जळगाव", "div-nashik"),
  D("ahilyanagar", "Ahilyanagar", "अहिल्यानगर", "div-nashik"),
  D(
    "chh-sambhajinagar",
    "Chhatrapati Sambhajinagar",
    "छत्रपती संभाजीनगर",
    "div-sambhajinagar",
  ),
  D("jalna", "Jalna", "जालना", "div-sambhajinagar"),
  D("beed", "Beed", "बीड", "div-sambhajinagar"),
  D("dharashiv", "Dharashiv", "धाराशिव", "div-sambhajinagar"),
  D("latur", "Latur", "लातूर", "div-sambhajinagar"),
  D("nanded", "Nanded", "नांदेड", "div-sambhajinagar"),
  D("parbhani", "Parbhani", "परभणी", "div-sambhajinagar"),
  D("hingoli", "Hingoli", "हिंगोली", "div-sambhajinagar"),
  D("amravati", "Amravati", "अमरावती", "div-amravati"),
  D("akola", "Akola", "अकोला", "div-amravati"),
  D("washim", "Washim", "वाशिम", "div-amravati"),
  D("buldhana", "Buldhana", "बुलढाणा", "div-amravati"),
  D("yavatmal", "Yavatmal", "यवतमाळ", "div-amravati"),
  D("nagpur", "Nagpur", "नागपूर", "div-nagpur"),
  D("wardha", "Wardha", "वर्धा", "div-nagpur"),
  D("bhandara", "Bhandara", "भंडारा", "div-nagpur"),
  D("gondia", "Gondia", "गोंदिया", "div-nagpur"),
  D("chandrapur", "Chandrapur", "चंद्रपूर", "div-nagpur"),
  D("gadchiroli", "Gadchiroli", "गडचिरोली", "div-nagpur"),
];

const LB = (
  id: string,
  en: string,
  mr: string,
  typeId: string,
  districtId: string,
  wardCount: number,
): LocalBody => ({ id, name: { en, mr }, typeId, districtId, wardCount });

/**
 * Local bodies. Municipal corporations exist only in their own districts;
 * Zilla Parishads exist only in rural districts (there is no ZP for Mumbai City
 * or Mumbai Suburban) — the exact class of mismatch the workbook flagged.
 */
export const localBodies: LocalBody[] = [
  // Municipal Corporations
  LB("mc-bmc", "Brihanmumbai Municipal Corporation", "बृहन्मुंबई महानगरपालिका", "mc", "mumbai-city", 24),
  LB("mc-thane", "Thane Municipal Corporation", "ठाणे महानगरपालिका", "mc", "thane", 22),
  LB("mc-kalyan", "Kalyan-Dombivli Municipal Corporation", "कल्याण-डोंबिवली महानगरपालिका", "mc", "thane", 20),
  LB("mc-navimumbai", "Navi Mumbai Municipal Corporation", "नवी मुंबई महानगरपालिका", "mc", "thane", 18),
  LB("mc-vasai", "Vasai-Virar City Municipal Corporation", "वसई-विरार शहर महानगरपालिका", "mc", "palghar", 18),
  LB("mc-panvel", "Panvel Municipal Corporation", "पनवेल महानगरपालिका", "mc", "raigad", 14),
  LB("mc-pune", "Pune Municipal Corporation", "पुणे महानगरपालिका", "mc", "pune", 22),
  LB("mc-pcmc", "Pimpri-Chinchwad Municipal Corporation", "पिंपरी-चिंचवड महानगरपालिका", "mc", "pune", 20),
  LB("mc-solapur", "Solapur Municipal Corporation", "सोलापूर महानगरपालिका", "mc", "solapur", 16),
  LB("mc-kolhapur", "Kolhapur Municipal Corporation", "कोल्हापूर महानगरपालिका", "mc", "kolhapur", 14),
  LB("mc-sangli", "Sangli-Miraj-Kupwad Municipal Corporation", "सांगली-मिरज-कुपवाड महानगरपालिका", "mc", "sangli", 14),
  LB("mc-nashik", "Nashik Municipal Corporation", "नाशिक महानगरपालिका", "mc", "nashik", 18),
  LB("mc-malegaon", "Malegaon Municipal Corporation", "मालेगाव महानगरपालिका", "mc", "nashik", 12),
  LB("mc-dhule", "Dhule Municipal Corporation", "धुळे महानगरपालिका", "mc", "dhule", 12),
  LB("mc-jalgaon", "Jalgaon Municipal Corporation", "जळगाव महानगरपालिका", "mc", "jalgaon", 12),
  LB("mc-ahilyanagar", "Ahilyanagar Municipal Corporation", "अहिल्यानगर महानगरपालिका", "mc", "ahilyanagar", 12),
  LB("mc-chhsambhajinagar", "Chhatrapati Sambhajinagar Municipal Corporation", "छत्रपती संभाजीनगर महानगरपालिका", "mc", "chh-sambhajinagar", 18),
  LB("mc-latur", "Latur Municipal Corporation", "लातूर महानगरपालिका", "mc", "latur", 12),
  LB("mc-nanded", "Nanded-Waghala Municipal Corporation", "नांदेड-वाघाळा महानगरपालिका", "mc", "nanded", 14),
  LB("mc-parbhani", "Parbhani Municipal Corporation", "परभणी महानगरपालिका", "mc", "parbhani", 12),
  LB("mc-amravati", "Amravati Municipal Corporation", "अमरावती महानगरपालिका", "mc", "amravati", 14),
  LB("mc-akola", "Akola Municipal Corporation", "अकोला महानगरपालिका", "mc", "akola", 14),
  LB("mc-nagpur", "Nagpur Municipal Corporation", "नागपूर महानगरपालिका", "mc", "nagpur", 20),
  LB("mc-chandrapur", "Chandrapur Municipal Corporation", "चंद्रपूर महानगरपालिका", "mc", "chandrapur", 12),

  // Municipal Councils
  LB("mcl-ambernath", "Ambernath Municipal Council", "अंबरनाथ नगरपरिषद", "mcouncil", "thane", 16),
  LB("mcl-badlapur", "Kulgaon-Badlapur Municipal Council", "कुळगाव-बदलापूर नगरपरिषद", "mcouncil", "thane", 14),
  LB("mcl-alibag", "Alibag Municipal Council", "अलिबाग नगरपरिषद", "mcouncil", "raigad", 10),
  LB("mcl-ratnagiri", "Ratnagiri Municipal Council", "रत्नागिरी नगरपरिषद", "mcouncil", "ratnagiri", 10),
  LB("mcl-sawantwadi", "Sawantwadi Municipal Council", "सावंतवाडी नगरपरिषद", "mcouncil", "sindhudurg", 8),
  LB("mcl-baramati", "Baramati Municipal Council", "बारामती नगरपरिषद", "mcouncil", "pune", 12),
  LB("mcl-satara", "Satara Municipal Council", "सातारा नगरपरिषद", "mcouncil", "satara", 10),
  LB("mcl-ichalkaranji", "Ichalkaranji Municipal Council", "इचलकरंजी नगरपरिषद", "mcouncil", "kolhapur", 14),
  LB("mcl-sinnar", "Sinnar Municipal Council", "सिन्नर नगरपरिषद", "mcouncil", "nashik", 8),
  LB("mcl-shirpur", "Shirpur-Warwade Municipal Council", "शिरपूर-वरवाडे नगरपरिषद", "mcouncil", "dhule", 8),
  LB("mcl-bhusawal", "Bhusawal Municipal Council", "भुसावळ नगरपरिषद", "mcouncil", "jalgaon", 12),
  LB("mcl-jalna", "Jalna Municipal Council", "जालना नगरपरिषद", "mcouncil", "jalna", 12),
  LB("mcl-beed", "Beed Municipal Council", "बीड नगरपरिषद", "mcouncil", "beed", 10),
  LB("mcl-dharashiv", "Dharashiv Municipal Council", "धाराशिव नगरपरिषद", "mcouncil", "dharashiv", 10),
  LB("mcl-hingoli", "Hingoli Municipal Council", "हिंगोली नगरपरिषद", "mcouncil", "hingoli", 8),
  LB("mcl-washim", "Washim Municipal Council", "वाशिम नगरपरिषद", "mcouncil", "washim", 8),
  LB("mcl-khamgaon", "Khamgaon Municipal Council", "खामगाव नगरपरिषद", "mcouncil", "buldhana", 10),
  LB("mcl-yavatmal", "Yavatmal Municipal Council", "यवतमाळ नगरपरिषद", "mcouncil", "yavatmal", 10),
  LB("mcl-wardha", "Wardha Municipal Council", "वर्धा नगरपरिषद", "mcouncil", "wardha", 10),
  LB("mcl-bhandara", "Bhandara Municipal Council", "भंडारा नगरपरिषद", "mcouncil", "bhandara", 8),
  LB("mcl-gondia", "Gondia Municipal Council", "गोंदिया नगरपरिषद", "mcouncil", "gondia", 10),

  // Nagar Panchayats
  LB("np-vikramgad", "Vikramgad Nagar Panchayat", "विक्रमगड नगरपंचायत", "np", "palghar", 6),
  LB("np-mangaon", "Mangaon Nagar Panchayat", "माणगाव नगरपंचायत", "np", "raigad", 6),
  LB("np-velhe", "Velhe Nagar Panchayat", "वेल्हे नगरपंचायत", "np", "pune", 6),
  LB("np-patan", "Patan Nagar Panchayat", "पाटण नगरपंचायत", "np", "satara", 6),
  LB("np-surgana", "Surgana Nagar Panchayat", "सुरगाणा नगरपंचायत", "np", "nashik", 6),
  LB("np-akkalkuwa", "Akkalkuwa Nagar Panchayat", "अक्कलकुवा नगरपंचायत", "np", "nandurbar", 6),
  LB("np-mantha", "Mantha Nagar Panchayat", "मंठा नगरपंचायत", "np", "jalna", 6),
  LB("np-mahagaon", "Mahagaon Nagar Panchayat", "महागाव नगरपंचायत", "np", "yavatmal", 6),
  LB("np-etapalli", "Etapalli Nagar Panchayat", "एटापल्ली नगरपंचायत", "np", "gadchiroli", 6),
  LB("np-sakoli", "Sakoli Nagar Panchayat", "साकोली नगरपंचायत", "np", "bhandara", 6),
];

// Zilla Parishads exist in every district except the two Mumbai districts.
const NO_ZP = new Set(["mumbai-city", "mumbai-suburban"]);
for (const district of districts) {
  if (NO_ZP.has(district.id)) continue;
  localBodies.push(
    LB(
      `zp-${district.id}`,
      `${district.name.en} Zilla Parishad`,
      `${district.name.mr} जिल्हा परिषद`,
      "zp",
      district.id,
      16,
    ),
  );
}

// A representative Panchayat Samiti and Gram Panchayat per rural district.
const PS_GP_SAMPLES: Record<string, [string, string][]> = {
  thane: [["Shahapur", "शहापूर"], ["Murbad", "मुरबाड"]],
  palghar: [["Dahanu", "डहाणू"], ["Jawhar", "जव्हार"]],
  raigad: [["Karjat", "कर्जत"], ["Mhasala", "म्हसळा"]],
  ratnagiri: [["Chiplun", "चिपळूण"], ["Guhagar", "गुहागर"]],
  sindhudurg: [["Kudal", "कुडाळ"], ["Vengurla", "वेंगुर्ला"]],
  pune: [["Haveli", "हवेली"], ["Junnar", "जुन्नर"]],
  satara: [["Karad", "कराड"], ["Wai", "वाई"]],
  sangli: [["Tasgaon", "तासगाव"], ["Shirala", "शिराळा"]],
  solapur: [["Pandharpur", "पंढरपूर"], ["Barshi", "बार्शी"]],
  kolhapur: [["Panhala", "पन्हाळा"], ["Shirol", "शिरोळ"]],
  nashik: [["Dindori", "दिंडोरी"], ["Niphad", "निफाड"]],
  dhule: [["Sakri", "साक्री"], ["Shindkheda", "शिंदखेडा"]],
  nandurbar: [["Taloda", "तळोदा"], ["Shahada", "शहादा"]],
  jalgaon: [["Chopda", "चोपडा"], ["Raver", "रावेर"]],
  ahilyanagar: [["Sangamner", "संगमनेर"], ["Rahuri", "राहुरी"]],
  "chh-sambhajinagar": [["Paithan", "पैठण"], ["Sillod", "सिल्लोड"]],
  jalna: [["Ambad", "अंबड"], ["Ghansawangi", "घनसावंगी"]],
  beed: [["Ashti", "आष्टी"], ["Georai", "गेवराई"]],
  dharashiv: [["Tuljapur", "तुळजापूर"], ["Bhoom", "भूम"]],
  latur: [["Ausa", "औसा"], ["Nilanga", "निलंगा"]],
  nanded: [["Kandhar", "कंधार"], ["Mukhed", "मुखेड"]],
  parbhani: [["Gangakhed", "गंगाखेड"], ["Sonpeth", "सोनपेठ"]],
  hingoli: [["Kalamnuri", "कळमनुरी"], ["Basmath", "बसमत"]],
  amravati: [["Achalpur", "अचलपूर"], ["Chandur Bazar", "चांदूर बाजार"]],
  akola: [["Balapur", "बाळापूर"], ["Murtizapur", "मूर्तिजापूर"]],
  washim: [["Malegaon", "मालेगाव"], ["Risod", "रिसोड"]],
  buldhana: [["Chikhli", "चिखली"], ["Mehkar", "मेहकर"]],
  yavatmal: [["Pusad", "पुसद"], ["Umarkhed", "उमरखेड"]],
  nagpur: [["Katol", "काटोल"], ["Ramtek", "रामटेक"]],
  wardha: [["Hinganghat", "हिंगणघाट"], ["Arvi", "आर्वी"]],
  bhandara: [["Tumsar", "तुमसर"], ["Pauni", "पवनी"]],
  gondia: [["Tirora", "तिरोडा"], ["Arjuni Morgaon", "अर्जुनी मोरगाव"]],
  chandrapur: [["Warora", "वरोरा"], ["Rajura", "राजुरा"]],
  gadchiroli: [["Armori", "आरमोरी"], ["Kurkheda", "कुरखेडा"]],
};

for (const [districtId, blocks] of Object.entries(PS_GP_SAMPLES)) {
  blocks.forEach(([en, mr], index) => {
    localBodies.push(
      LB(`ps-${districtId}-${index}`, `${en} Panchayat Samiti`, `${mr} पंचायत समिती`, "ps", districtId, 10),
    );
    localBodies.push(
      LB(`gp-${districtId}-${index}`, `${en} Gram Panchayat`, `${mr} ग्रामपंचायत`, "gp", districtId, 7),
    );
  });
}

const RESERVATIONS: Ward["reservation"][] = ["general", "women", "obc", "sc", "general", "st", "women"];

/** Wards are derived so every local body always has a valid, non-empty list. */
export const wards: Ward[] = localBodies.flatMap((body) =>
  Array.from({ length: body.wardCount }, (_, i) => {
    const num = String(i + 1).padStart(2, "0");
    const unit =
      body.typeId === "zp"
        ? { en: "Gat", mr: "गट" }
        : body.typeId === "ps"
          ? { en: "Gan", mr: "गण" }
          : body.typeId === "gp"
            ? { en: "Ward", mr: "वॉर्ड" }
            : { en: "Prabhag", mr: "प्रभाग" };
    return {
      id: `${body.id}-w${num}`,
      localBodyId: body.id,
      number: num,
      name: {
        en: `${unit.en} ${num}`,
        mr: `${unit.mr} ${num}`,
      },
      reservation: RESERVATIONS[i % RESERVATIONS.length] ?? "general",
      electors: 2400 + ((i * 733) % 5200),
    } satisfies Ward;
  }),
);

// --- Query helpers (the UI never filters raw arrays itself) ----------------

export const getLocalBodyType = (id?: string) => localBodyTypes.find((t) => t.id === id);
export const getDistrict = (id?: string) => districts.find((d) => d.id === id);
export const getLocalBody = (id?: string) => localBodies.find((b) => b.id === id);
export const getWard = (id?: string) => wards.find((w) => w.id === id);

/** Districts that actually contain at least one body of the chosen type. */
export function districtsForType(typeId?: string): District[] {
  if (!typeId) return [];
  const ids = new Set(localBodies.filter((b) => b.typeId === typeId).map((b) => b.districtId));
  return districts.filter((d) => ids.has(d.id));
}

export function localBodiesFor(typeId?: string, districtId?: string): LocalBody[] {
  if (!typeId || !districtId) return [];
  return localBodies.filter((b) => b.typeId === typeId && b.districtId === districtId);
}

export function wardsFor(localBodyId?: string): Ward[] {
  if (!localBodyId) return [];
  return wards.filter((w) => w.localBodyId === localBodyId);
}

export const geoStats = {
  districts: districts.length,
  localBodies: localBodies.length,
  wards: wards.length,
  divisions: divisions.length,
};
