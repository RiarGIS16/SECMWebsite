import type { Localised } from "@/i18n/i18n";

/**
 * Information architecture.
 *
 * The workbook repeatedly flags a flat, mixed hierarchy (rows 1, 6, 21, 51, 57,
 * 75). The site is therefore organised around audiences and services rather
 * than around the Commission's internal filing structure, and every section is
 * declared once here so the header, mobile navigation, footer and sitemap stay
 * in step.
 */

export type NavLink = {
  to: string;
  label: Localised;
  description?: Localised;
};

export type NavSection = {
  id: string;
  label: Localised;
  /** Landing page for the section. */
  to: string;
  summary: Localised;
  children: NavLink[];
};

/**
 * "About Us" is a standalone top-level menu (it sits immediately after Home)
 * with its own sub-pages, so it is declared separately from the service
 * sections but uses the same shape.
 */
export const aboutSection: NavSection = {
  id: "about",
  label: { en: "About Us", mr: "आमच्याविषयी" },
  to: "/about",
  summary: {
    en: "The Commission's mandate, leadership, history, structure and recognition.",
    mr: "आयोगाचे अधिकार, नेतृत्व, इतिहास, रचना व सन्मान.",
  },
  children: [
    { to: "/about", label: { en: "About the Commission", mr: "आयोगाविषयी" } },
    {
      to: "/about/role",
      label: { en: "Role of the State Election Commission (SEC)", mr: "राज्य निवडणूक आयोगाची भूमिका" },
    },
    {
      to: "/about/commissioner",
      label: { en: "Present Commissioner profile", mr: "विद्यमान आयुक्तांची माहिती" },
    },
    {
      to: "/about/history",
      label: {
        en: "History of the State Election Commission, Maharashtra (SECM)",
        mr: "राज्य निवडणूक आयोग, महाराष्ट्र यांचा इतिहास",
      },
    },
    {
      to: "/about/organisation",
      label: { en: "Organisation chart and directory", mr: "संघटन रचना व निर्देशिका" },
    },
    { to: "/about/protocol", label: { en: "Protocol regarding SEC", mr: "आयोगासंबंधी शिष्टाचार" } },
    {
      to: "/about/awards",
      label: { en: "Milestones, awards and achievements", mr: "टप्पे, पुरस्कार व यश" },
    },
  ],
};

export const importantStatisticsSection: NavSection = {
  id: "statistics",
  label: { en: "Imp Statistics", mr: "महत्त्वाची आकडेवारी" },
  to: "/statistics",
  summary: {
    en: "Local body statistics, published statistical reports and due-election data.",
    mr: "स्थानिक स्वराज्य संस्थांची आकडेवारी, सांख्यिकी अहवाल व मुदतपूर्ती निवडणूक माहिती.",
  },
  children: [
    {
      to: "/statistics",
      label: { en: "Local Bodies Statistics at a Glance", mr: "स्थानिक स्वराज्य संस्था — संक्षिप्त आकडेवारी" },
    },
    {
      to: "/statistics/reports",
      label: { en: "Statistical Reports", mr: "सांख्यिकी अहवाल" },
    },
    {
      to: "/statistics/due-elections",
      label: { en: "Due Election Data", mr: "मुदतपूर्ती निवडणूक माहिती" },
    },
  ],
};

export const navSections: NavSection[] = [
  {
    id: "voter",
    label: { en: "Voters", mr: "मतदार" },
    to: "/voter",
    summary: {
      en: "Check your entry in the local body voter roll, find your ward and polling station.",
      mr: "स्थानिक संस्था मतदार यादीतील नोंद तपासा, प्रभाग व मतदान केंद्र शोधा.",
    },
    children: [
      {
        to: "/voter",
        label: { en: "Search the voter roll", mr: "मतदार यादीत शोधा" },
        description: { en: "Search by name or EPIC number", mr: "नाव किंवा मतदार ओळखपत्र क्रमांकाने शोधा" },
      },
      {
        to: "/voter/polling-station",
        label: { en: "Find your polling station", mr: "मतदान केंद्र शोधा" },
        description: { en: "Ward-wise station and accessibility facilities", mr: "प्रभागनिहाय केंद्र व सुलभता सुविधा" },
      },
      {
        to: "/voter/local-body-roll",
        label: { en: "Local self-government voter list", mr: "स्थानिक स्वराज्य संस्था मतदार यादी" },
        description: { en: "Type → district → local body → ward", mr: "प्रकार → जिल्हा → संस्था → प्रभाग" },
      },
      {
        to: "/voter/objection",
        label: { en: "Objection to a roll entry", mr: "यादी नोंदीवर हरकत" },
        description: { en: "Correction, inclusion or deletion", mr: "दुरुस्ती, समावेश किंवा वगळणी" },
      },
      {
        to: "/voter/awareness",
        label: { en: "Voter awareness orders", mr: "मतदार जागृती आदेश" },
        description: { en: "Orders, campaigns and media", mr: "आदेश, मोहिमा व माध्यम साहित्य" },
      },
    ],
  },
  {
    id: "candidate",
    label: { en: "Candidates", mr: "उमेदवार" },
    to: "/candidate",
    summary: {
      en: "The full candidate journey from eligibility to declaration of result.",
      mr: "पात्रतेपासून निकाल जाहीर होईपर्यंतचा संपूर्ण उमेदवार प्रवास.",
    },
    children: [
      { to: "/candidate", label: { en: "Candidate journey", mr: "उमेदवार प्रवास" } },
      { to: "/candidate/eligibility", label: { en: "Eligibility", mr: "पात्रता" } },
      { to: "/candidate/nomination", label: { en: "Nomination", mr: "नामनिर्देशन" } },
      { to: "/candidate/affidavit", label: { en: "Affidavit search", mr: "प्रतिज्ञापत्र शोध" } },
      { to: "/candidate/expenditure", label: { en: "Expenditure", mr: "निवडणूक खर्च" } },
      { to: "/candidate/list", label: { en: "Contesting candidates", mr: "रिंगणातील उमेदवार" } },
      { to: "/candidate/symbols", label: { en: "Symbol allotment", mr: "चिन्ह वाटप" } },
      { to: "/candidate/results", label: { en: "Result & elected candidate", mr: "निकाल व निर्वाचित उमेदवार" } },
      { to: "/candidate/general-orders", label: { en: "General Instruction – Orders", mr: "सर्वसाधारण सूचना — आदेश" } },
      { to: "/candidate/specific-instructions", label: { en: "Specific Instructions", mr: "विशिष्ट सूचना" } },
    ],
  },
  {
    id: "ro",
    label: { en: "Help for ROs", mr: "निवडणूक निर्णय अधिकाऱ्यांसाठी" },
    to: "/ro",
    summary: {
      en: "Stage-wise workflows, statutory material, forms, checklists and escalation routes.",
      mr: "टप्पानिहाय कार्यपद्धती, कायदेशीर साहित्य, नमुने, तपासणी सूची व उन्नयन मार्ग.",
    },
    children: [
      { to: "/ro", label: { en: "RO workspace", mr: "अधिकारी कार्यक्षेत्र" } },
      { to: "/ro/workflow", label: { en: "Stage-wise workflow", mr: "टप्पानिहाय कार्यपद्धती" } },
      { to: "/ro/constitutional-provisions", label: { en: "Constitutional provisions", mr: "घटनात्मक तरतुदी" } },
      { to: "/ro/acts-and-rules", label: { en: "Acts & rules", mr: "अधिनियम व नियम" } },
      { to: "/ro/handbooks", label: { en: "Handbooks & manuals", mr: "हस्तपुस्तिका व मार्गदर्शिका" } },
      { to: "/ro/forms", label: { en: "Forms & formats", mr: "अर्ज व नमुने" } },
      { to: "/ro/training", label: { en: "Training material", mr: "प्रशिक्षण साहित्य" } },
      { to: "/ro/checklist", label: { en: "Milestone checklist", mr: "टप्पा तपासणी सूची" } },
      { to: "/ro/circulars", label: { en: "Circulars & orders", mr: "परिपत्रके व आदेश" } },
      { to: "/ro/faqs", label: { en: "FAQs", mr: "नेहमीचे प्रश्न" } },
      { to: "/ro/calendar", label: { en: "Important dates", mr: "महत्त्वाचे दिनांक" } },
      { to: "/ro/escalation", label: { en: "Contact & escalation", mr: "संपर्क व उन्नयन" } },
      { to: "/ro/judgments", label: { en: "Important Judgments", mr: "महत्त्वाचे न्यायनिर्णय" } },
    ],
  },
  {
    id: "parties",
    label: { en: "Political parties", mr: "राजकीय पक्ष" },
    to: "/parties",
    summary: {
      en: "Registration, recognition status, reserved symbols and compliance obligations.",
      mr: "नोंदणी, मान्यता स्थिती, राखीव चिन्हे व अनुपालन जबाबदाऱ्या.",
    },
    children: [
      { to: "/parties", label: { en: "Overview", mr: "आढावा" } },
      { to: "/parties/registration", label: { en: "Registration", mr: "नोंदणी" } },
      { to: "/parties/register", label: { en: "Party status register", mr: "पक्ष स्थिती नोंदवही" } },
      { to: "/parties/symbols", label: { en: "Symbol catalogue", mr: "चिन्ह सूची" } },
      { to: "/parties/circulars", label: { en: "Circulars & orders", mr: "परिपत्रके व आदेश" } },
      { to: "/parties/compliance", label: { en: "Compliance calendar", mr: "अनुपालन दिनदर्शिका" } },
      { to: "/parties/contact", label: { en: "Party contact", mr: "पक्ष संपर्क" } },
      { to: "/parties/deregistered", label: { en: "De Registered with SEC", mr: "आयोगाकडून नोंदणी रद्द केलेले" } },
    ],
  },
  {
    id: "elections",
    label: { en: "Elections", mr: "निवडणुका" },
    to: "/elections",
    summary: {
      en: "Election programmes for urban and rural local bodies, and published results.",
      mr: "शहरी व ग्रामीण स्थानिक संस्थांचे निवडणूक कार्यक्रम आणि प्रसिद्ध निकाल.",
    },
    children: [
      { to: "/elections", label: { en: "Election programme", mr: "निवडणूक कार्यक्रम" } },
      { to: "/elections/upcoming", label: { en: "Upcoming elections", mr: "आगामी निवडणुका" } },
      { to: "/elections/ongoing", label: { en: "Ongoing elections", mr: "सुरू असलेल्या निवडणुका" } },
      { to: "/elections/completed", label: { en: "Recently completed", mr: "अलीकडे पूर्ण झालेल्या" } },
      { to: "/elections/results", label: { en: "Results", mr: "निकाल" } },
      { to: "/events", label: { en: "Events", mr: "कार्यक्रम" } },
      { to: "/events/calendar", label: { en: "Event calendar", mr: "कार्यक्रम दिनदर्शिका" } },
      { to: "/events/past", label: { en: "Past events", mr: "मागील कार्यक्रम" } },
      { to: "/events/gallery", label: { en: "Media gallery", mr: "छायाचित्र दालन" } },
    ],
  },
  {
    id: "evm",
    label: { en: "EVM / VVPAT", mr: "ईव्हीएम / व्हीव्हीपॅट" },
    to: "/evm",
    summary: {
      en: "How the machines work, how they are secured, and the orders and training behind them.",
      mr: "यंत्रे कशी चालतात, त्यांची सुरक्षा कशी होते आणि त्यामागील आदेश व प्रशिक्षण.",
    },
    children: [
      { to: "/evm", label: { en: "Knowledge hub", mr: "माहिती केंद्र" } },
      { to: "/evm/demonstration", label: { en: "Demonstration", mr: "प्रात्यक्षिक" } },
      { to: "/evm/faqs", label: { en: "FAQs", mr: "प्रश्नोत्तरे" } },
      { to: "/evm/orders", label: { en: "Orders & circulars", mr: "आदेश व परिपत्रके" } },
      { to: "/evm/security", label: { en: "Security process", mr: "सुरक्षा प्रक्रिया" } },
      { to: "/evm/training", label: { en: "Training", mr: "प्रशिक्षण" } },
    ],
  },
  {
    id: "resources",
    label: { en: "Documents", mr: "दस्तऐवज" },
    to: "/updates",
    summary: {
      en: "One register for notifications, circulars, orders, forms and publications.",
      mr: "अधिसूचना, परिपत्रके, आदेश, नमुने व प्रकाशनांसाठी एकच नोंदवही.",
    },
    children: [
      { to: "/updates", label: { en: "Latest updates", mr: "अलीकडील अद्ययावत" } },
      { to: "/publications", label: { en: "Publications", mr: "प्रकाशने" } },
      { to: "/publications/annual-reports", label: { en: "Annual reports", mr: "वार्षिक अहवाल" } },
      { to: "/publications/statistics", label: { en: "Statistical publications", mr: "सांख्यिकी प्रकाशने" } },
      { to: "/publications/manuals", label: { en: "Manuals", mr: "पुस्तिका" } },
      { to: "/publications/search", label: { en: "Search publications", mr: "प्रकाशने शोधा" } },
      { to: "/statistics", label: { en: "Statistics", mr: "आकडेवारी" } },
    ],
  },
  {
    id: "rti",
    label: { en: "RTI", mr: "माहितीचा अधिकार" },
    to: "/rti",
    summary: {
      en: "Proactive disclosure, information officers, how to apply and how requests were handled.",
      mr: "स्वयंप्रेरित प्रकटीकरण, माहिती अधिकारी, अर्ज कसा करावा व अर्जांची स्थिती.",
    },
    children: [
      { to: "/rti", label: { en: "RTI overview", mr: "आढावा" } },
      { to: "/rti/section-4", label: { en: "Section 4 disclosure", mr: "कलम ४ प्रकटीकरण" } },
      { to: "/rti/officers", label: { en: "PIO / appellate authority", mr: "जन माहिती अधिकारी / अपिलीय प्राधिकारी" } },
      { to: "/rti/process", label: { en: "Application process", mr: "अर्ज प्रक्रिया" } },
      { to: "/rti/reports", label: { en: "RTI reports", mr: "अहवाल" } },
    ],
  },
  {
    id: "connect",
    label: { en: "Contact & help", mr: "संपर्क व मदत" },
    to: "/contact",
    summary: {
      en: "Reach the right desk by purpose, and track anything you have submitted.",
      mr: "कामाच्या स्वरूपानुसार योग्य कक्षाशी संपर्क साधा आणि सादर केलेल्या बाबींचा मागोवा घ्या.",
    },
    children: [
      { to: "/contact", label: { en: "Contact directory", mr: "संपर्क निर्देशिका" } },
      { to: "/feedback", label: { en: "Feedback & grievance", mr: "अभिप्राय व तक्रार" } },
      { to: "/feedback/status", label: { en: "Track a submission", mr: "सादर बाबीचा मागोवा" } },
      { to: "/feedback/accessibility", label: { en: "Accessibility feedback", mr: "सुलभता अभिप्राय" } },
      { to: "/feedback/escalation", label: { en: "Escalation matrix", mr: "उन्नयन तक्ता" } },
      { to: "/feedback/statistics", label: { en: "Public feedback statistics", mr: "अभिप्राय आकडेवारी" } },
      { to: "/about", label: { en: "About the Commission", mr: "आयोगाविषयी" } },
      { to: "/about/awards", label: { en: "Awards & recognition", mr: "पुरस्कार व सन्मान" } },
    ],
  },
];

/**
 * Concise primary menus requested for the global header. The comprehensive
 * section arrays above remain the source for connected pages, the footer and
 * sitemap, so reducing a dropdown never removes access to an existing service.
 */
export const primaryNavSections: NavSection[] = [
  aboutSection,
  importantStatisticsSection,
  {
    ...navSections[0]!,
    label: { en: "Voters", mr: "मतदार" },
    children: [
      { to: "/voter", label: { en: "Search in voter list", mr: "मतदार यादीत शोधा" } },
      { to: "/voter/awareness", label: { en: "Voters Awareness", mr: "मतदार जागृती" } },
    ],
  },
  {
    ...navSections[4]!,
    label: { en: "Election Program", mr: "निवडणूक कार्यक्रम" },
    children: [
      { to: "/elections/completed", label: { en: "Recently Completed Elections", mr: "अलीकडे पूर्ण झालेल्या निवडणुका" } },
      { to: "/elections/ongoing", label: { en: "On Going Elections", mr: "सुरू असलेल्या निवडणुका" } },
      { to: "/elections/upcoming", label: { en: "Upcoming", mr: "आगामी" } },
    ],
  },
  {
    ...navSections[2]!,
    children: [
      { to: "/ro/acts-and-rules", label: { en: "Election Related Acts and Rules", mr: "निवडणूक संबंधित अधिनियम व नियम" } },
      { to: "/ro/handbooks", label: { en: "Handbooks", mr: "हस्तपुस्तिका" } },
      { to: "/ro/circulars", label: { en: "Compendium of Important Orders", mr: "महत्त्वाच्या आदेशांचा संग्रह" } },
      { to: "/ro/training", label: { en: "Training Material", mr: "प्रशिक्षण साहित्य" } },
      { to: "/ro/judgments", label: { en: "Important Judgments", mr: "महत्त्वाचे न्यायनिर्णय" } },
    ],
  },
  {
    ...navSections[1]!,
    label: { en: "Candidate", mr: "उमेदवार" },
    children: [
      { to: "/candidate/general-orders", label: { en: "General Instruction – Orders", mr: "सर्वसाधारण सूचना — आदेश" } },
      { to: "/candidate/specific-instructions", label: { en: "Specific Instructions", mr: "विशिष्ट सूचना" } },
    ],
  },
  {
    ...navSections[3]!,
    label: { en: "Political Party", mr: "राजकीय पक्ष" },
    children: [
      { to: "/parties/circulars", label: { en: "General Orders", mr: "सर्वसाधारण आदेश" } },
      { to: "/parties/register", label: { en: "Registered with SEC", mr: "आयोगाकडे नोंदणीकृत" } },
      { to: "/parties/deregistered", label: { en: "De Registered with SEC", mr: "आयोगाकडून नोंदणी रद्द केलेले" } },
    ],
  },
];

export const remainingPrimaryLinks = navSections.filter((section) =>
  ["evm", "resources", "rti", "connect"].includes(section.id),
);

/**
 * Quick links. `kind` drives the interstitial behaviour flagged in workbook rows
 * 11, 12 and 15: no warning for our own pages, a light notice for other
 * government domains, a full notice only for third-party sites.
 */
export type QuickLink = {
  to: string;
  label: Localised;
  hint: Localised;
  icon: string;
  external?: boolean;
};

export const quickLinks: QuickLink[] = [
  {
    to: "/voter",
    label: { en: "Search voter roll", mr: "मतदार यादीत शोधा" },
    hint: { en: "Name or EPIC number", mr: "नाव किंवा ओळखपत्र क्रमांक" },
    icon: "search",
  },
  {
    to: "/candidate/nomination",
    label: { en: "File a nomination", mr: "नामनिर्देशन दाखल करा" },
    hint: { en: "Steps, forms and fees", mr: "टप्पे, नमुने व शुल्क" },
    icon: "file-text",
  },
  {
    to: "/candidate/affidavit",
    label: { en: "Affidavit search", mr: "प्रतिज्ञापत्र शोध" },
    hint: { en: "Contesting candidate declarations", mr: "रिंगणातील उमेदवारांची घोषणापत्रे" },
    icon: "scale",
  },
  {
    to: "/elections",
    label: { en: "Election programme", mr: "निवडणूक कार्यक्रम" },
    hint: { en: "Urban and rural bodies", mr: "शहरी व ग्रामीण संस्था" },
    icon: "calendar-days",
  },
  {
    to: "/updates",
    label: { en: "Notices & circulars", mr: "सूचना व परिपत्रके" },
    hint: { en: "Filter by type and date", mr: "प्रकार व दिनांकानुसार गाळा" },
    icon: "scroll-text",
  },
  {
    to: "/feedback",
    label: { en: "Raise a grievance", mr: "तक्रार नोंदवा" },
    hint: { en: "Tracked with a reference ID", mr: "संदर्भ क्रमांकासह मागोवा" },
    icon: "message-square",
  },
];
