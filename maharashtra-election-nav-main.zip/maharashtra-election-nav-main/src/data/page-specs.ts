import type { Localised } from "@/i18n/i18n";

/**
 * Content model for the sub-pages added in this update cycle.
 *
 * Each entry declares exactly what a record on that page must carry, which
 * filters the page offers and which actions it supports. Official values are
 * deliberately absent: the structure is here so the Commission's CMS/API can
 * populate it, and nothing on screen pretends to be verified official data.
 */

export type PageSpec = {
  title: Localised;
  intro: Localised;
  /** Fields every record on this page carries. */
  fields: string[];
  /** Filters offered above the listing. */
  filters?: string[];
  /** Interactions the page supports. */
  actions?: string[];
  /** Office/system expected to supply the content. */
  source: Localised;
};

const areaFilters = ["Local body type", "District", "Local body", "Ward"];
const docFields = [
  "Title",
  "Document type",
  "Reference number",
  "Issue date",
  "Issuing authority",
  "Language (English / Marathi)",
  "Status (current, in-force, superseded, repealed, archived)",
  "Version",
  "Last reviewed",
];

export const pageSpecs: Record<string, PageSpec> = {
  "/statistics/reports": {
    title: { en: "Statistical Reports", mr: "सांख्यिकी अहवाल" },
    intro: {
      en: "Published statistical reports for local body elections, supplied and verified by the Commission.",
      mr: "स्थानिक स्वराज्य संस्था निवडणुकांचे प्रसिद्ध सांख्यिकी अहवाल, आयोगाकडून पुरवले व पडताळलेले.",
    },
    fields: [...docFields, "Reference period", "Geographic coverage", "Accessible data table"],
    filters: ["Search", "Report year", "Local body type", "District", "Language"],
    actions: ["Search", "Preview", "Read accessible table", "Download"],
    source: { en: "Statistics Section", mr: "सांख्यिकी कक्ष" },
  },
  "/statistics/due-elections": {
    title: { en: "Due Election Data", mr: "मुदतपूर्ती निवडणूक माहिती" },
    intro: {
      en: "Local bodies approaching an election cycle, published only after verification by the Commission.",
      mr: "निवडणूक चक्राजवळ असलेल्या स्थानिक स्वराज्य संस्था; आयोगाच्या पडताळणीनंतरच प्रसिद्ध केल्या जातील.",
    },
    fields: ["Local body type", "District", "Local body", "Term status", "Reference period", "Verification status", "Supporting order"],
    filters: [...areaFilters, "Reference period", "Verification status"],
    actions: ["Search", "View accessible table", "Export CSV / XLSX", "Open supporting order"],
    source: { en: "Election Programme Section / Statistics Section", mr: "निवडणूक कार्यक्रम कक्ष / सांख्यिकी कक्ष" },
  },
  "/about/role": {
    title: { en: "Role of the State Election Commission", mr: "राज्य निवडणूक आयोगाची भूमिका" },
    intro: {
      en: "Mandate, powers and duties of the Commission for local self-government elections, as supplied by the Commission.",
      mr: "स्थानिक स्वराज्य संस्था निवडणुकांसाठी आयोगाचे अधिकार व कर्तव्ये, आयोगाकडून पुरवली जाणारी माहिती.",
    },
    fields: [
      "Statement of mandate",
      "Powers and functions",
      "Constitutional and statutory basis (reference only)",
      "Bodies covered",
      "Related document links",
      "Last reviewed",
    ],
    actions: ["Read", "Open related documents"],
    source: { en: "Secretariat / Legal Section", mr: "सचिवालय / विधी कक्ष" },
  },

  "/about/commissioner": {
    title: { en: "Present Commissioner profile", mr: "विद्यमान आयुक्तांची माहिती" },
    intro: {
      en: "Profile of the serving State Election Commissioner. Name, photograph and service record are supplied by the Commission.",
      mr: "विद्यमान राज्य निवडणूक आयुक्तांची माहिती. नाव, छायाचित्र व सेवा तपशील आयोगाकडून पुरवले जातात.",
    },
    fields: [
      "Name",
      "Designation",
      "Photograph",
      "Date of assuming office",
      "Educational background",
      "Service record",
      "Message to citizens",
    ],
    actions: ["Read profile", "Download photograph"],
    source: { en: "Commissioner's Office", mr: "आयुक्त कार्यालय" },
  },

  "/about/history": {
    title: {
      en: "History of the State Election Commission, Maharashtra",
      mr: "राज्य निवडणूक आयोग, महाराष्ट्र यांचा इतिहास",
    },
    intro: {
      en: "Timeline of the Commission from its establishment onwards, with milestones and former Commissioners.",
      mr: "स्थापनेपासूनचा आयोगाचा कालानुक्रम, महत्त्वाचे टप्पे व माजी आयुक्तांसह.",
    },
    fields: [
      "Year",
      "Milestone title",
      "Description",
      "Former Commissioner name and tenure",
      "Supporting document or photograph",
    ],
    filters: ["Decade", "Year"],
    actions: ["Browse timeline", "Preview supporting document"],
    source: { en: "Administration Section", mr: "प्रशासन कक्ष" },
  },

  "/about/organisation": {
    title: { en: "Organisation chart and directory", mr: "संघटन रचना व निर्देशिका" },
    intro: {
      en: "Structure of the Commission and the officer directory for each section, with designation-level contact routes.",
      mr: "आयोगाची रचना व प्रत्येक कक्षाची अधिकारी निर्देशिका, पदनिहाय संपर्क मार्गासह.",
    },
    fields: [
      "Section / unit name",
      "Reporting level",
      "Designation",
      "Officer name",
      "Office telephone",
      "Official email",
      "Office address",
      "Last updated",
    ],
    filters: ["Section / unit", "Designation"],
    actions: ["Search directory", "View chart", "Download chart"],
    source: { en: "Administration Section", mr: "प्रशासन कक्ष" },
  },

  "/about/protocol": {
    title: { en: "Protocol regarding the Commission", mr: "आयोगासंबंधी शिष्टाचार" },
    intro: {
      en: "Protocol and precedence orders applicable to the Commission and its officers, as issued by the competent authority.",
      mr: "आयोग व त्यांच्या अधिकाऱ्यांना लागू शिष्टाचार व अग्रक्रम आदेश, सक्षम प्राधिकाऱ्याकडून निर्गमित.",
    },
    fields: docFields,
    filters: ["Issue date range", "Issuing authority", "Status"],
    actions: ["Search", "Preview", "Download"],
    source: { en: "General Administration Department", mr: "सामान्य प्रशासन विभाग" },
  },

  "/about/awards": {
    title: { en: "Awards & recognition", mr: "पुरस्कार व सन्मान" },
    intro: {
      en: "Awards received by the Commission, with the issuing organisation and supporting record for each.",
      mr: "आयोगाला मिळालेले पुरस्कार, प्रदान करणारी संस्था व आधारभूत नोंदीसह.",
    },
    fields: [
      "Award name",
      "Award category",
      "Award date",
      "Issuing organisation",
      "Description",
      "Supporting document or photograph",
      "Archive flag",
    ],
    filters: ["Year", "Category", "Issuing organisation"],
    actions: ["Search", "Preview supporting document", "View archive"],
    source: { en: "Administration Section", mr: "प्रशासन कक्ष" },
  },

  "/voter/local-body-roll": {
    title: { en: "Local self-government voter list", mr: "स्थानिक स्वराज्य संस्था मतदार यादी" },
    intro: {
      en: "Dependent search: choose local body type, then district, then local body, then ward. Only valid combinations are offered.",
      mr: "अवलंबित शोध: संस्था प्रकार, नंतर जिल्हा, स्थानिक संस्था व प्रभाग निवडा. केवळ वैध संयोजने दिसतात.",
    },
    fields: ["Part number", "Serial number", "Elector name", "Relation name", "Age", "Polling station", "Ward"],
    filters: [...areaFilters, "First name", "Last name", "EPIC number"],
    actions: ["Search", "Clear filters", "Retry", "Download part list", "Report a mistake"],
    source: { en: "Electoral Roll Section", mr: "मतदार यादी कक्ष" },
  },

  "/voter/awareness": {
    title: { en: "Voter awareness orders", mr: "मतदार जागृती आदेश" },
    intro: {
      en: "Orders, circulars and campaign material on voter awareness, filterable by date, category and year.",
      mr: "मतदार जागृतीविषयक आदेश, परिपत्रके व प्रचार साहित्य; दिनांक, वर्ग व वर्षानुसार गाळता येते.",
    },
    fields: [...docFields, "Campaign", "Media type (document, photo, video)", "Alt text / caption"],
    filters: ["Date range", "Category", "Year", "Document type", "District"],
    actions: ["Search", "Preview", "Download", "Open media gallery"],
    source: { en: "Voter Awareness (SVEEP) Cell", mr: "मतदार जागृती (स्वीप) कक्ष" },
  },

  "/elections/upcoming": {
    title: { en: "Upcoming elections", mr: "आगामी निवडणुका" },
    intro: {
      en: "Only officially notified programmes appear here. Nothing speculative is published.",
      mr: "येथे केवळ अधिकृतपणे अधिसूचित कार्यक्रम दिसतात. अंदाजित माहिती प्रसिद्ध केली जात नाही.",
    },
    fields: [
      "Election type",
      "Local body type",
      "District",
      "Local body",
      "Notification date",
      "Nomination dates",
      "Scrutiny date",
      "Withdrawal date",
      "Polling date",
      "Counting date",
      "Official notification document",
    ],
    filters: [...areaFilters, "Election type", "Date range"],
    actions: ["Search", "Preview notification", "Add to calendar (.ics)"],
    source: { en: "Election Programme Section", mr: "निवडणूक कार्यक्रम कक्ष" },
  },

  "/elections/ongoing": {
    title: { en: "Ongoing elections", mr: "सुरू असलेल्या निवडणुका" },
    intro: {
      en: "Live status of every election currently in progress, stage by stage.",
      mr: "सध्या सुरू असलेल्या प्रत्येक निवडणुकीची टप्पानिहाय सद्यस्थिती.",
    },
    fields: [
      "Election type",
      "District",
      "Local body",
      "Current stage",
      "Stage start and end dates",
      "Next milestone",
      "Official notices issued",
      "Status updated at",
    ],
    filters: [...areaFilters, "Election type", "Stage"],
    actions: ["Search", "Open notices", "Follow the programme"],
    source: { en: "Election Programme Section", mr: "निवडणूक कार्यक्रम कक्ष" },
  },

  "/elections/completed": {
    title: { en: "Recently completed elections", mr: "अलीकडे पूर्ण झालेल्या निवडणुका" },
    intro: {
      en: "Concluded programmes with their result documents and closing orders.",
      mr: "पूर्ण झालेले कार्यक्रम, निकाल दस्तऐवज व समारोप आदेशांसह.",
    },
    fields: [
      "Election type",
      "Local body type",
      "District",
      "Local body",
      "Year",
      "Polling date",
      "Counting date",
      "Result document",
      "Turnout",
    ],
    filters: [...areaFilters, "Election type", "Year", "Date range"],
    actions: ["Search", "Preview result", "Download", "Open result register"],
    source: { en: "Results Section", mr: "निकाल कक्ष" },
  },

  "/ro/constitutional-provisions": {
    title: { en: "Constitutional provisions", mr: "घटनात्मक तरतुदी" },
    intro: {
      en: "Article-wise reference for Returning Officers, linked to the Acts, rules and forms each provision drives.",
      mr: "निवडणूक निर्णय अधिकाऱ्यांसाठी अनुच्छेदनिहाय संदर्भ; संबंधित अधिनियम, नियम व नमुन्यांशी जोडलेला.",
    },
    fields: [
      "Article number",
      "Article heading",
      "Election relevance",
      "Plain-language explanation",
      "Related Acts and rules",
      "Related circulars",
      "Related forms",
    ],
    filters: ["Search", "Election type", "Article range"],
    actions: ["Search", "Jump to related rule", "Preview document"],
    source: { en: "Law Section", mr: "विधी कक्ष" },
  },

  "/ro/handbooks": {
    title: { en: "Handbooks & manuals", mr: "हस्तपुस्तिका व मार्गदर्शिका" },
    intro: {
      en: "Manual content broken down as election stage → task → guidance → rule → form → checklist, instead of one large file.",
      mr: "एका मोठ्या फाइलऐवजी टप्पा → कार्य → मार्गदर्शन → नियम → नमुना → तपासणी सूची अशी रचना.",
    },
    fields: [
      "Election stage",
      "Task",
      "Guidance text",
      "Governing rule",
      "Linked form",
      "Linked checklist item",
      "Current / archived",
      "Language (English / Marathi)",
    ],
    filters: ["Search", "Election stage", "Category", "Status", "Language"],
    actions: ["Search", "Expand a task", "Preview", "Download the full manual"],
    source: { en: "Training & Capacity Building Section", mr: "प्रशिक्षण व क्षमता बांधणी कक्ष" },
  },

  "/ro/training": {
    title: { en: "Training material", mr: "प्रशिक्षण साहित्य" },
    intro: {
      en: "Modular training: induction, statutory framework, nomination, polling, counting and case studies.",
      mr: "मॉड्यूलनिहाय प्रशिक्षण: प्रवेशिका, वैधानिक चौकट, नामनिर्देशन, मतदान, मतमोजणी व अभ्यासप्रकरणे.",
    },
    fields: [
      "Module name",
      "Mandatory or reference",
      "Video (captioned)",
      "PDF",
      "Presentation",
      "Self-check assessment",
      "Completion status",
      "Duration",
    ],
    filters: ["Module", "Role", "Mandatory / reference", "Language"],
    actions: ["Open module", "Mark complete", "Take self-check", "Download material"],
    source: { en: "Training & Capacity Building Section", mr: "प्रशिक्षण व क्षमता बांधणी कक्ष" },
  },

  "/ro/circulars": {
    title: { en: "Circulars & orders for ROs", mr: "अधिकाऱ्यांसाठी परिपत्रके व आदेश" },
    intro: {
      en: "One register for RO instructions, categorised by election stage and kept in force / superseded.",
      mr: "अधिकाऱ्यांच्या सूचनांची एकच नोंदवही; टप्पानिहाय वर्गीकरण व अंमलात/अधिक्रमित स्थिती.",
    },
    fields: [...docFields, "Election stage", "Superseded by"],
    filters: [
      "Search",
      "Category (nomination, EVM, polling, polling staff, expenditure, counting, model code, results)",
      "Year",
      "Authority",
      "Election stage",
      "Status",
    ],
    actions: ["Search", "Preview", "Download", "Show superseding order"],
    source: { en: "Election Operations Section", mr: "निवडणूक संचालन कक्ष" },
  },

  "/ro/faqs": {
    title: { en: "FAQs for Returning Officers", mr: "अधिकाऱ्यांसाठी नेहमीचे प्रश्न" },
    intro: {
      en: "Questions grouped by election stage, each answer linked to the rule, circular or form behind it.",
      mr: "टप्पानिहाय प्रश्न; प्रत्येक उत्तर संबंधित नियम, परिपत्रक किंवा नमुन्याशी जोडलेले.",
    },
    fields: ["Question", "Answer", "Election stage", "Related rule", "Related circular", "Related form", "Last reviewed"],
    filters: ["Search", "Election stage", "Category"],
    actions: ["Search", "Expand answer", "Mark helpful / not helpful"],
    source: { en: "Election Operations Section", mr: "निवडणूक संचालन कक्ष" },
  },

  "/candidate/results": {
    title: { en: "Result & elected candidate", mr: "निकाल व निर्वाचित उमेदवार" },
    intro: {
      en: "A single candidate record that links nomination, affidavit, symbol, votes polled and declared result.",
      mr: "नामनिर्देशन, प्रतिज्ञापत्र, चिन्ह, मिळालेली मते व जाहीर निकाल एकत्र जोडणारी उमेदवार नोंद.",
    },
    fields: [
      "Candidate name",
      "Ward and local body",
      "Party / independent",
      "Symbol",
      "Nomination reference",
      "Affidavit link",
      "Votes polled",
      "Result (elected / not elected)",
      "Stable candidate URL",
    ],
    filters: [...areaFilters, "Election type", "Party", "Year"],
    actions: ["Search", "Sort", "Export CSV / XLSX", "Open candidate profile"],
    source: { en: "Results Section", mr: "निकाल कक्ष" },
  },

  "/candidate/general-orders": {
    title: { en: "General Instruction – Orders", mr: "सर्वसाधारण सूचना — आदेश" },
    intro: {
      en: "General instructions and orders applicable to candidates, published with status and supersession details.",
      mr: "उमेदवारांना लागू सर्वसाधारण सूचना व आदेश, स्थिती व अधिक्रमण तपशीलासह.",
    },
    fields: docFields,
    filters: ["Search", "Issue date range", "Election type", "Status", "Language"],
    actions: ["Search", "Preview", "Download", "Show superseding order"],
    source: { en: "Election Operations Section", mr: "निवडणूक संचालन कक्ष" },
  },

  "/candidate/specific-instructions": {
    title: { en: "Specific Instructions", mr: "विशिष्ट सूचना" },
    intro: {
      en: "Election- and stage-specific candidate instructions supplied by the competent Commission section.",
      mr: "सक्षम आयोग कक्षाकडून पुरवलेल्या निवडणूक व टप्पानिहाय उमेदवार सूचना.",
    },
    fields: [...docFields, "Election type", "Election stage", "Applicable audience"],
    filters: ["Search", "Election type", "Election stage", "Issue date range", "Status"],
    actions: ["Search", "Preview", "Download"],
    source: { en: "Election Operations Section", mr: "निवडणूक संचालन कक्ष" },
  },

  "/ro/judgments": {
    title: { en: "Important Judgments", mr: "महत्त्वाचे न्यायनिर्णय" },
    intro: {
      en: "Important court judgments relevant to Returning Officers, indexed without paraphrasing legal findings as official advice.",
      mr: "निवडणूक निर्णय अधिकाऱ्यांशी संबंधित महत्त्वाचे न्यायनिर्णय; कायदेशीर निष्कर्षांचा अधिकृत सल्ला म्हणून अर्थ न लावता सूचीबद्ध.",
    },
    fields: ["Case title", "Court", "Case number", "Decision date", "Subject", "Official judgment document", "Related Act or rule", "Last reviewed"],
    filters: ["Search", "Court", "Decision date range", "Subject", "Election type"],
    actions: ["Search", "Preview official judgment", "Download"],
    source: { en: "Law Section", mr: "विधी कक्ष" },
  },

  "/parties/circulars": {
    title: { en: "Party circulars & orders", mr: "पक्षविषयक परिपत्रके व आदेश" },
    intro: {
      en: "Orders addressed to political parties, filterable by party, election, category and year.",
      mr: "राजकीय पक्षांसाठीचे आदेश; पक्ष, निवडणूक, वर्ग व वर्षानुसार गाळता येतात.",
    },
    fields: [...docFields, "Party", "Order category"],
    filters: ["Search", "Party", "Election", "Order category", "Year", "Authority", "Status"],
    actions: ["Search", "Preview", "Download"],
    source: { en: "Political Party Section", mr: "राजकीय पक्ष कक्ष" },
  },

  "/parties/contact": {
    title: { en: "Party contact & routing", mr: "पक्ष संपर्क व मार्गनिर्देशन" },
    intro: {
      en: "Reach the right desk by purpose: registration, recognition, symbols or compliance.",
      mr: "कामाच्या स्वरूपानुसार योग्य कक्षाशी संपर्क: नोंदणी, मान्यता, चिन्हे किंवा अनुपालन.",
    },
    fields: ["Purpose", "Designation", "Jurisdiction", "Phone", "Email", "Office address", "Response window", "Last verified"],
    filters: ["Purpose", "Jurisdiction"],
    actions: ["Call (tel:)", "Email (mailto:)", "Copy address"],
    source: { en: "Political Party Section", mr: "राजकीय पक्ष कक्ष" },
  },

  "/parties/deregistered": {
    title: { en: "De Registered with SEC", mr: "आयोगाकडून नोंदणी रद्द केलेले" },
    intro: {
      en: "Parties whose SEC registration status is recorded as de-registered, shown only from verified Commission records.",
      mr: "आयोगाच्या पडताळलेल्या नोंदीनुसार नोंदणी रद्द स्थिती असलेले पक्ष.",
    },
    fields: ["Party name", "Registration reference", "De-registration order", "Effective date", "Status", "Last verified"],
    filters: ["Search", "Effective date range", "Status"],
    actions: ["Search", "Preview order", "Download"],
    source: { en: "Political Party Section", mr: "राजकीय पक्ष कक्ष" },
  },

  "/events/calendar": {
    title: { en: "Event calendar", mr: "कार्यक्रम दिनदर्शिका" },
    intro: {
      en: "Month and list views of workshops, trainings, hearings and awareness drives, with a text alternative.",
      mr: "कार्यशाळा, प्रशिक्षण, सुनावणी व जागृती उपक्रमांचे मासिक व यादी स्वरूप, मजकूर पर्यायासह.",
    },
    fields: ["Event title", "Date and time", "Event type", "District", "Venue", "Organising officer"],
    filters: ["Month", "Date range", "District", "Event type"],
    actions: ["Switch month / list view", "Export .ics", "Add to Google Calendar", "Keyboard navigation"],
    source: { en: "Events Cell", mr: "कार्यक्रम कक्ष" },
  },

  "/events/past": {
    title: { en: "Past events archive", mr: "मागील कार्यक्रम संग्रह" },
    intro: {
      en: "Concluded events with their report, photographs, presentation and circular.",
      mr: "पूर्ण झालेले कार्यक्रम; अहवाल, छायाचित्रे, सादरीकरण व परिपत्रकासह.",
    },
    fields: ["Event title", "Date", "Event type", "District", "Report", "Photographs", "Presentation", "Circular", "Archived label"],
    filters: ["Search", "Year", "Event type", "District"],
    actions: ["Search", "Preview report", "Open gallery", "Download"],
    source: { en: "Events Cell", mr: "कार्यक्रम कक्ष" },
  },

  "/events/gallery": {
    title: { en: "Media gallery", mr: "छायाचित्र दालन" },
    intro: {
      en: "Event photographs and video, each with a caption, descriptive alt text and usage metadata.",
      mr: "कार्यक्रमांची छायाचित्रे व चित्रफिती; प्रत्येकासोबत शीर्षक, वर्णनात्मक पर्यायी मजकूर व वापर माहिती.",
    },
    fields: ["Caption", "Descriptive alt text", "Event name", "Event date", "Location", "Category", "Usage / credit"],
    filters: ["Event", "Year", "District", "Category"],
    actions: ["Filter", "Open full size", "Keyboard navigation", "Download"],
    source: { en: "Media Cell", mr: "प्रसिद्धी कक्ष" },
  },

  "/publications/annual-reports": {
    title: { en: "Annual reports", mr: "वार्षिक अहवाल" },
    intro: {
      en: "Year-wise archive with an executive summary and an accessible PDF for each year.",
      mr: "वर्षनिहाय संग्रह; प्रत्येक वर्षासाठी सारांश व सुलभ पीडीएफ.",
    },
    fields: ["Year", "Executive summary", "Accessible PDF", "HTML alternative", "Language", "Missing-year indicator"],
    filters: ["Year", "Language"],
    actions: ["Preview", "Download", "Read HTML version"],
    source: { en: "Planning & Reports Section", mr: "नियोजन व अहवाल कक्ष" },
  },

  "/publications/statistics": {
    title: { en: "Statistical publications", mr: "सांख्यिकी प्रकाशने" },
    intro: {
      en: "Every dataset published as PDF, CSV and XLSX with a data dictionary and an accessible HTML table.",
      mr: "प्रत्येक संच पीडीएफ, सीएसव्ही व एक्सएलएसएक्समध्ये; डेटा शब्दकोश व सुलभ तक्त्यासह.",
    },
    fields: ["Dataset title", "Reference period", "Source", "Last verified", "PDF", "CSV", "XLSX", "Data dictionary"],
    filters: ["Search", "Subject", "Year", "District", "Election type"],
    actions: ["Search", "View HTML table", "Download CSV / XLSX", "Open data dictionary"],
    source: { en: "Statistics Section", mr: "सांख्यिकी कक्ष" },
  },

  "/publications/manuals": {
    title: { en: "Manuals & handbooks", mr: "पुस्तिका व हस्तपुस्तिका" },
    intro: {
      en: "Current and archived editions side by side, with version, issue date and superseding edition.",
      mr: "चालू व संग्रहित आवृत्त्या एकत्र; आवृत्ती क्रमांक, प्रकाशन दिनांक व अधिक्रमित आवृत्तीसह.",
    },
    fields: ["Title", "Version", "Issue date", "Status (current / archived)", "Superseded by", "Language", "Accessible PDF"],
    filters: ["Search", "Subject", "Status", "Year", "Language"],
    actions: ["Preview", "Download", "Compare with previous edition"],
    source: { en: "Publications Section", mr: "प्रकाशन कक्ष" },
  },

  "/publications/search": {
    title: { en: "Search publications", mr: "प्रकाशने शोधा" },
    intro: {
      en: "Full-text search across published documents, with result snippets and inline preview.",
      mr: "प्रसिद्ध दस्तऐवजांमध्ये संपूर्ण मजकूर शोध; निकालांचे उतारे व थेट पूर्वावलोकनासह.",
    },
    fields: ["Matched document", "Snippet", "Page number", "Document type", "Year", "Language"],
    filters: ["Keyword", "Subject", "Year", "Language", "Document type", "Owner"],
    actions: ["Full-text search", "OCR search for scanned files", "Inline preview", "Download"],
    source: { en: "Publications Section", mr: "प्रकाशन कक्ष" },
  },

  "/rti/section-4": {
    title: { en: "Section 4 proactive disclosure", mr: "कलम ४ स्वयंप्रेरित प्रकटीकरण" },
    intro: {
      en: "Each disclosure item with its owning office, update frequency and completeness status.",
      mr: "प्रत्येक बाबीसाठी जबाबदार कक्ष, अद्ययावत वारंवारता व पूर्णत्व स्थिती.",
    },
    fields: ["Disclosure item", "Owner", "Last updated", "Update frequency", "Completeness status", "Document"],
    filters: ["Section 4 clause", "Owner", "Status"],
    actions: ["Preview", "Download", "Report an omission"],
    source: { en: "RTI Cell", mr: "माहिती अधिकार कक्ष" },
  },

  "/rti/officers": {
    title: { en: "PIO & appellate authority", mr: "जन माहिती अधिकारी व अपिलीय प्राधिकारी" },
    intro: {
      en: "Searchable directory of information officers by jurisdiction.",
      mr: "कार्यक्षेत्रानुसार माहिती अधिकाऱ्यांची शोधण्याजोगी निर्देशिका.",
    },
    fields: ["Jurisdiction", "Officer", "Designation", "Role (PIO / APIO / appellate)", "Email", "Phone", "Address", "Last verified"],
    filters: ["Search", "Jurisdiction", "Role"],
    actions: ["Search", "Call (tel:)", "Email (mailto:)"],
    source: { en: "RTI Cell", mr: "माहिती अधिकार कक्ष" },
  },

  "/rti/process": {
    title: { en: "RTI application process", mr: "माहिती अधिकार अर्ज प्रक्रिया" },
    intro: {
      en: "Plain-language walkthrough: application, fee, submission, timeline, response and first appeal.",
      mr: "सोप्या भाषेत टप्पे: अर्ज, शुल्क, सादरीकरण, कालमर्यादा, उत्तर व प्रथम अपील.",
    },
    fields: ["Step", "What you do", "Fee", "Statutory timeline", "Online option", "Offline option", "Form"],
    actions: ["Follow the steps", "Download the form", "Open the online portal"],
    source: { en: "RTI Cell", mr: "माहिती अधिकार कक्ष" },
  },

  "/rti/reports": {
    title: { en: "RTI reports", mr: "माहिती अधिकार अहवाल" },
    intro: {
      en: "Applications received, disposed, pending, appeals and response times — chart plus accessible table.",
      mr: "प्राप्त, निकाली, प्रलंबित अर्ज, अपिले व उत्तर कालावधी — आलेख व सुलभ तक्ता.",
    },
    fields: ["Period", "Applications received", "Disposed", "Pending", "Appeals", "Average response time"],
    filters: ["Year", "Quarter", "Office"],
    actions: ["View chart", "View accessible table", "Download CSV"],
    source: { en: "RTI Cell", mr: "माहिती अधिकार कक्ष" },
  },

  "/evm/demonstration": {
    title: { en: "EVM & VVPAT demonstration", mr: "ईव्हीएम व व्हीव्हीपॅट प्रात्यक्षिक" },
    intro: {
      en: "Captioned demonstration video, full transcript and a step-by-step illustrated walkthrough.",
      mr: "उपशीर्षकांसह प्रात्यक्षिक चित्रफीत, संपूर्ण संहिता व टप्पानिहाय सचित्र मार्गदर्शन.",
    },
    fields: ["Step", "What happens", "Illustration with alt text", "Video with captions", "Transcript", "Language"],
    actions: ["Play video", "Read transcript", "Step through the walkthrough"],
    source: { en: "EVM Cell", mr: "ईव्हीएम कक्ष" },
  },

  "/evm/faqs": {
    title: { en: "EVM & VVPAT FAQs", mr: "ईव्हीएम व व्हीव्हीपॅट प्रश्नोत्तरे" },
    intro: {
      en: "Questions grouped as myths, process, security, VVPAT and troubleshooting.",
      mr: "गैरसमज, प्रक्रिया, सुरक्षा, व्हीव्हीपॅट व अडचणी अशा गटांत प्रश्न.",
    },
    fields: ["Question", "Answer", "Category", "Related document", "Last reviewed"],
    filters: ["Search", "Category", "Language"],
    actions: ["Search", "Expand answer", "Mark helpful / not helpful"],
    source: { en: "EVM Cell", mr: "ईव्हीएम कक्ष" },
  },

  "/evm/orders": {
    title: { en: "EVM orders & circulars", mr: "ईव्हीएम आदेश व परिपत्रके" },
    intro: {
      en: "Operational orders kept separate from public awareness material.",
      mr: "प्रचालन आदेश व जनजागृती साहित्य स्वतंत्रपणे.",
    },
    fields: [...docFields, "Track (operational / public awareness)"],
    filters: ["Search", "Track", "Year", "Authority", "Election stage", "Status"],
    actions: ["Search", "Preview", "Download"],
    source: { en: "EVM Cell", mr: "ईव्हीएम कक्ष" },
  },

  "/evm/security": {
    title: { en: "EVM security process", mr: "ईव्हीएम सुरक्षा प्रक्रिया" },
    intro: {
      en: "Storage → transportation → randomisation → polling → sealing → strong room → counting, as a diagram and as text carrying the same information.",
      mr: "साठवण → वाहतूक → संगणकीय सरमिसळ → मतदान → सीलबंद → स्ट्राँग रूम → मतमोजणी; आकृती व तेवढीच माहिती देणारा मजकूर.",
    },
    fields: ["Stage", "What happens", "Who is present", "Records maintained", "Safeguard", "Governing instruction"],
    actions: ["View diagram", "Read the text version", "Open the governing order"],
    source: { en: "EVM Cell", mr: "ईव्हीएम कक्ष" },
  },

  "/evm/training": {
    title: { en: "EVM training", mr: "ईव्हीएम प्रशिक्षण" },
    intro: {
      en: "Role-based modules for polling officers, presiding officers, Returning Officers and technical support.",
      mr: "मतदान अधिकारी, केंद्राध्यक्ष, निवडणूक निर्णय अधिकारी व तांत्रिक साहाय्यकांसाठी भूमिकानिहाय मॉड्यूल.",
    },
    fields: ["Role", "Module", "Mandatory or reference", "Video", "PDF", "Assessment", "Completion status"],
    filters: ["Role", "Module", "Mandatory / reference"],
    actions: ["Open module", "Mark complete", "Download material"],
    source: { en: "EVM Cell", mr: "ईव्हीएम कक्ष" },
  },

  "/feedback/accessibility": {
    title: { en: "Accessibility feedback", mr: "सुलभता अभिप्राय" },
    intro: {
      en: "Report a barrier on this website. Accessibility reports are handled on priority.",
      mr: "या संकेतस्थळावरील अडथळा कळवा. सुलभताविषयक तक्रारी प्राधान्याने हाताळल्या जातात.",
    },
    fields: [
      "Barrier type",
      "Assistive technology used",
      "Page or component affected",
      "Description",
      "Contact details",
      "Priority flag",
      "Tracking ID",
    ],
    actions: ["Submit", "Receive tracking ID", "Track status"],
    source: { en: "Web Accessibility Cell", mr: "संकेतस्थळ सुलभता कक्ष" },
  },

  "/feedback/escalation": {
    title: { en: "Feedback escalation matrix", mr: "अभिप्राय उन्नयन तक्ता" },
    intro: {
      en: "Who to approach if a submission is not answered within its service window.",
      mr: "ठरलेल्या कालावधीत उत्तर न मिळाल्यास कोणाकडे जावे.",
    },
    fields: ["Level 1 officer", "Level 2 officer", "Responsible role", "Phone", "Email", "Service window (SLA)", "Auto-escalation after"],
    filters: ["Category", "Jurisdiction"],
    actions: ["Call (tel:)", "Email (mailto:)", "Escalate a tracked submission"],
    source: { en: "Public Grievance Cell", mr: "लोक तक्रार कक्ष" },
  },

  "/feedback/statistics": {
    title: { en: "Public feedback statistics", mr: "सार्वजनिक अभिप्राय आकडेवारी" },
    intro: {
      en: "High-level disposal figures only, shown as a chart, a table and a text equivalent.",
      mr: "केवळ ठळक निपटारा आकडेवारी; आलेख, तक्ता व मजकूर स्वरूपात.",
    },
    fields: ["Period", "Received", "Disposed", "Pending", "Within service window", "Category-wise split"],
    filters: ["Year", "Quarter", "Category"],
    actions: ["View chart", "View accessible table", "Read text summary"],
    source: { en: "Public Grievance Cell", mr: "लोक तक्रार कक्ष" },
  },
};

export function getPageSpec(path: string): PageSpec | undefined {
  return pageSpecs[path];
}

/** Route `head()` metadata derived from a page spec (English, for crawlers). */
export function specHead(path: string) {
  const spec = pageSpecs[path];
  const title = spec ? `${spec.title.en} — State Election Commission, Maharashtra` : "State Election Commission, Maharashtra";
  const description = spec?.intro.en ?? "Services for voters, candidates, political parties and Returning Officers.";
  return {
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  };
}
