# SECM navigation update and GIGW 3.0 alignment

## Goal
Update the existing global navigation without rebuilding the site. Match the requested menu order and labels from the reference screenshots, retain all working pages, and keep English/Marathi, mobile, keyboard, and screen-reader behaviour consistent.

## Navigation changes

1. Keep **Home** first and **About Us** second.
2. Add **Imp Statistics** immediately after About Us with:
   - Local Bodies Statistics at a Glance
   - Statistical Reports
   - Due Election Data
3. Place **Voters** next with the requested visible choices:
   - Search in voter list
   - Voters Awareness
4. Place **Election Program** immediately after Voters with:
   - Recently Completed Elections
   - On Going Elections
   - Upcoming
5. Update **Help for ROs** to show:
   - Election Related Acts and Rules
   - Handbooks
   - Compendium of Important Orders
   - Training Material
   - Important Judgments
6. Update **Candidate** to show:
   - General Instruction – Orders
   - Specific Instructions
7. Update **Political Party** to show:
   - General Orders
   - Registered with SEC
   - De Registered with SEC
8. Keep remaining existing sections available after these requested menus. Existing useful pages will not be deleted; routes no longer shown in these concise dropdowns remain reachable through connected pages, search, footer, or sitemap.

## Pages and content structure

- Reuse current pages where a requested label already has a suitable destination.
- Add only the missing pages for statistics, RO judgments, candidate instruction categories, and registered/de-registered party lists.
- Give every new page bilingual labels, its own descriptive page metadata, breadcrumbs, source ownership, required fields/filters/actions, and a clear “awaiting official content” state.
- Do not invent election dates, judgments, orders, party status, statistics, officers, or other official records.

## Header behaviour

- Convert each requested desktop item into a clearly identified menu button with an adjacent chevron and active state.
- Use the existing accessible menu component so Enter/Space opens a menu, arrow keys move through choices, Escape closes it, and focus returns to the trigger.
- Keep menu links as real links and preserve visible focus rings.
- Mirror the same order and labels in the mobile accordion navigation.
- Retain the contextual section links below the main navigation for deeper access without duplicating top-level items.

## GIGW 3.0 checks applied to this update

- Consistent navigation, bilingual labels, breadcrumbs, sitemap linkage, and unique page titles/descriptions.
- No hover-only access: all menus work by keyboard, touch, and assistive technology.
- Descriptive accessible names, expanded/menu state exposure, logical DOM/tab order, skip links, and strong focus visibility.
- Minimum practical touch targets, reflow without clipping, sufficient contrast, semantic landmarks, and no keyboard traps.
- Clear current-page indication and meaningful empty/source states for content awaiting official publication.

## Validation

- Check every new and reused menu destination returns a working page.
- Test desktop keyboard navigation, dismissal, focus return, and active states.
- Test mobile menu order, accordion operation, touch targets, and no horizontal overflow.
- Verify English/Marathi switching updates all new labels.
- Verify accessibility names/states and inspect preview console/runtime errors.
- Run the project type check and confirm the latest preview build is successful.
