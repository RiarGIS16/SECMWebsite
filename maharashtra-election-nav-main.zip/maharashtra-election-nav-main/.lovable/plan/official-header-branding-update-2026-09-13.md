# Official header branding update

## Scope
- Preserve the existing navigation, page structure, design system, search, language controls, and workflows.
- Replace the temporary “SEC” mark with the official SEC Maharashtra logo shown on the Commission website.
- Add the Lion Capital emblem to the opposite side of the masthead using the official source artwork.
- Restyle the masthead and utility strip to match the supplied reference while retaining responsive behavior.

## Working utility controls
- Add a live India date/time display that updates each second without causing server-rendering mismatches.
- Keep global search functional and expose it as a prominent search control in the utility strip.
- Add a screen-reader/audio control that reads the page’s main content aloud and can stop playback.
- Present text sizing as A−, A, A+ controls; present separate standard and high-contrast “A” buttons.
- Keep Marathi switching functional and add a clearly styled Login control linked to a real sign-in page state.

## Platform-wide visual markers
- Reuse the existing navigation icon metadata to display clear Lucide icons in homepage quick-service cards.
- Add consistent section-specific icons to service cards across section pages without changing their destinations or content.
- Use accessible labels, keyboard targets, and reduced-motion behavior throughout.

## Technical details
- Store official bitmap artwork as CDN-backed project assets, with local pointer files rather than large binaries.
- Add semantic masthead and utility colors to the shared design tokens; avoid hardcoded colors in page components.
- Add a small reusable service-icon mapper so icon usage stays consistent across the site.
- Update the existing incremental gap map and roadmap to tie this enhancement to the branding/accessibility requirements.
- Verify type safety, live rendering at desktop and mobile widths, utility interactions, navigation, and the latest build status.
