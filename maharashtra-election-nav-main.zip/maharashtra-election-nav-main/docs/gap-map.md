# Incremental update plan — existing SECM site vs. workbook

Rule applied: enhance an existing page wherever it can carry the requirement;
create a sub-page only where the workbook identifies a distinct service area;
fix shared behaviour once in a reusable component.

## A. Already present — reused, not rebuilt

| Requirement | Existing asset | Action |
| --- | --- | --- |
| Master Local Body selector (Type → District → Local Body → Ward) | `components/common/AreaFilter.tsx` + `data/geo.ts` (valid-only combinations) | Reuse everywhere |
| Common date filter, inclusive of both endpoints | `components/common/DateRangeFilter.tsx` + `lib/date-range.ts` | Reuse everywhere |
| Universal search & filter, empty states, document metadata cards, preview, status | `components/common/DocumentRegister.tsx`, `data/documents.ts` | Reuse everywhere |
| Site-wide search | `components/common/GlobalSearch.tsx`, `/search` | Keep |
| External-link classification (internal / government / third party) | `components/common/SmartLink.tsx` | Keep; single mechanism |
| Bilingual system, accessibility shell, header/footer/design system | `i18n/*`, `components/layout/*`, `styles.css` | Enhanced with official branding, live clock, audio reading, explicit text/contrast controls and service icons |
| Home, About, Voter, Candidate, RO, Parties, Elections, Documents, Contact, Feedback, RTI, EVM, Events, Publications, Statistics landings | existing routes | Enhance only |

## B. New sub-pages added under existing parents

- About: Awards & recognition
- Voter: Local self-government voter list, Voter awareness orders
- Elections: Upcoming, Ongoing, Recently completed
- Help for ROs: Constitutional provisions, Handbooks & manuals, Training material, Circulars & orders, FAQs
- Candidates: Result / elected candidate
- Political parties: Circulars & orders, Party contact
- Events: Calendar, Past events, Media gallery
- Publications: Annual reports, Statistical publications, Manuals, Publication search
- RTI: Section 4 disclosure, PIO / appellate authority, Application process, RTI reports
- EVM/VVPAT: Demonstration, FAQs, Orders & circulars, Security process, Training
- Feedback: Accessibility feedback, Escalation matrix, Public feedback statistics

No new top-level menu items were introduced; every page is attached to its
existing parent section, so the header, footer and sitemap stay in step.

## C. Content model, not invented content

Each new sub-page declares the exact record structure the workbook asks for
(fields, filters, statuses, exports) and states the owning office and the data
source that must supply it. Official values — dates, officers, results,
statistics, circular numbers, legal provisions — are left as clearly marked
CMS placeholders rather than fabricated.

## D. Official branding and utility-bar enhancement

The existing global header is retained and enhanced rather than replaced. The
official SEC Maharashtra mark and Lion Capital artwork are sourced from the
Commission website. The utility bar now exposes working search, India time,
page reading, text-size, contrast, Marathi and clearly marked demo-login
controls. Existing service cards reuse their route/icon metadata for consistent
visual markers without changing navigation or content.

## E. Requested primary-navigation alignment

The global navigation now follows the supplied legacy-menu reference order:
About Us, Imp Statistics, Voters, Election Program, Help for ROs, Candidate and
Political Party. Existing suitable destinations were reused. New pages were
created only for statistical reports, due-election data, important judgments,
candidate instruction categories and de-registered party records. Their official
records remain CMS placeholders. Desktop menus are keyboard-operable and mirrored
by touch-sized mobile accordions in accordance with the applicable GIGW 3.0 and
WCAG 2.1 AA navigation requirements.

## F. Real published records replace sample data

Voters, Election Programme, Candidate and Publications registers now carry the
Commission's own published records (titles, document types, dates, file sizes
and file links, collected from mahasec.maharashtra.gov.in on 17 September 2026)
in `src/data/official-records`-style module `src/data/official-documents.ts`.
Download buttons open the actual published PDF. Sections with no published list
keep the clearly labelled demo register so filter behaviour stays exercisable.
